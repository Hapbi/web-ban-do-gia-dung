using CuaHangGiaDungPro.Data;
using CuaHangGiaDungPro.Helpers;
using CuaHangGiaDungPro.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace CuaHangGiaDungPro.Controllers;

public class TrangChuController : Controller
{
    private readonly AppDb _db;
    public TrangChuController(AppDb db) => _db = db;

    public async Task<IActionResult> Index()
    {
        ViewBag.Banners = await _db.Banners
            .Where(x => x.DangHienThi)
            .OrderBy(x => x.ThuTu).ThenBy(x => x.Id)
            .ToListAsync();

        ViewBag.DanhMucs = await _db.DanhMucs.ToListAsync();
        ViewBag.CauHinh = await _db.CauHinhs.FirstOrDefaultAsync();

        var noiBat = await _db.SanPhams
            .Include(x => x.DanhMuc).Include(x => x.DanhSachDanhGia)
            .Where(x => x.DangBan && x.NoiBat && x.TonKho > 0)
            .OrderByDescending(x => x.NgayTao).Take(8).ToListAsync();
        ViewBag.SanPhamNoiBat = noiBat;

        var sanPhamMoi = await _db.SanPhams
            .Include(x => x.DanhMuc).Include(x => x.DanhSachDanhGia)
            .Where(x => x.DangBan && x.TonKho > 0)
            .OrderByDescending(x => x.NgayTao).Take(8).ToListAsync();
        ViewBag.SanPhamMoi = sanPhamMoi;

        var banChay = await _db.SanPhams
            .Include(x => x.DanhMuc).Include(x => x.DanhSachDanhGia)
            .Where(x => x.DangBan && x.TonKho > 0)
            .OrderByDescending(x => x.DaBan).Take(4).ToListAsync();
        ViewBag.SanPhamBanChay = banChay;

        // 37 ảnh cho 3D Ring Carousel
        var allImgs = await _db.SanPhams.Where(x => x.DangBan && !string.IsNullOrEmpty(x.AnhChinh))
            .Select(x => x.AnhChinh).ToListAsync();
        if (!allImgs.Any()) allImgs.Add("/images/san-pham-mac-dinh.svg");
        var list37 = new List<string>();
        for (int i = 0; i < 37; i++) list37.Add(allImgs[i % allImgs.Count]);
        ViewBag.List37 = list37;

        return View();
    }

    [Route("lien-he")]
    public IActionResult LienHe() => View();

    [HttpPost, Route("lien-he")]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> LienHe(string hoTen, string email, string dienThoai, string noiDung)
    {
        if (string.IsNullOrWhiteSpace(hoTen) || string.IsNullOrWhiteSpace(noiDung))
        {
            TempData["Loi"] = "Vui lòng nhập họ tên và nội dung";
            return View();
        }
        _db.LienHes.Add(new LienHe
        {
            HoTen = hoTen.Trim(),
            Email = email?.Trim() ?? "",
            DienThoai = dienThoai?.Trim() ?? "",
            NoiDung = noiDung.Trim()
        });
        await _db.SaveChangesAsync();
        TempData["ThanhCong"] = "Cảm ơn bạn đã gửi liên hệ! Chúng tôi sẽ phản hồi sớm.";
        return RedirectToAction(nameof(LienHe));
    }

    [Route("loi")]
    public IActionResult Loi() => Content("Đã có lỗi xảy ra.");
}
