# Nova 4-Role Marketplace Upgrade

## Scope
This upgrade keeps the existing ASP.NET Core 8 + Identity + EF Core architecture and adds a marketplace layer.

## Roles
1. Guest: browse only.
2. Customer: buy, cart, order history, account, sell.
3. Employee: `/Employee` for operations, reports, inventory and marketplace moderation.
4. Admin: `/Admin` for full administration and staff/account governance.

## Security / UX changes
- Guest add-to-cart is blocked server-side and returns a registration/login gate in AJAX flows.
- Admin demo username is `admin`; demo password is configured only in `appsettings.Development.json`.
- Identity continues to hash passwords; cookies are HttpOnly/Secure in production, anti-forgery remains enabled and auth is rate-limited.
- Marketplace listings are moderated before publication.
- Seller self-purchase is blocked server-side.
- Platform fee is persisted per order line at 7% for marketplace items.

## Important deployment note
The environment does not include the .NET SDK in this build session, so `dotnet build` could not be executed here. The project should be built and integration-tested on a machine with the .NET 8 SDK and SQL Server available before production deployment.
