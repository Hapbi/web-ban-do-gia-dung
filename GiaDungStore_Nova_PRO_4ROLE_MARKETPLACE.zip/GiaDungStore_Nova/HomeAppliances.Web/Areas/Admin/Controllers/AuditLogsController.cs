using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using HomeAppliances.Web.Data;
using HomeAppliances.Web.Infrastructure;
using HomeAppliances.Web.Models.Entities;
using HomeAppliances.Web.Services;

namespace HomeAppliances.Web.Areas.Admin.Controllers;

[Area("Admin"), Authorize(Policy = AppPolicies.AdminOnly)]
public class AuditLogsController : Controller
{
    private readonly ApplicationDbContext _db;
    public AuditLogsController(ApplicationDbContext db) => _db = db;

    public async Task<IActionResult> Index(string? q, int page = 1)
    {
        const int size = 30;
        var query = _db.AuditLogs.AsNoTracking().AsQueryable();
        if (!string.IsNullOrWhiteSpace(q)) { var t = q.Trim(); query = query.Where(a => a.Action.Contains(t) || a.EntityType.Contains(t) || a.UserEmail!.Contains(t) || a.EntityId!.Contains(t)); }
        var total = await query.CountAsync();
        page = Math.Clamp(page, 1, Math.Max(1, (int)Math.Ceiling(total / (double)size)));
        ViewData["Q"] = q;
        return View(new PagedResult<AuditLog> { Items = await query.OrderByDescending(a => a.Id).Skip((page - 1) * size).Take(size).ToListAsync(), Page = page, PageSize = size, TotalItems = total });
    }
}
