using Microsoft.AspNetCore.Identity;

namespace HomeAppliances.Web.Models.Entities;

public class ApplicationUser : IdentityUser
{
    public string FullName { get; set; } = "";
    public DateTime CreatedUtc { get; set; } = DateTime.UtcNow;
    /// <summary>False = account deactivated by an administrator (cannot sign in).</summary>
    public bool IsActive { get; set; } = true;
}
