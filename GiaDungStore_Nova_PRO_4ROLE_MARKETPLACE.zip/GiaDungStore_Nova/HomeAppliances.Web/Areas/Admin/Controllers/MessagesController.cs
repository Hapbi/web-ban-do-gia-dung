using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using HomeAppliances.Web.Data;
using HomeAppliances.Web.Infrastructure;
using HomeAppliances.Web.Models.Entities;
using HomeAppliances.Web.Services;

namespace HomeAppliances.Web.Areas.Admin.Controllers;

/// <summary>Messages sent through the public Contact page.</summary>
[Area("Admin"), Authorize(Policy = AppPolicies.AdminOnly)]
public class MessagesController : Controller
{
    private readonly ApplicationDbContext _db;
    public MessagesController(ApplicationDbContext db) => _db = db;

    public async Task<IActionResult> Index(int page = 1)
    {
        const int size = 20;
        var total = await _db.ContactMessages.CountAsync();
        page = Math.Clamp(page, 1, Math.Max(1, (int)Math.Ceiling(total / (double)size)));
        var items = await _db.ContactMessages.AsNoTracking().OrderByDescending(m => m.CreatedUtc).Skip((page - 1) * size).Take(size).ToListAsync();
        return View(new PagedResult<ContactMessage> { Items = items, Page = page, PageSize = size, TotalItems = total });
    }

    [HttpPost]
    public async Task<IActionResult> MarkRead(int id)
    {
        var m = await _db.ContactMessages.FirstOrDefaultAsync(x => x.Id == id);
        if (m == null) return NotFound();
        m.IsRead = true; await _db.SaveChangesAsync();
        return RedirectToAction(nameof(Index));
    }

    [HttpPost]
    public async Task<IActionResult> Delete(int id)
    {
        var m = await _db.ContactMessages.FirstOrDefaultAsync(x => x.Id == id);
        if (m == null) return NotFound();
        _db.ContactMessages.Remove(m); await _db.SaveChangesAsync();
        return RedirectToAction(nameof(Index));
    }
}
