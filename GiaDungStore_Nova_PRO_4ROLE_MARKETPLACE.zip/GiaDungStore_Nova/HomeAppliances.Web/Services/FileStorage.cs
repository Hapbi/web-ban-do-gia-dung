using Microsoft.Extensions.Options;
using HomeAppliances.Web.Domain;

namespace HomeAppliances.Web.Services;

public record StoredFile(string RelativePath, string ContentType, long SizeBytes);

public interface IFileStorage
{
    /// <summary>Saves a validated image under wwwroot/uploads/{folder}; returns the web path.</summary>
    Task<ServiceResult<string>> SavePublicImageAsync(IFormFile file, string folder);
    /// <summary>Saves a validated image outside wwwroot (payment proofs). Not reachable by URL.</summary>
    Task<ServiceResult<StoredFile>> SavePrivateImageAsync(IFormFile file, string subFolder);
    (Stream Stream, string ContentType)? OpenPrivate(string relativePath);
    void DeletePublic(string? webPath);
    void DeletePrivate(string? relativePath);
}

public class FileStorage : IFileStorage
{
    private readonly IWebHostEnvironment _env;
    private readonly StorageOptions _opt;

    public FileStorage(IWebHostEnvironment env, IOptions<StorageOptions> opt) { _env = env; _opt = opt.Value; }

    private string WebRoot => _env.WebRootPath ?? Path.Combine(_env.ContentRootPath, "wwwroot");
    private string PrivateRoot => Path.GetFullPath(Path.IsPathRooted(_opt.PrivateRoot) ? _opt.PrivateRoot : Path.Combine(_env.ContentRootPath, _opt.PrivateRoot));

    private static string SafeSegment(string s) => new(s.Where(c => char.IsAsciiLetterOrDigit(c) || c is '-' or '_').ToArray());

    private static async Task<UploadCheck> CheckAsync(IFormFile file, long max)
    {
        var header = new byte[UploadValidator.HeaderLength];
        int read;
        await using (var s = file.OpenReadStream()) read = await s.ReadAsync(header.AsMemory(0, header.Length));
        Array.Resize(ref header, read);
        return UploadValidator.Validate(file.FileName, file.Length, header, max);
    }

    public async Task<ServiceResult<string>> SavePublicImageAsync(IFormFile file, string folder)
    {
        var check = await CheckAsync(file, _opt.MaxImageBytes);
        if (!check.Ok) return ServiceResult<string>.Fail(check.Error!);

        var seg = SafeSegment(folder);
        var dir = Path.Combine(WebRoot, "uploads", seg);
        Directory.CreateDirectory(dir);
        var name = Guid.NewGuid().ToString("N") + check.Extension;
        await using (var fs = File.Create(Path.Combine(dir, name))) await file.CopyToAsync(fs);
        return ServiceResult<string>.Ok($"/uploads/{seg}/{name}");
    }

    public async Task<ServiceResult<StoredFile>> SavePrivateImageAsync(IFormFile file, string subFolder)
    {
        var check = await CheckAsync(file, _opt.MaxPaymentProofBytes);
        if (!check.Ok) return ServiceResult<StoredFile>.Fail(check.Error!);

        var seg = string.Join('/', subFolder.Split('/', StringSplitOptions.RemoveEmptyEntries).Select(SafeSegment));
        var dir = Path.Combine(PrivateRoot, seg.Replace('/', Path.DirectorySeparatorChar));
        Directory.CreateDirectory(dir);
        var name = Guid.NewGuid().ToString("N") + check.Extension;   // server-generated name, never the client's
        await using (var fs = File.Create(Path.Combine(dir, name))) await file.CopyToAsync(fs);
        return ServiceResult<StoredFile>.Ok(new StoredFile($"{seg}/{name}", ContentTypeFor(check.Extension), file.Length));
    }

    public (Stream Stream, string ContentType)? OpenPrivate(string relativePath)
    {
        var root = PrivateRoot;
        var full = Path.GetFullPath(Path.Combine(root, relativePath.Replace('/', Path.DirectorySeparatorChar)));
        // Path traversal guard: the resolved file must stay inside the private root.
        if (!full.StartsWith(root + Path.DirectorySeparatorChar, StringComparison.Ordinal) || !File.Exists(full)) return null;
        return (new FileStream(full, FileMode.Open, FileAccess.Read, FileShare.Read), ContentTypeFor(Path.GetExtension(full)));
    }

    public void DeletePublic(string? webPath)
    {
        if (string.IsNullOrEmpty(webPath) || !webPath.StartsWith("/uploads/") || webPath.Contains("..")) return;
        var full = Path.GetFullPath(Path.Combine(WebRoot, webPath.TrimStart('/').Replace('/', Path.DirectorySeparatorChar)));
        if (full.StartsWith(Path.GetFullPath(Path.Combine(WebRoot, "uploads")) + Path.DirectorySeparatorChar) && File.Exists(full)) File.Delete(full);
    }

    public void DeletePrivate(string? relativePath)
    {
        if (string.IsNullOrEmpty(relativePath)) return;
        var full = Path.GetFullPath(Path.Combine(PrivateRoot, relativePath.Replace('/', Path.DirectorySeparatorChar)));
        if (full.StartsWith(PrivateRoot + Path.DirectorySeparatorChar) && File.Exists(full)) File.Delete(full);
    }

    private static string ContentTypeFor(string ext) => ext.ToLowerInvariant() switch
    {
        ".png" => "image/png",
        ".webp" => "image/webp",
        ".gif" => "image/gif",
        _ => "image/jpeg"
    };
}
