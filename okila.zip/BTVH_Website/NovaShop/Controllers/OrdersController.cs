using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using NovaShop.Models;
using NovaShop.Services;

namespace NovaShop.Controllers;

public class OrdersController : Controller
{
    private readonly OrderService _orders;
    public OrdersController(OrderService orders) => _orders = orders;

    [Authorize, Route("don-hang")]
    public async Task<IActionResult> Index() => View(await _orders.GetMyOrdersAsync());

    [Authorize, Route("don-hang/{code}")]
    public async Task<IActionResult> Detail(string code)
    {
        var o = await _orders.GetByCodeAsync(code);
        if (o == null) return NotFound();
        return View(o);
    }

    [Route("tra-cuu")]
    public IActionResult Track() => View(new TrackOrderVM());

    [HttpPost, Route("tra-cuu")]
    public async Task<IActionResult> Track(TrackOrderVM vm)
    {
        if (!ModelState.IsValid) return View(vm);
        vm.Searched = true;
        vm.Result = await _orders.TrackByCodeAndPhoneAsync(vm.OrderCode, vm.Phone);
        return View(vm);
    }
}


####################################################################################################
