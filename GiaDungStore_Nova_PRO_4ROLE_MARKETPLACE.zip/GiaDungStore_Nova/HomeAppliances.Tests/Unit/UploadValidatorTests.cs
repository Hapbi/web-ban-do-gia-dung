using HomeAppliances.Web.Domain;
using Xunit;

namespace HomeAppliances.Tests.Unit;

public class UploadValidatorTests
{
    private static readonly byte[] Jpeg = { 0xFF, 0xD8, 0xFF, 0xE0, 0, 0x10, (byte)'J', (byte)'F', (byte)'I', (byte)'F', 0, 1, 1, 0, 0, 1 };
    private static readonly byte[] Png = { 0x89, 0x50, 0x4E, 0x47, 0x0D, 0x0A, 0x1A, 0x0A, 0, 0, 0, 13, (byte)'I', (byte)'H', (byte)'D', (byte)'R' };
    private static readonly byte[] Webp = { (byte)'R', (byte)'I', (byte)'F', (byte)'F', 1, 2, 3, 4, (byte)'W', (byte)'E', (byte)'B', (byte)'P', (byte)'V', (byte)'P', (byte)'8', (byte)' ' };
    private static readonly byte[] Gif = { (byte)'G', (byte)'I', (byte)'F', (byte)'8', (byte)'9', (byte)'a', 1, 0, 1, 0, 0, 0, 0, 0, 0, 0 };
    private static readonly byte[] Html = System.Text.Encoding.ASCII.GetBytes("<html><script>alert(1)</script>");
    private static readonly byte[] Exe = { (byte)'M', (byte)'Z', 0x90, 0, 3, 0, 0, 0, 4, 0, 0, 0, 0xFF, 0xFF, 0, 0 };

    private const long Max = 5 * 1024 * 1024;

    [Fact] public void Accepts_a_real_jpeg() { var r = UploadValidator.Validate("bien-lai.jpg", 1000, Jpeg, Max); Assert.True(r.Ok); Assert.Equal(".jpg", r.Extension); }
    [Fact] public void Accepts_jpeg_extension_variant() => Assert.True(UploadValidator.Validate("a.JPEG", 1000, Jpeg, Max).Ok);
    [Fact] public void Accepts_a_real_png() => Assert.Equal(".png", UploadValidator.Validate("a.png", 1000, Png, Max).Extension);
    [Fact] public void Accepts_a_real_webp() => Assert.Equal(".webp", UploadValidator.Validate("a.webp", 1000, Webp, Max).Extension);

    [Fact] public void Rejects_html_renamed_to_jpg() => Assert.False(UploadValidator.Validate("evil.jpg", 100, Html, Max).Ok);
    [Fact] public void Rejects_an_executable_renamed_to_png() => Assert.False(UploadValidator.Validate("setup.png", 100, Exe, Max).Ok);
    [Fact] public void Rejects_when_extension_and_content_disagree() => Assert.False(UploadValidator.Validate("a.png", 1000, Jpeg, Max).Ok);
    [Fact] public void Rejects_gif_unless_allowed() { Assert.False(UploadValidator.Validate("a.gif", 1000, Gif, Max).Ok); Assert.True(UploadValidator.Validate("a.gif", 1000, Gif, Max, allowGif: true).Ok); }
    [Fact] public void Rejects_files_over_the_size_limit() => Assert.False(UploadValidator.Validate("a.jpg", Max + 1, Jpeg, Max).Ok);
    [Fact] public void Rejects_empty_files() => Assert.False(UploadValidator.Validate("a.jpg", 0, Jpeg, Max).Ok);
    [Fact] public void Rejects_a_file_without_extension() => Assert.False(UploadValidator.Validate("receipt", 1000, Jpeg, Max).Ok);
    [Fact] public void Never_returns_the_clients_extension_for_double_extensions() { var r = UploadValidator.Validate("shell.php.jpg", 1000, Jpeg, Max); Assert.True(r.Ok); Assert.Equal(".jpg", r.Extension); }
}
