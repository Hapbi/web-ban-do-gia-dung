using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using NovaShop.Data;
using NovaShop.Helpers;
using NovaShop.Models;
using NovaShop.Services;

namespace NovaShop.Controllers;

[Authorize(Roles = "Admin,Staff")]
[Route("quan-tri")]
public class ManageController : Controller
{
    private readonly AppDbContext _db;
    private readonly AuthService _auth;
    private readonly OrderService _orders;
    private readonly MarketplaceService _market;
    private readonly ReportService _report;
    private readonly SettingsService _settings;
    private readonly AuditService _audit;

    public ManageController(AppDbContext db, AuthService auth, OrderService orders,
        MarketplaceService market, ReportService report, SettingsService settings, AuditService audit)
    { _db = db; _auth = auth; _orders = orders; _market = market; _report = report; _settings = settings; _audit = audit; }

    async Task LogAsync(string action, string entity, string id, string details = "")
    {
        var u = await _auth.GetCurrentAsync();
        await _audit.LogAsync(u?.Email ?? "system", action, entity, id, details);
    }

    // ============ DASHBOARD ============
    [HttpGet("")]
    public async Task<IActionResult> Dashboard()
    {
        if (!User.Can("revenue.view") && !User.Can("stock.view")) return Forbid();
        return View(await _report.GetDashboardAsync());
    }

    // ============ SẢN PHẨM ============
    [HttpGet("san-pham")]
    public async Task<IActionResult> Products(string? q, int? catId, bool? active, bool lowStock = false, int page = 1)
    {
        if (!User.CanProducts()) return Forbid();
        var query = _db.Products.Include(p => p.Category).Include(p => p.Brand).Include(p => p.Images).AsQueryable();
        if (!string.IsNullOrWhiteSpace(q))
        {
            var term = q.Trim().ToLower();
            query = query.Where(p => p.Name.ToLower().Contains(term));
        }
        if (catId.HasValue) query = query.Where(p => p.CategoryId == catId.Value);
        if (active.HasValue) query = query.Where(p => p.IsActive == active.Value);
        if (lowStock) query = query.Where(p => p.Stock > 0 && p.Stock <= 5);

        var total = await query.CountAsync();
        var products = await query.OrderByDescending(p => p.Id).Skip((page - 1) * 20).Take(20).ToListAsync();

        ViewBag.Search = q; ViewBag.CatId = catId; ViewBag.Active = active;
        ViewBag.LowStock = lowStock; ViewBag.Page = page; ViewBag.Total = total;
        ViewBag.TotalPages = (int)Math.Ceiling(total / 20.0);
        ViewBag.Categories = await _db.Categories.OrderBy(c => c.DisplayOrder).ToListAsync();
        return View(products);
    }

    [HttpGet("san-pham/them")]
    public async Task<IActionResult> ProductCreate()
    {
        if (!User.CanProducts()) return Forbid();
        ViewBag.Categories = await _db.Categories.ToListAsync();
        ViewBag.Brands = await _db.Brands.ToListAsync();
        return View("ProductForm", new ProductEditVM());
    }

    [HttpGet("san-pham/sua/{id:int}")]
    public async Task<IActionResult> ProductEdit(int id)
    {
        if (!User.CanProducts()) return Forbid();
        var p = await _db.Products.Include(x => x.Images).Include(x => x.Specs).FirstOrDefaultAsync(x => x.Id == id);
        if (p == null) return NotFound();
        var vm = new ProductEditVM
        {
            Id = p.Id, Name = p.Name, Slug = p.Slug,
            ShortDescription = p.ShortDescription, Description = p.Description,
            CategoryId = p.CategoryId, BrandId = p.BrandId,
            OriginalPrice = p.OriginalPrice, SalePrice = p.SalePrice, Stock = p.Stock,
            IsFeatured = p.IsFeatured, IsActive = p.IsActive, Tags = p.Tags,
            ImageUrlsText = string.Join("\n", p.Images.OrderBy(i => i.SortOrder).Select(i => i.Url)),
            SpecsText = string.Join("\n", p.Specs.OrderBy(s => s.SortOrder).Select(s => $"{s.Name}: {s.Value}"))
        };
        ViewBag.Categories = await _db.Categories.ToListAsync();
        ViewBag.Brands = await _db.Brands.ToListAsync();
        return View("ProductForm", vm);
    }

    [HttpPost("san-pham/luu")]
    public async Task<IActionResult> ProductSave(ProductEditVM vm)
    {
        if (!User.CanProducts()) return Forbid();
        if (!ModelState.IsValid)
        {
            ViewBag.Categories = await _db.Categories.ToListAsync();
            ViewBag.Brands = await _db.Brands.ToListAsync();
            return View("ProductForm", vm);
        }
        Product p;
        if (vm.Id == 0) { p = new Product(); _db.Products.Add(p); }
        else
        {
            var existing = await _db.Products.Include(x => x.Images).Include(x => x.Specs).FirstOrDefaultAsync(x => x.Id == vm.Id);
            if (existing == null) return NotFound();
            p = existing;
        }
        if (string.IsNullOrWhiteSpace(vm.Slug)) vm.Slug = Ext.Slugify(vm.Name);
        if (await _db.Products.AnyAsync(x => x.Slug == vm.Slug && x.Id != vm.Id))
            vm.Slug = vm.Slug + "-" + Guid.NewGuid().ToString("N")[..4];

        p.Name = vm.Name.Trim();
        p.Slug = vm.Slug;
        p.ShortDescription = vm.ShortDescription?.Trim() ?? "";
        p.Description = vm.Description?.Trim() ?? "";
        p.CategoryId = vm.CategoryId;
        p.BrandId = vm.BrandId;
        p.Stock = vm.Stock;
        p.IsFeatured = vm.IsFeatured;
        p.IsActive = vm.IsActive;
        p.Tags = vm.Tags?.Trim() ?? "";
        p.UpdatedAt = DateTime.Now;
        if (vm.Id == 0 || User.Can("price.set")) { p.OriginalPrice = vm.OriginalPrice; p.SalePrice = vm.SalePrice; }

        _db.ProductImages.RemoveRange(p.Images);
        p.Images.Clear();
        if (!string.IsNullOrWhiteSpace(vm.ImageUrlsText))
        {
            int sort = 0;
            foreach (var line in vm.ImageUrlsText.Split('\n', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries))
                p.Images.Add(new ProductImage { Url = line, IsPrimary = sort == 0, SortOrder = sort++ });
        }
        _db.ProductSpecs.RemoveRange(p.Specs);
        p.Specs.Clear();
        if (!string.IsNullOrWhiteSpace(vm.SpecsText))
        {
            int sort = 0;
            foreach (var line in vm.SpecsText.Split('\n', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries))
            {
                var parts = line.Split(':', 2);
                p.Specs.Add(new ProductSpec { Name = parts[0].Trim(), Value = parts.Length > 1 ? parts[1].Trim() : "", SortOrder = sort++ });
            }
        }

        await _db.SaveChangesAsync();
        await LogAsync(vm.Id == 0 ? "Tạo sản phẩm" : "Sửa sản phẩm", "Product", p.Id.ToString(), p.Name);
        TempData["Success"] = "Đã lưu sản phẩm";
        return RedirectToAction(nameof(Products));
    }

    [HttpPost("san-pham/xoa/{id:int}")]
    public async Task<IActionResult> ProductDelete(int id)
    {
        if (!User.Can("product.delete")) return Forbid();
        var p = await _db.Products.FindAsync(id);
        if (p == null) return NotFound();
        if (await _db.OrderItems.AnyAsync(i => i.ProductId == id))
        {
            TempData["Error"] = "Không thể xóa — sản phẩm đã có trong đơn hàng. Hãy dùng Ẩn thay vì xóa.";
            return RedirectToAction(nameof(Products));
        }
        _db.Products.Remove(p);
        await _db.SaveChangesAsync();
        await LogAsync("Xóa sản phẩm", "Product", id.ToString(), p.Name);
        TempData["Success"] = "Đã xóa sản phẩm";
        return RedirectToAction(nameof(Products));
    }

    [HttpPost("san-pham/an/{id:int}")]
    public async Task<IActionResult> ProductToggle(int id)
    {
        if (!User.CanProducts()) return Forbid();
        var p = await _db.Products.FindAsync(id);
        if (p == null) return NotFound();
        p.IsActive = !p.IsActive;
        await _db.SaveChangesAsync();
        await LogAsync(p.IsActive ? "Hiện SP" : "Ẩn SP", "Product", id.ToString(), p.Name);
        TempData["Success"] = p.IsActive ? "Đã hiện sản phẩm" : "Đã ẩn sản phẩm";
        return RedirectToAction(nameof(Products));
    }

    [HttpPost("san-pham/gia")]
    public async Task<IActionResult> ProductSetPrice(int id, decimal price)
    {
        if (!User.Can("price.set")) return Forbid();
        var p = await _db.Products.FindAsync(id);
        if (p == null) return NotFound();
        var old = p.OriginalPrice;
        p.OriginalPrice = price;
        await _db.SaveChangesAsync();
        await LogAsync("Đổi giá", "Product", id.ToString(), $"{old:N0} → {price:N0}");
        TempData["Success"] = "Đã đổi giá";
        return RedirectToAction(nameof(Products));
    }

    // ============ ĐƠN HÀNG ============
    [HttpGet("don-hang")]
    public async Task<IActionResult> Orders(OrderStatus? status, string? q, int page = 1)
    {
        if (!User.Can("order.view")) return Forbid();
        var query = _db.Orders.Include(o => o.User).Include(o => o.Items).AsQueryable();
        if (status.HasValue) query = query.Where(o => o.Status == status.Value);
        if (!string.IsNullOrWhiteSpace(q))
        {
            var term = q.Trim().ToLower();
            query = query.Where(o => o.Code.ToLower().Contains(term) || o.CustomerName.ToLower().Contains(term) || o.Phone.Contains(term));
        }
        var total = await query.CountAsync();
        var orders = await query.OrderByDescending(o => o.CreatedAt).Skip((page - 1) * 20).Take(20).ToListAsync();

        ViewBag.Status = status; ViewBag.Search = q; ViewBag.Page = page;
        ViewBag.Total = total; ViewBag.TotalPages = (int)Math.Ceiling(total / 20.0);
        ViewBag.StatusCounts = await _db.Orders.GroupBy(o => o.Status)
            .Select(g => new { g.Key, Count = g.Count() }).ToDictionaryAsync(x => x.Key, x => x.Count);
        return View(orders);
    }

    [HttpGet("don-hang/{id:int}")]
    public async Task<IActionResult> OrderDetail(int id)
    {
        if (!User.Can("order.view")) return Forbid();
        var o = await _db.Orders.Include(x => x.User).Include(x => x.Items).Include(x => x.History)
            .FirstOrDefaultAsync(x => x.Id == id);
        if (o == null) return NotFound();
        return View(o);
    }

    [HttpPost("don-hang/{id:int}/trang-thai")]
    public async Task<IActionResult> OrderSetStatus(int id, OrderStatus status)
    {
        if (!User.Can("order.status")) return Forbid();
        var u = await _auth.GetCurrentAsync();
        var (ok, msg) = status switch
        {
            OrderStatus.Confirmed => await _orders.ConfirmAsync(id, u!.FullName),
            OrderStatus.Packing   => await _orders.PackAsync(id, u!.FullName),
            OrderStatus.Shipping  => await _orders.ShipAsync(id, u!.FullName),
            OrderStatus.Delivered => await _orders.DeliverAsync(id, u!.FullName),
            OrderStatus.Cancelled => await _orders.CancelAsync(id, u!.FullName),
            _ => (false, "Trạng thái không hợp lệ")
        };
        TempData[ok ? "Success" : "Error"] = msg;
        return RedirectToAction(nameof(OrderDetail), new { id });
    }

    [HttpPost("don-hang/{id:int}/xac-minh-tt")]
    public async Task<IActionResult> OrderVerifyPayment(int id, bool approve, string? note)
    {
        if (!User.Can("payment.verify")) return Forbid();
        var u = await _auth.GetCurrentAsync();
        var (ok, msg) = await _orders.VerifyPaymentAsync(id, u!.FullName, approve, note);
        TempData[ok ? "Success" : "Error"] = msg;
        return RedirectToAction(nameof(OrderDetail), new { id });
    }

    // ============ NGƯỜI DÙNG ============
    [HttpGet("nguoi-dung"), Authorize(Roles = "Admin")]
    public async Task<IActionResult> Users(string? role, string? q)
    {
        var query = _db.Users.AsQueryable();
        if (!string.IsNullOrWhiteSpace(role)) query = query.Where(u => u.Role == role);
        if (!string.IsNullOrWhiteSpace(q))
        {
            var term = q.Trim().ToLower();
            query = query.Where(u => u.Email.ToLower().Contains(term) || u.FullName.ToLower().Contains(term) || u.Phone.Contains(term));
        }
        var users = await query.OrderBy(u => u.Id).ToListAsync();
        ViewBag.Role = role; ViewBag.Search = q;
        ViewBag.RoleCounts = await _db.Users.GroupBy(u => u.Role)
            .Select(g => new { g.Key, Count = g.Count() }).ToDictionaryAsync(x => x.Key, x => x.Count);
        return View(users);
    }

    [HttpPost("nguoi-dung/{id:int}/vai-tro"), Authorize(Roles = "Admin")]
    public async Task<IActionResult> UserSetRole(int id, string role)
    {
        if (!new[] { "Admin", "Staff", "Customer" }.Contains(role)) return BadRequest();
        var u = await _db.Users.FindAsync(id);
        if (u == null) return NotFound();
        if (u.Id == (await _auth.GetCurrentId())) { TempData["Error"] = "Không thể đổi vai trò chính bạn"; return RedirectToAction(nameof(Users)); }
        var old = u.Role;
        u.Role = role;
        u.Permissions = "";
        await _db.SaveChangesAsync();
        await LogAsync("Đổi vai trò", "User", id.ToString(), $"{u.Email}: {old} → {role}");
        TempData["Success"] = "Đã đổi vai trò";
        return RedirectToAction(nameof(Users));
    }

    [HttpPost("nguoi-dung/{id:int}/khoa"), Authorize(Roles = "Admin")]
    public async Task<IActionResult> UserToggleLock(int id)
    {
        var u = await _db.Users.FindAsync(id);
        if (u == null) return NotFound();
        if (u.Id == (await _auth.GetCurrentId())) { TempData["Error"] = "Không thể khóa chính mình"; return RedirectToAction(nameof(Users)); }
        u.IsActive = !u.IsActive;
        await _db.SaveChangesAsync();
        await LogAsync(u.IsActive ? "Mở khóa" : "Khóa", "User", id.ToString(), u.Email);
        TempData["Success"] = u.IsActive ? "Đã mở khóa" : "Đã khóa";
        return RedirectToAction(nameof(Users));
    }

    [HttpPost("nguoi-dung/{id:int}/dat-lai-mat-khau"), Authorize(Roles = "Admin")]
    public async Task<IActionResult> UserResetPassword(int id, string password)
    {
        if ((password ?? "").Length < 6) { TempData["Error"] = "Mật khẩu tối thiểu 6 ký tự"; return RedirectToAction(nameof(Users)); }
        var u = await _db.Users.FindAsync(id);
        if (u == null) return NotFound();
        u.PasswordHash = DbInitializer.Hash(password);
        await _db.SaveChangesAsync();
        await LogAsync("Đặt lại MK", "User", id.ToString(), u.Email);
        TempData["Success"] = "Đã đặt lại mật khẩu";
        return RedirectToAction(nameof(Users));
    }

    [HttpPost("nguoi-dung/tao-staff"), Authorize(Roles = "Admin")]
    public async Task<IActionResult> CreateStaff(string email, string fullName, string password)
    {
        var e = (email ?? "").Trim().ToLower();
        if (string.IsNullOrWhiteSpace(e) || string.IsNullOrWhiteSpace(fullName) || (password ?? "").Length < 6)
        { TempData["Error"] = "Vui lòng nhập đủ thông tin, mật khẩu ≥ 6 ký tự"; return RedirectToAction(nameof(Users)); }
        if (await _db.Users.AnyAsync(u => u.Email.ToLower() == e))
        { TempData["Error"] = "Email đã tồn tại"; return RedirectToAction(nameof(Users)); }
        _db.Users.Add(new User { Email = e, FullName = fullName.Trim(), PasswordHash = DbInitializer.Hash(password), Role = "Staff" });
        await _db.SaveChangesAsync();
        await LogAsync("Tạo Staff", "User", e, fullName);
        TempData["Success"] = $"Đã tạo Staff {e}";
        return RedirectToAction(nameof(Users));
    }

    // ============ PHÂN QUYỀN ============
    [HttpGet("phan-quyen/{id:int}"), Authorize(Roles = "Admin")]
    public async Task<IActionResult> Permissions(int id)
    {
        var u = await _db.Users.FindAsync(id);
        if (u == null) return NotFound();
        if (u.Role != "Staff") { TempData["Error"] = "Chỉ Staff mới cần phân quyền"; return RedirectToAction(nameof(Users)); }
        ViewBag.Granted = Perm.Effective(u.Role, u.Permissions);
        return View(u);
    }

    [HttpPost("phan-quyen/{id:int}"), Authorize(Roles = "Admin")]
    public async Task<IActionResult> Permissions(int id, string[] perms, bool reset = false)
    {
        var u = await _db.Users.FindAsync(id);
        if (u == null || u.Role != "Staff") return NotFound();
        u.Permissions = reset ? "" : Perm.Serialize(perms);
        await _db.SaveChangesAsync();
        await LogAsync("Phân quyền", "User", id.ToString(), u.Email);
        TempData["Success"] = "Đã lưu phân quyền";
        return RedirectToAction(nameof(Users));
    }

    // ============ DANH MỤC / THƯƠNG HIỆU / TAG ============
    [HttpGet("danh-muc"), RequirePerm("taxonomy.manage")]
    public async Task<IActionResult> Taxonomy()
    {
        ViewBag.Categories = await _db.Categories.OrderBy(c => c.DisplayOrder).ToListAsync();
        ViewBag.Brands = await _db.Brands.OrderBy(b => b.Name).ToListAsync();
        ViewBag.Tags = await _db.Tags.OrderBy(t => t.Name).ToListAsync();
        return View();
    }

    [HttpPost("danh-muc/them"), RequirePerm("taxonomy.manage")]
    public async Task<IActionResult> TaxonomyAdd(string type, string name, string? icon, int? order)
    {
        name = (name ?? "").Trim();
        if (string.IsNullOrWhiteSpace(name)) { TempData["Error"] = "Tên không được để trống"; return RedirectToAction(nameof(Taxonomy)); }
        var slug = Ext.Slugify(name);
        switch (type)
        {
            case "category":
                if (await _db.Categories.AnyAsync(c => c.Name.ToLower() == name.ToLower()))
                { TempData["Error"] = "Đã tồn tại"; return RedirectToAction(nameof(Taxonomy)); }
                _db.Categories.Add(new Category { Name = name, Slug = slug, Icon = icon ?? "📦", DisplayOrder = order ?? 0 });
                break;
            case "brand":
                if (await _db.Brands.AnyAsync(b => b.Name.ToLower() == name.ToLower()))
                { TempData["Error"] = "Đã tồn tại"; return RedirectToAction(nameof(Taxonomy)); }
                _db.Brands.Add(new Brand { Name = name, Slug = slug });
                break;
            case "tag":
                if (await _db.Tags.AnyAsync(t => t.Name.ToLower() == name.ToLower()))
                { TempData["Error"] = "Đã tồn tại"; return RedirectToAction(nameof(Taxonomy)); }
                _db.Tags.Add(new Tag { Name = name, Slug = slug });
                break;
            default: return BadRequest();
        }
        await _db.SaveChangesAsync();
        await LogAsync($"Thêm {type}", type, name, "");
        TempData["Success"] = "Đã thêm";
        return RedirectToAction(nameof(Taxonomy));
    }

    [HttpPost("danh-muc/xoa"), RequirePerm("taxonomy.manage")]
    public async Task<IActionResult> TaxonomyDelete(string type, int id)
    {
        switch (type)
        {
            case "category":
                if (await _db.Products.AnyAsync(p => p.CategoryId == id))
                { TempData["Error"] = "Còn sản phẩm trong danh mục, không thể xóa"; return RedirectToAction(nameof(Taxonomy)); }
                var c = await _db.Categories.FindAsync(id); if (c != null) _db.Categories.Remove(c); break;
            case "brand":
                if (await _db.Products.AnyAsync(p => p.BrandId == id))
                { TempData["Error"] = "Còn sản phẩm của thương hiệu, không thể xóa"; return RedirectToAction(nameof(Taxonomy)); }
                var b = await _db.Brands.FindAsync(id); if (b != null) _db.Brands.Remove(b); break;
            case "tag":
                var t = await _db.Tags.FindAsync(id); if (t != null) _db.Tags.Remove(t); break;
            default: return BadRequest();
        }
        await _db.SaveChangesAsync();
        TempData["Success"] = "Đã xóa";
        return RedirectToAction(nameof(Taxonomy));
    }

    // ============ BANNER ============
    [HttpGet("banner"), RequirePerm("banner.manage")]
    public async Task<IActionResult> Banners() => View(await _db.Banners.OrderBy(b => b.SortOrder).ToListAsync());

    [HttpPost("banner/luu"), RequirePerm("banner.manage")]
    public async Task<IActionResult> BannerSave(int id, string title, string imageUrl, string? linkUrl, int sortOrder, bool isActive)
    {
        if (string.IsNullOrWhiteSpace(imageUrl)) { TempData["Error"] = "Vui lòng nhập link ảnh"; return RedirectToAction(nameof(Banners)); }
        Banner b;
        if (id == 0) { b = new Banner(); _db.Banners.Add(b); }
        else { var existing = await _db.Banners.FindAsync(id); if (existing == null) return NotFound(); b = existing; }
        b.Title = title.Trim();
        b.ImageUrl = imageUrl.Trim();
        b.LinkUrl = linkUrl?.Trim();
        b.SortOrder = sortOrder;
        b.IsActive = isActive;
        await _db.SaveChangesAsync();
        TempData["Success"] = "Đã lưu banner";
        return RedirectToAction(nameof(Banners));
    }

    [HttpPost("banner/xoa/{id:int}"), RequirePerm("banner.manage")]
    public async Task<IActionResult> BannerDelete(int id)
    {
        var b = await _db.Banners.FindAsync(id);
        if (b != null) { _db.Banners.Remove(b); await _db.SaveChangesAsync(); TempData["Success"] = "Đã xóa"; }
        return RedirectToAction(nameof(Banners));
    }

    // ============ BÀI VIẾT ============
    [HttpGet("bai-viet"), RequirePerm("post.manage")]
    public async Task<IActionResult> Posts() => View(await _db.BlogPosts.OrderByDescending(p => p.Id).ToListAsync());

    [HttpGet("bai-viet/them"), RequirePerm("post.manage")]
    public IActionResult PostCreate() => View("PostForm", new BlogPost());

    [HttpGet("bai-viet/sua/{id:int}"), RequirePerm("post.manage")]
    public async Task<IActionResult> PostEdit(int id)
    {
        var p = await _db.BlogPosts.FindAsync(id);
        return p == null ? NotFound() : View("PostForm", p);
    }

    [HttpPost("bai-viet/luu"), RequirePerm("post.manage")]
    public async Task<IActionResult> PostSave(BlogPost vm)
    {
        if (string.IsNullOrWhiteSpace(vm.Title)) { TempData["Error"] = "Vui lòng nhập tiêu đề"; return RedirectToAction(nameof(Posts)); }
        BlogPost p;
        if (vm.Id == 0) { p = new BlogPost(); _db.BlogPosts.Add(p); }
        else { var existing = await _db.BlogPosts.FindAsync(vm.Id); if (existing == null) return NotFound(); p = existing; }
        if (string.IsNullOrWhiteSpace(vm.Slug)) vm.Slug = Ext.Slugify(vm.Title);
        if (await _db.BlogPosts.AnyAsync(x => x.Slug == vm.Slug && x.Id != vm.Id))
            vm.Slug = vm.Slug + "-" + Guid.NewGuid().ToString("N")[..4];
        p.Title = vm.Title.Trim();
        p.Slug = vm.Slug;
        p.Summary = vm.Summary?.Trim() ?? "";
        p.Content = vm.Content?.Trim() ?? "";
        p.CoverImage = vm.CoverImage?.Trim() ?? "";
        p.Category = vm.Category?.Trim() ?? "";
        p.AuthorName = vm.AuthorName?.Trim() ?? (await _auth.GetCurrentAsync())?.FullName ?? "Admin";
        p.IsPublished = vm.IsPublished;
        if (vm.IsPublished && p.PublishedAt == null) p.PublishedAt = DateTime.Now;
        await _db.SaveChangesAsync();
        TempData["Success"] = "Đã lưu bài viết";
        return RedirectToAction(nameof(Posts));
    }

    [HttpPost("bai-viet/xoa/{id:int}"), RequirePerm("post.manage")]
    public async Task<IActionResult> PostDelete(int id)
    {
        var p = await _db.BlogPosts.FindAsync(id);
        if (p != null) { _db.BlogPosts.Remove(p); await _db.SaveChangesAsync(); TempData["Success"] = "Đã xóa"; }
        return RedirectToAction(nameof(Posts));
    }

    // ============ LIÊN HỆ ============
    [HttpGet("lien-he"), RequirePerm("contact.manage")]
    public async Task<IActionResult> Contacts(ContactStatus? status, ContactType? type)
    {
        var query = _db.ContactMessages.AsQueryable();
        if (status.HasValue) query = query.Where(c => c.Status == status.Value);
        if (type.HasValue) query = query.Where(c => c.Type == type.Value);
        ViewBag.Status = status; ViewBag.Type = type;
        ViewBag.NewCount = await _db.ContactMessages.CountAsync(c => c.Status == ContactStatus.New);
        return View(await query.OrderByDescending(c => c.Id).ToListAsync());
    }

    [HttpPost("lien-he/{id:int}"), RequirePerm("contact.manage")]
    public async Task<IActionResult> ContactUpdate(int id, ContactStatus status, string? note)
    {
        var c = await _db.ContactMessages.FindAsync(id);
        if (c == null) return NotFound();
        c.Status = status;
        c.StaffNote = note?.Trim();
        c.HandledBy = (await _auth.GetCurrentAsync())?.FullName;
        if (status == ContactStatus.Resolved) c.ResolvedAt = DateTime.Now;
        await _db.SaveChangesAsync();
        TempData["Success"] = "Đã cập nhật";
        return RedirectToAction(nameof(Contacts));
    }

    // ============ MARKETPLACE ============
    [HttpGet("marketplace"), RequirePerm("marketplace.manage")]
    public async Task<IActionResult> Marketplace()
    {
        ViewBag.Pending = await _market.GetPendingAsync();
        ViewBag.All = await _market.GetAllListingsAsync();
        return View();
    }

    [HttpPost("marketplace/{id:int}/duyet"), RequirePerm("marketplace.manage")]
    public async Task<IActionResult> MarketplaceApprove(int id)
    {
        var (ok, msg) = await _market.ApproveAsync(id);
        TempData[ok ? "Success" : "Error"] = msg;
        return RedirectToAction(nameof(Marketplace));
    }

    [HttpPost("marketplace/{id:int}/tu-choi"), RequirePerm("marketplace.manage")]
    public async Task<IActionResult> MarketplaceReject(int id, string reason)
    {
        var (ok, msg) = await _market.RejectAsync(id, reason);
        TempData[ok ? "Success" : "Error"] = msg;
        return RedirectToAction(nameof(Marketplace));
    }

    // ============ BÁO CÁO ============
    [HttpGet("bao-cao-van-hanh"), RequirePerm("report.view")]
    public async Task<IActionResult> ReportOperations() => View(await _report.GetOperationsAsync());

    [HttpGet("bao-cao-doanh-thu"), RequirePerm("stats.view")]
    public async Task<IActionResult> ReportRevenue(DateTime? from, DateTime? to)
    {
        var f = from ?? DateTime.Today.AddDays(-29);
        var t = to ?? DateTime.Today;
        return View(await _report.GetRevenueAsync(f, t));
    }

    [HttpGet("bao-cao-doanh-thu/csv"), RequirePerm("stats.view")]
    public async Task<IActionResult> ReportRevenueCsv(DateTime? from, DateTime? to)
    {
        var f = from ?? DateTime.Today.AddDays(-29);
        var t = to ?? DateTime.Today;
        var vm = await _report.GetRevenueAsync(f, t);
        var sb = new System.Text.StringBuilder("Ngày,Số đơn,Doanh thu\n");
        foreach (var d in vm.Daily) sb.Append($"{d.Date:dd/MM/yyyy},{d.Orders},{(long)d.Revenue}\n");
        sb.Append($"TỔNG,{vm.PaidOrders},{(long)vm.TotalRevenue}\n");
        return File(System.Text.Encoding.UTF8.GetBytes(sb.ToString()), "text/csv; charset=utf-8",
            $"doanh-thu_{f:yyyyMMdd}_{t:yyyyMMdd}.csv");
    }

    // ============ CẤU HÌNH ============
    [HttpGet("cau-hinh"), RequirePerm("settings.manage")]
    public async Task<IActionResult> Settings()
    {
        ViewBag.Site = await _settings.GetSiteAsync();
        ViewBag.Bank = await _settings.GetBankAsync();
        return View();
    }

    [HttpPost("cau-hinh/site"), RequirePerm("settings.manage")]
    public async Task<IActionResult> SettingsSite(SiteSettings s)
    {
        await _settings.SaveSiteAsync(s);
        await LogAsync("Cập nhật cấu hình", "SiteSettings", "1", "");
        TempData["Success"] = "Đã lưu cấu hình";
        return RedirectToAction(nameof(Settings));
    }

    [HttpPost("cau-hinh/bank"), RequirePerm("settings.manage")]
    public async Task<IActionResult> SettingsBank(BankSettings b)
    {
        await _settings.SaveBankAsync(b);
        await LogAsync("Cập nhật ngân hàng", "BankSettings", "1", "");
        TempData["Success"] = "Đã lưu ngân hàng";
        return RedirectToAction(nameof(Settings));
    }

    // ============ NHẬT KÝ ============
    [HttpGet("nhat-ky"), RequirePerm("log.view")]
    public async Task<IActionResult> AuditLog(string? q)
    {
        var query = _db.AuditLogs.AsQueryable();
        if (!string.IsNullOrWhiteSpace(q))
        {
            var term = q.Trim().ToLower();
            query = query.Where(a => a.UserEmail.ToLower().Contains(term) || a.Action.ToLower().Contains(term) || a.Details.ToLower().Contains(term));
        }
        ViewBag.Search = q;
        return View(await query.OrderByDescending(a => a.Id).Take(500).ToListAsync());
    }
}
