using Microsoft.EntityFrameworkCore;
using NovaShop.Data;
using NovaShop.Models;

namespace NovaShop.Services;

public class CouponService
{
    private readonly AppDbContext _db;
    public CouponService(AppDbContext db) => _db = db;

    public async Task<(bool ok, Coupon? coupon, string? error)> ValidateAsync(string code, decimal orderTotal)
    {
        if (string.IsNullOrWhiteSpace(code)) return (false, null, "Nhập mã");
        var coupon = await _db.Coupons.FirstOrDefaultAsync(c => c.Code.ToUpper() == code.Trim().ToUpper());
        if (coupon == null) return (false, null, "Mã không tồn tại");
        if (!coupon.IsValid) return (false, null, "Mã không hợp lệ hoặc đã hết hạn");
        if (orderTotal < coupon.MinOrderAmount) return (false, null, $"Đơn tối thiểu {coupon.MinOrderAmount:N0}đ");
        return (true, coupon, null);
    }

    public async Task IncrementUsageAsync(string code)
    {
        var c = await _db.Coupons.FirstOrDefaultAsync(x => x.Code.ToUpper() == code.ToUpper());
        if (c != null) { c.UsedCount++; await _db.SaveChangesAsync(); }
    }
}
