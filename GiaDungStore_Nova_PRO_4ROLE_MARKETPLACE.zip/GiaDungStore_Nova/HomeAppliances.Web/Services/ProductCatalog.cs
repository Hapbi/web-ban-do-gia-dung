using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Caching.Memory;
using HomeAppliances.Web.Data;
using HomeAppliances.Web.Domain;
using HomeAppliances.Web.Models.Entities;
using HomeAppliances.Web.Models.ViewModels;

namespace HomeAppliances.Web.Services;

/// <summary>Read-side catalog used by the public storefront.</summary>
public interface IProductCatalog
{
    Task<HomePageViewModel> GetHomePageAsync();
    Task<ProductListViewModel> GetProductListAsync(ProductListQuery query);
    Task<ProductDetailViewModel?> GetProductBySlugAsync(string slug);
    Task<IReadOnlyList<CategoryLinkViewModel>> GetCategoriesAsync();
    Task<CategoryLinkViewModel?> GetCategoryAsync(string slug);
}

public class ProductCatalog : IProductCatalog
{
    public const string CategoriesCacheKey = "catalog:categories";
    private const int PageSize = 12;
    private readonly ApplicationDbContext _db;
    private readonly IMemoryCache _cache;

    public ProductCatalog(ApplicationDbContext db, IMemoryCache cache) { _db = db; _cache = cache; }

    private IQueryable<Product> Active => _db.Products.AsNoTracking().Where(p => p.IsActive && p.Category!.IsActive);

    private static IQueryable<ProductCardViewModel> ToCards(IQueryable<Product> q) =>
        q.Select(p => new ProductCardViewModel
        {
            Id = p.Id, Slug = p.Slug, Name = p.Name, Brand = p.Brand,
            CategorySlug = p.Category!.Slug, CategoryName = p.Category!.Name,
            OriginalPrice = p.OriginalPrice, DiscountPrice = p.DiscountPrice, StockQuantity = p.StockQuantity,
            ImageUrl = p.Images.OrderByDescending(i => i.IsPrimary).ThenBy(i => i.SortOrder).Select(i => i.Path).FirstOrDefault(),
            CreatedUtc = p.CreatedUtc, SoldCount = p.SoldCount
        });

    public async Task<IReadOnlyList<CategoryLinkViewModel>> GetCategoriesAsync() =>
        (await _cache.GetOrCreateAsync(CategoriesCacheKey, async e =>
        {
            e.AbsoluteExpirationRelativeToNow = TimeSpan.FromMinutes(2);
            return await _db.Categories.AsNoTracking().Where(c => c.IsActive).OrderBy(c => c.DisplayOrder).ThenBy(c => c.Name)
                .Select(c => new CategoryLinkViewModel { Slug = c.Slug, Name = c.Name, ProductCount = c.Products.Count(p => p.IsActive) })
                .ToListAsync();
        }))!;

    public async Task<CategoryLinkViewModel?> GetCategoryAsync(string slug) =>
        (await GetCategoriesAsync()).FirstOrDefault(c => c.Slug == slug);

    public async Task<HomePageViewModel> GetHomePageAsync()
    {
        var featured = await ToCards(Active.Where(p => p.IsFeatured && p.StockQuantity > 0).OrderByDescending(p => p.SoldCount).Take(4)).ToListAsync();
        if (featured.Count == 0)
            featured = await ToCards(Active.Where(p => p.DiscountPrice != null && p.StockQuantity > 0).OrderByDescending(p => p.OriginalPrice - p.DiscountPrice!.Value).Take(4)).ToListAsync();

        return new HomePageViewModel
        {
            Categories = (await GetCategoriesAsync()).ToList(),
            Featured = featured,
            NewArrivals = await ToCards(Active.OrderByDescending(p => p.CreatedUtc).Take(4)).ToListAsync(),
            BestSellers = await ToCards(Active.OrderByDescending(p => p.SoldCount).ThenByDescending(p => p.Id).Take(4)).ToListAsync(),
            Banners = await _db.Banners.AsNoTracking().Where(b => b.IsActive).OrderBy(b => b.SortOrder)
                .Select(b => new BannerViewModel { Title = b.Title, Subtitle = b.Subtitle, ImageUrl = b.ImagePath, LinkUrl = b.LinkUrl }).ToListAsync()
        };
    }

    public async Task<ProductListViewModel> GetProductListAsync(ProductListQuery query)
    {
        var q = Active;
        if (!string.IsNullOrWhiteSpace(query.Q))
        {
            var term = query.Q.Trim();
            var slugTerm = SlugHelper.Slugify(term);   // matches Vietnamese text typed without diacritics
            q = q.Where(p => p.Name.Contains(term) || p.Brand.Contains(term) || p.Category!.Name.Contains(term)
                             || p.Description.Contains(term) || (slugTerm != "" && p.Slug.Contains(slugTerm)));
        }
        if (!string.IsNullOrWhiteSpace(query.Category)) q = q.Where(p => p.Category!.Slug == query.Category);
        if (!string.IsNullOrWhiteSpace(query.Brand)) q = q.Where(p => p.Brand == query.Brand);
        if (query.MinPrice is > 0)
        {
            var min = query.MinPrice.Value;
            q = q.Where(p => (p.DiscountPrice > 0 && p.DiscountPrice < p.OriginalPrice ? p.DiscountPrice : (decimal?)p.OriginalPrice) >= min);
        }
        if (query.MaxPrice is > 0)
        {
            var max = query.MaxPrice.Value;
            q = q.Where(p => (p.DiscountPrice > 0 && p.DiscountPrice < p.OriginalPrice ? p.DiscountPrice : (decimal?)p.OriginalPrice) <= max);
        }
        if (query.InStockOnly) q = q.Where(p => p.StockQuantity > 0);

        var total = await q.CountAsync();
        var totalPages = Math.Max(1, (int)Math.Ceiling(total / (double)PageSize));
        var page = Math.Clamp(query.Page, 1, totalPages);

        IOrderedQueryable<Product> ordered = query.Sort switch
        {
            "price-asc" => q.OrderBy(p => p.DiscountPrice > 0 && p.DiscountPrice < p.OriginalPrice ? p.DiscountPrice : (decimal?)p.OriginalPrice),
            "price-desc" => q.OrderByDescending(p => p.DiscountPrice > 0 && p.DiscountPrice < p.OriginalPrice ? p.DiscountPrice : (decimal?)p.OriginalPrice),
            "popular" => q.OrderByDescending(p => p.SoldCount),
            _ => q.OrderByDescending(p => p.CreatedUtc)
        };
        var items = await ToCards(ordered.ThenByDescending(p => p.Id).Skip((page - 1) * PageSize).Take(PageSize)).ToListAsync();

        var heading = "Tất cả sản phẩm";
        if (!string.IsNullOrWhiteSpace(query.Category)) heading = (await GetCategoryAsync(query.Category))?.Name ?? heading;
        else if (!string.IsNullOrWhiteSpace(query.Q)) heading = $"Kết quả cho “{query.Q.Trim()}”";

        return new ProductListViewModel
        {
            Query = query, Heading = heading, Products = items,
            Categories = (await GetCategoriesAsync()).ToList(),
            Brands = await Active.Select(p => p.Brand).Distinct().OrderBy(b => b).ToListAsync(),
            Pager = new PagerViewModel { Page = page, TotalPages = totalPages, TotalItems = total, PageSize = PageSize }
        };
    }

    public async Task<ProductDetailViewModel?> GetProductBySlugAsync(string slug)
    {
        var p = await _db.Products.AsNoTracking().Include(x => x.Category).Include(x => x.Images).Include(x => x.Specifications)
            .FirstOrDefaultAsync(x => x.Slug == slug && x.IsActive && x.Category!.IsActive);
        if (p == null) return null;

        var related = await ToCards(Active.Where(x => x.CategoryId == p.CategoryId && x.Id != p.Id).OrderByDescending(x => x.SoldCount).Take(4)).ToListAsync();
        return new ProductDetailViewModel
        {
            Id = p.Id, Slug = p.Slug, Name = p.Name, Brand = p.Brand, CategorySlug = p.Category!.Slug, CategoryName = p.Category.Name,
            OriginalPrice = p.OriginalPrice, DiscountPrice = p.DiscountPrice, StockQuantity = p.StockQuantity,
            SoldCount = p.SoldCount, CreatedUtc = p.CreatedUtc, Description = p.Description,
            Images = p.Images.OrderByDescending(i => i.IsPrimary).ThenBy(i => i.SortOrder).Select(i => i.Path).ToList(),
            ImageUrl = p.Images.OrderByDescending(i => i.IsPrimary).ThenBy(i => i.SortOrder).Select(i => i.Path).FirstOrDefault(),
            Specifications = p.Specifications.OrderBy(s => s.SortOrder).Select(s => new KeyValuePair<string, string>(s.Name, s.Value)).ToList(),
            Related = related
        };
    }
}
