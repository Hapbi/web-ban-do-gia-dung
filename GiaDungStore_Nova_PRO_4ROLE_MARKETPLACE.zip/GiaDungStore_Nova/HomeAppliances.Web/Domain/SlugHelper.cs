using System.Globalization;
using System.Text;
using System.Text.RegularExpressions;

namespace HomeAppliances.Web.Domain;

public static class SlugHelper
{
    /// <summary>Vietnamese-aware slug: strips diacritics, maps đ to d, collapses separators.</summary>
    public static string Slugify(string? text)
    {
        if (string.IsNullOrWhiteSpace(text)) return "";
        var normalized = text.Trim().ToLowerInvariant().Replace('đ', 'd').Normalize(NormalizationForm.FormD);
        var sb = new StringBuilder();
        foreach (var ch in normalized)
        {
            if (CharUnicodeInfo.GetUnicodeCategory(ch) == UnicodeCategory.NonSpacingMark) continue;
            sb.Append(ch is >= 'a' and <= 'z' or >= '0' and <= '9' ? ch : '-');
        }
        return Regex.Replace(sb.ToString(), "-+", "-").Trim('-');
    }
}
