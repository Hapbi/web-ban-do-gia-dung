using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using HomeAppliances.Web.Infrastructure;
using HomeAppliances.Web.Models.Entities;
using HomeAppliances.Web.Models.ViewModels;
using HomeAppliances.Web.Services;

namespace HomeAppliances.Web.Areas.Admin.Controllers;

[Area("Admin"), Authorize(Policy = AppPolicies.AdminOnly)]
public class WebsiteSettingsController : Controller
{
    private readonly ISettingsService _settings;
    private readonly IAuditService _audit;
    public WebsiteSettingsController(ISettingsService settings, IAuditService audit) { _settings = settings; _audit = audit; }

    public async Task<IActionResult> Index()
    {
        var s = await _settings.GetWebsiteAsync();
        return View(new WebsiteSettingsViewModel
        {
            SiteName = s.SiteName, Tagline = s.Tagline, Introduction = s.Introduction, Address = s.Address, Phone = s.Phone, Email = s.Email, OpeningHours = s.OpeningHours,
            FacebookUrl = s.FacebookUrl, YoutubeUrl = s.YoutubeUrl, ZaloUrl = s.ZaloUrl, TiktokUrl = s.TiktokUrl,
            ShippingFee = s.ShippingFee, FreeShippingThreshold = s.FreeShippingThreshold, UnpaidOrderExpiryHours = s.UnpaidOrderExpiryHours
        });
    }

    [HttpPost]
    public async Task<IActionResult> Index(WebsiteSettingsViewModel vm)
    {
        if (!ModelState.IsValid) return View(vm);
        await _settings.SaveWebsiteAsync(new WebsiteSettings
        {
            SiteName = vm.SiteName.Trim(), Tagline = (vm.Tagline ?? "").Trim(), Introduction = (vm.Introduction ?? "").Trim(), Address = (vm.Address ?? "").Trim(), Phone = (vm.Phone ?? "").Trim(),
            Email = (vm.Email ?? "").Trim(), OpeningHours = (vm.OpeningHours ?? "").Trim(),
            FacebookUrl = vm.FacebookUrl?.Trim(), YoutubeUrl = vm.YoutubeUrl?.Trim(), ZaloUrl = vm.ZaloUrl?.Trim(), TiktokUrl = vm.TiktokUrl?.Trim(),
            ShippingFee = vm.ShippingFee, FreeShippingThreshold = vm.FreeShippingThreshold, UnpaidOrderExpiryHours = vm.UnpaidOrderExpiryHours
        });
        await _audit.LogAsync("WebsiteSettings.Update", "WebsiteSettings", "1", vm.SiteName.Trim());
        TempData["Success"] = "Đã lưu thông tin website.";
        return RedirectToAction(nameof(Index));
    }
}
