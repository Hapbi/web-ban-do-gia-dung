using Microsoft.EntityFrameworkCore;
using NovaShop.Data;
using NovaShop.Models;

namespace NovaShop.Services;

public class OrderService
{
    private readonly AppDbContext _db;
    private readonly CartService _cart;
    private readonly AuthService _auth;
    private readonly CouponService _coupons;
    private readonly NotificationService _notif;
    private readonly AuditService _audit;

    public OrderService(AppDbContext db, CartService cart, AuthService auth,
        CouponService coupons, NotificationService notif, AuditService audit)
    { _db = db; _cart = cart; _auth = auth; _coupons = coupons; _notif = notif; _audit = audit; }

    public async Task<(bool ok, string? code, string? err)> PlaceOrderAsync(CheckoutVM input)
    {
        var user = await _auth.GetCurrentAsync();
        if (user == null) return (false, null, "Vui lòng đăng nhập");

        var cart = await _cart.GetAsync(input.CouponCode);
        if (cart.IsEmpty) return (false, null, "Giỏ hàng trống");
        if (cart.HasProblems) return (false, null, "Sản phẩm vượt quá tồn kho");

        foreach (var line in cart.Lines)
        {
            var fresh = await _db.Products.FindAsync(line.Product.Id);
            if (fresh == null || fresh.Stock < line.Quantity)
                return (false, null, $"'{line.Product.Name}' chỉ còn {fresh?.Stock ?? 0} sản phẩm");
        }

        string code;
        do { code = "DH" + DateTime.Now.ToString("yyMMdd") + Guid.NewGuid().ToString("N")[..4].ToUpper(); }
        while (await _db.Orders.AnyAsync(o => o.Code == code));

        var order = new Order
        {
            Code = code, UserId = user.Id,
            CustomerName = input.CustomerName.Trim(), Phone = input.Phone.Trim(),
            Email = input.Email.Trim(), Address = input.Address.Trim(), Note = input.Note?.Trim(),
            Subtotal = cart.Subtotal, Discount = cart.Discount, CouponCode = cart.CouponCode,
            Shipping = cart.Shipping, Total = cart.Total,
            Status = OrderStatus.Pending, Payment = PaymentStatus.Unpaid,
            PaymentMethod = input.PaymentMethod, CreatedAt = DateTime.Now
        };
        order.History.Add(new OrderStatusHistory { Status = OrderStatus.Pending, Note = "Đơn được tạo", ChangedBy = "Customer" });

        foreach (var l in cart.Lines)
        {
            order.Items.Add(new OrderItem
            {
                ProductId = l.Product.Id, ProductName = l.Product.Name,
                ProductImage = l.Product.PrimaryImage, ProductSlug = l.Product.Slug,
                UnitPrice = l.Product.CurrentPrice, OriginalUnitPrice = l.Product.OriginalPrice, Quantity = l.Quantity
            });
            var p = await _db.Products.FindAsync(l.Product.Id);
            if (p != null) { p.Stock -= l.Quantity; p.SoldCount += l.Quantity; }
        }

        _db.Orders.Add(order);
        await _db.SaveChangesAsync();

        if (!string.IsNullOrWhiteSpace(cart.CouponCode)) await _coupons.IncrementUsageAsync(cart.CouponCode);
        await _cart.ClearAsync();
        await _notif.CreateAsync(user.Id, "Đặt hàng thành công",
            $"Đơn #{code} tổng {order.Total:N0}đ", $"/don-hang/{code}", "✅");

        return (true, code, null);
    }

    public async Task<List<Order>> GetMyOrdersAsync()
    {
        var uid = _auth.GetCurrentId();
        if (uid == null) return new();
        return await _db.Orders.Include(o => o.Items)
            .Where(o => o.UserId == uid.Value)
            .OrderByDescending(o => o.CreatedAt).ToListAsync();
    }

    public async Task<Order?> GetByCodeAsync(string code)
    {
        var user = await _auth.GetCurrentAsync();
        if (user == null) return null;
        return await _db.Orders.Include(o => o.Items).Include(o => o.History)
            .FirstOrDefaultAsync(o => o.Code == code &&
                (o.UserId == user.Id || user.Role == "Admin" || user.Role == "Staff"));
    }

    private async Task<(bool ok, string msg)> ChangeStatusAsync(int orderId, OrderStatus newStatus, string note, string staffName)
    {
        var o = await _db.Orders.Include(x => x.Items).FirstOrDefaultAsync(x => x.Id == orderId);
        if (o == null) return (false, "Không tìm thấy đơn");
        o.Status = newStatus;
        o.History.Add(new OrderStatusHistory { Status = newStatus, Note = note, ChangedBy = staffName });

        if (newStatus == OrderStatus.Confirmed) o.ConfirmedAt = DateTime.Now;
        if (newStatus == OrderStatus.Shipping) o.ShippedAt = DateTime.Now;
        if (newStatus == OrderStatus.Delivered) { o.DeliveredAt = DateTime.Now; o.Payment = PaymentStatus.Paid; }
        if (newStatus == OrderStatus.Cancelled)
        {
            o.CancelledAt = DateTime.Now;
            foreach (var i in o.Items)
            {
                var p = await _db.Products.FindAsync(i.ProductId);
                if (p != null) { p.Stock += i.Quantity; p.SoldCount = Math.Max(0, p.SoldCount - i.Quantity); }
            }
        }
        await _db.SaveChangesAsync();
        await _audit.LogAsync(staffName, "Order." + newStatus.ToString(), "Order", o.Id.ToString(), o.Code);
        return (true, $"Đã chuyển sang {newStatus.Label()}");
    }

    public Task<(bool ok, string msg)> ConfirmAsync(int id, string staff) => ChangeStatusAsync(id, OrderStatus.Confirmed, "Đã xác nhận", staff);
    public Task<(bool ok, string msg)> PackAsync(int id, string staff) => ChangeStatusAsync(id, OrderStatus.Packing, "Đang đóng gói", staff);
    public Task<(bool ok, string msg)> ShipAsync(int id, string staff) => ChangeStatusAsync(id, OrderStatus.Shipping, "Đang giao", staff);
    public Task<(bool ok, string msg)> DeliverAsync(int id, string staff) => ChangeStatusAsync(id, OrderStatus.Delivered, "Đã giao", staff);
    public Task<(bool ok, string msg)> CancelAsync(int id, string staff) => ChangeStatusAsync(id, OrderStatus.Cancelled, "Đã hủy", staff);

    public async Task<(bool ok, string msg)> VerifyPaymentAsync(int id, string staff, bool approve, string? note = null)
    {
        var o = await _db.Orders.FindAsync(id);
        if (o == null) return (false, "Không tìm thấy đơn");
        if (approve) { o.Payment = PaymentStatus.Paid; o.PaymentNote = note?.Trim(); }
        else { o.Payment = PaymentStatus.Unpaid; o.PaymentNote = note?.Trim() ?? "Thanh toán không hợp lệ"; }
        o.History.Add(new OrderStatusHistory
        {
            Status = o.Status,
            Note = (approve ? "Đã xác minh thanh toán" : "Từ chối thanh toán: " + note),
            ChangedBy = staff
        });
        await _db.SaveChangesAsync();
        await _audit.LogAsync(staff, "Order.VerifyPayment", "Order", o.Id.ToString(), $"{o.Code} - {(approve ? "Duyệt" : "Từ chối")}");
        return (true, approve ? "Đã xác minh thanh toán" : "Đã từ chối thanh toán");
    }
}
