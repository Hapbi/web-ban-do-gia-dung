using Microsoft.AspNetCore.Mvc;
using HomeAppliances.Web.Services;

namespace HomeAppliances.Web.ViewComponents;

public class CartCountViewComponent : ViewComponent
{
    private readonly ICartService _cart;
    public CartCountViewComponent(ICartService cart) => _cart = cart;
    public async Task<IViewComponentResult> InvokeAsync() => View(await _cart.CountAsync());
}
