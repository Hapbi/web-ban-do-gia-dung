# Gia Dụng Pro | Premium Red Edition

Website thương mại điện tử demo xây dựng bằng **ASP.NET Core 8 MVC**, **Entity Framework Core** và **SQLite**. Giao diện giữ phong cách đỏ cao cấp, glassmorphism, hiệu ứng 3D carousel, responsive desktop/mobile.

## Chạy trên Windows

1. Cài **.NET 8 SDK**: https://dotnet.microsoft.com/download/dotnet/8.0
2. Giải nén ZIP, mở PowerShell tại thư mục chứa `CuaHangGiaDungPro.csproj`.
3. Chạy lệnh:

```powershell
dotnet restore
dotnet build
dotnet run
```

4. Mở URL được hiển thị trong Terminal (thường là `http://localhost:5xxx` hoặc `https://localhost:7xxx`).

Database SQLite `giadung.db` được tạo tự động ở thư mục chạy ứng dụng trong lần khởi động đầu tiên.

## Tài khoản demo lần đầu

| Vai trò | Email | Mật khẩu |
|---|---|---|
| Quản trị | `admin@shop.vn` | `Admin@123` |
| Nhân viên | `staff@shop.vn` | `Staff@123` |
| Khách hàng | `khach@shop.vn` | `Khach@123` |

**Lưu ý:** Đây là tài khoản phục vụ chạy thử. Hãy đổi mật khẩu và cấu hình thông tin cửa hàng trước khi đưa lên môi trường thật. Không dùng dữ liệu mẫu hoặc thông tin ngân hàng mẫu cho giao dịch thật.

## Chức năng chính

- Trang chủ, banner, danh mục, danh sách sản phẩm, tìm kiếm, lọc giá theo giá bán hiện tại và sắp xếp.
- Chi tiết sản phẩm, tồn kho, yêu thích, đánh giá sau khi đơn hoàn thành và quy trình duyệt đánh giá.
- Giỏ hàng, cập nhật số lượng, kiểm tra tồn kho lại trong transaction khi đặt hàng; quản lý luồng trạng thái đơn và xác nhận thanh toán thủ công.
- Đăng ký, đăng nhập, đăng xuất, cookie authentication và phân quyền Admin/Nhân viên/Khách hàng.
- Admin: sản phẩm, danh mục, đơn hàng, người dùng, phân quyền nhân viên, banner, bài viết, cấu hình, liên hệ, nhật ký, báo cáo và xuất CSV.
- Ảnh sản phẩm có thể dùng URL hoặc tải tệp ảnh lên từ trang quản trị.

## Lưu ý kỹ thuật

- Mật khẩu mới được băm bằng PBKDF2-SHA256 với salt ngẫu nhiên. Hash SHA-256 cũ trong dữ liệu demo vẫn được xác minh và tự nâng cấp sau lần đăng nhập thành công.
- Dữ liệu mẫu chỉ được tạo khi database chưa có dữ liệu tương ứng.
- Dự án dùng `EnsureCreated` để khởi tạo database demo. Khi phát triển lâu dài, nên chuyển sang EF Core Migrations để quản lý thay đổi schema.
- Môi trường đóng gói không có .NET SDK nên chưa thể xác nhận `dotnet build` tại đây. Hãy chạy `dotnet restore` và `dotnet build` trên máy đã cài .NET 8 SDK trước khi triển khai.
