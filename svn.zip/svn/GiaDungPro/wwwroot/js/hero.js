(function () {
    "use strict";

    // ====== 1. SCALE CANVAS ======
    var canvas = document.querySelector('.hero-canvas');
    function resize() {
        if (!canvas) return;
        var vw = window.innerWidth;
        var vh = window.innerHeight;
        var W = 1172;
        var k = Math.min(vw / W, vh / 620);
        if (k > 1.3) k = 1.3;

        if (vw <= 700) {
            canvas.style.transform = 'translateX(-50%) scale(' + (vw / W) + ')';
            canvas.style.transformOrigin = '50% 0';
            return;
        }
        canvas.style.transform = 'translateX(-50%) scale(' + k + ')';
        canvas.style.setProperty('--k', k);
    }
    window.addEventListener('resize', resize);
    resize();

    // ====== 2. STARFIELD ======
    function generateStars(id, count, blur, minA, maxA) {
        var el = document.getElementById(id);
        if (!el) return;
        var shadows = [];
        for (var i = 0; i < count; i++) {
            var x = Math.random() * 100;
            var y = Math.random() * 100;
            var a = (Math.random() * (maxA - minA) + minA).toFixed(2);
            shadows.push(x + 'vw ' + y + 'vh ' + blur + 'px 0 rgba(255,255,255,' + a + ')');
        }
        el.style.boxShadow = shadows.join(',');
    }
    generateStars('stA', 180, 0, 0.05, 0.35);
    generateStars('stB', 20, 1.2, 0.4, 0.8);

    // ====== 3. 3D RING CAROUSEL ======
    var ring = document.getElementById('ring');
    if (ring) {
        var totalCards = 37;
        var radius = 891;
        var step = 360 / totalCards;
        var phase = -2;
        var cards = [];

        for (var i = 0; i < totalCards; i++) {
            var c = document.createElement('div');
            c.className = 'card';
            var imgUrl = (typeof listImg !== 'undefined' && listImg.length > 0)
                ? listImg[i % listImg.length]
                : '/images/san-pham-mac-dinh.svg';
            c.innerHTML = '<img src="' + imgUrl + '" alt="" onerror="this.src=\'/images/san-pham-mac-dinh.svg\'"><div class="edge"></div>';
            ring.appendChild(c);
            cards.push(c);
        }

        function renderRing() {
            cards.forEach(function (c, idx) {
                var a = ((idx * step + phase) % 360 + 540) % 360 - 180;
                if (Math.abs(a) > 42) {
                    c.style.visibility = 'hidden';
                } else {
                    c.style.visibility = 'visible';
                    var r = a * Math.PI / 180;
                    var cos = Math.cos(r);
                    var sin = Math.sin(r);
                    var z = radius * (1 - cos);
                    var x = radius * sin;
                    c.style.transform = 'translate3d(' + x + 'px, 0, ' + z + 'px) rotateY(' + (-a) + 'deg)';
                    c.style.filter = 'brightness(' + (0.84 + 0.5 * (1 / cos - 1)) + ')';
                }
            });
        }

        var last = performance.now();
        function tick(t) {
            var dt = Math.min((t - last) / 1000, 0.1);
            last = t;
            phase -= 1.9 * dt;
            renderRing();
            requestAnimationFrame(tick);
        }
        requestAnimationFrame(tick);
    }

    // ====== 4. PARALLAX MOUSE ======
    document.addEventListener('mousemove', function (e) {
        if (!canvas || window.innerWidth <= 900) return;
        var mx = (e.clientX / window.innerWidth - 0.5) * 10;
        var my = (e.clientY / window.innerHeight - 0.5) * 10;
        var ringEl = document.getElementById('ring');
        if (ringEl) {
            ringEl.style.marginLeft = mx + 'px';
            ringEl.style.marginTop = my + 'px';
        }
    });
})();
