# Test cases and results

**How to read the status column.** Results are recorded honestly:

* **Pass** - executed. Only the *Automated unit* tests could be executed in the authoring environment: 69 tests, 69 passed, 0 failed (`docs/unit-test-results.txt`).
* **Not run** - the test exists (automated) or is described (manual) but has not been executed. The authoring environment could not download the NuGet packages for EF Core, SQLite or ASP.NET integration testing, so the SQLite/`WebApplicationFactory` tests were compile-checked against stand-ins only. Run `dotnet test` and record the real results in the *Actual result* column.
* **Manual** cases need a browser and SQL Server; fill in *Actual result* and *Status* when you perform them.

Application-level checks that WERE performed in the authoring environment (against stand-in packages, no database): full compile of the solution and tests; application start-up with .NET's complete dependency-injection validation; every protected URL redirects an anonymous user to login; every state-changing POST without an anti-forgery token returns 400; security headers present; no ambiguous routes.

Re-run after every bug fix (regression): `dotnet test`, then repeat the manual cases that touch the changed module.

| ID | Module | Precondition | Input | Expected result | Type | Actual result | Status |
|---|---|---|---|---|---|---|---|
| AUTH-01 | Registration | Visitor, no account | Valid name, new e-mail, phone 0912345678, password Abcdefg1 x2 | Account created, Customer role, signed in (or asked to confirm e-mail if SMTP on) | Manual |  | Not run |
| AUTH-02 | Registration | Account dup@x exists | Register dup@x again | Page re-shown with 'Email này đã được đăng ký'; no second account | Automated integration (written, not run) |  | Not run |
| AUTH-03 | Registration | - | Empty fields / bad e-mail / phone 123 / password 'abc' / mismatch | Vietnamese validation messages next to each field; nothing created | Manual |  | Not run |
| AUTH-04 | Login | Customer account | Correct e-mail + password | Signed in, redirected home (or to ReturnUrl) | Automated integration (written, not run) |  | Not run |
| AUTH-05 | Login | - | Wrong password 5 times | Generic error, then 'tạm thời bị khóa' for 15 minutes | Manual |  | Not run |
| AUTH-06 | Login | Deactivated account | Correct password | Message that the account is deactivated; no session | Manual |  | Not run |
| AUTH-07 | Login | - | Click show/hide on password, tick remember-me | Password toggles; persistent cookie issued | Manual |  | Not run |
| AUTH-08 | Logout | Signed in | Click Đăng xuất | Signed out; /tai-khoan redirects to login | Manual |  | Not run |
| AUTH-09 | Forgot password | Known e-mail and unknown e-mail | Submit each | Identical confirmation page for both (no account enumeration) | Automated integration (written, not run) |  | Not run |
| AUTH-10 | Reset password | Valid link <2h | Set new compliant password | Password changed; old password rejected; link cannot be reused | Manual |  | Not run |
| AUTH-11 | Reset password | Tampered / expired link | Submit | 'Liên kết đã hết hạn hoặc không hợp lệ' | Manual |  | Not run |
| AUTH-12 | Anti-forgery | - | POST /lien-he without token | HTTP 400 | Automated integration (written, not run) |  | Not run |
| ACL-01 | Authorization | Anonymous | GET /Admin, /Admin/Users, /Employee/Orders, /don-hang, /tai-khoan, /thanh-toan | 302 to /dang-nhap with ReturnUrl | Automated integration (written, not run) |  | Not run |
| ACL-02 | Authorization | Customer signed in | GET /Admin/*, /Employee/* | 302 to /khong-co-quyen | Automated integration (written, not run) |  | Not run |
| ACL-03 | Authorization | Employee signed in | GET /Admin/Products, /Admin/Users, /Admin/BankSettings | 302 to /khong-co-quyen | Automated integration (written, not run) |  | Not run |
| ACL-04 | Authorization | Employee WITHOUT verify permission | POST /Employee/Orders/Approve/1 directly | Forbidden (redirect to access denied); no state change | Automated integration (written, not run) |  | Not run |
| ACL-05 | Authorization policy | - | Evaluate CanVerifyPayments for Admin / Employee / Employee+claim / Customer+claim / anonymous | true / false / true / false / false | Automated unit (run) | 69/69 unit tests passed | Pass |
| ACL-06 | Data isolation | Customers A and B, B has order | A opens /don-hang/{B order} and B's proof URL | 404 for both; owner gets 200 | Automated integration (written, not run) |  | Not run |
| ACL-07 | Data isolation | Same | GetCustomerOrder / list for the wrong user | null / empty list | Automated integration (written, not run) |  | Not run |
| ACL-08 | Roles | Admin | Edit own account: change role or deactivate | Refused with explanation | Manual |  | Not run |
| ACL-09 | Roles | Only one active admin | Demote or deactivate that admin | Refused: at least one active admin must remain | Manual |  | Not run |
| ACL-10 | Roles | Employee granted permission | Admin ticks 'verify payments' | Employee can approve; signed out of old sessions first | Manual |  | Not run |
| CAT-01 | Product list | Sample data | Open /san-pham | 12 products/page, pagination, 24 items = 2 pages | Manual |  | Not run |
| CAT-02 | Search | - | q=tu lanh (no diacritics) and q=Tủ lạnh | Both find refrigerators | Manual |  | Not run |
| CAT-03 | Filter | - | category, brand, min/max price, in-stock only | Result set matches all filters; price uses sale price | Manual |  | Not run |
| CAT-04 | Sort | - | price-asc, price-desc, popular, newest | Order correct and stable | Manual |  | Not run |
| CAT-05 | Detail | Product with images/specs | Open product | Gallery, price, stock label, specs, 4 related items | Manual |  | Not run |
| CAT-06 | Slug | - | Slugify 'Tủ lạnh Inverter 2 cánh 450 lít' | tu-lanh-inverter-2-canh-450-lit | Automated unit (run) | 69/69 unit tests passed | Pass |
| CAT-07 | Product CRUD | Admin | Create with 2 images, edit price, deactivate, reactivate | Saved; inactive product disappears from storefront | Manual |  | Not run |
| CAT-08 | Product CRUD | Product in an order | Delete it | Refused; advised to deactivate | Automated integration (written, not run) |  | Not run |
| CAT-09 | Product validation | Admin | Sale price >= price; stock -1; missing name | Server-side validation messages; nothing saved | Manual |  | Not run |
| CAT-10 | Category | Category has products | Delete it | Refused; empty category deletes OK | Manual |  | Not run |
| CAT-11 | Images | Admin | Upload .jpg that is really HTML; 3 MB image; .gif | All rejected with message | Automated unit (run) | 69/69 unit tests passed | Pass |
| CART-01 | Cart | Guest | Add product x2 twice | One line, quantity 4 | Manual |  | Not run |
| CART-02 | Cart | Stock 3 | Add 5 | Refused: only 3 available | Manual |  | Not run |
| CART-03 | Cart | Guest cart with items | Log in | Guest cart merged into saved cart, never above stock | Manual |  | Not run |
| CART-04 | Cart | - | Update quantity, remove line, clear (confirm dialog) | Totals recalculated on server | Manual |  | Not run |
| CART-05 | Cart | Price changed by admin after adding | Open cart | Shows current price, not the old one | Manual |  | Not run |
| CART-06 | Totals | - | Subtotal 2.5m, discount 0.4m, shipping 30k | Total 2.130.000 ₫ | Automated unit (run) | 69/69 unit tests passed | Pass |
| CART-07 | Totals | - | Merchandise after discount reaches the free-shipping threshold | Shipping 0 | Automated unit (run) | 69/69 unit tests passed | Pass |
| CART-08 | Totals | - | Empty cart; sale price above list price; quantity <= 0 | 0; list price charged; ignored | Automated unit (run) | 69/69 unit tests passed | Pass |
| ORD-01 | Checkout | Customer, cart not empty | Valid name/phone/address | Order created PendingPayment, number DHyyMMdd####, stock reduced, cart emptied, redirected to order page with QR | Automated integration (written, not run) |  | Not run |
| ORD-02 | Checkout | Qty exceeds stock | Place order | Refused; stock and orders unchanged | Automated integration (written, not run) |  | Not run |
| ORD-03 | Checkout | One unit left, two buyers | Both place order | Exactly one succeeds; stock never negative | Automated integration (written, not run) |  | Not run |
| ORD-04 | Checkout | Price edited after ordering | View order | Order keeps the price paid | Automated integration (written, not run) |  | Not run |
| ORD-05 | Checkout | - | Phone '123', address 'a' | Validation messages | Manual |  | Not run |
| ORD-06 | Order number | - | Generate 500 numbers | Shape DHyyMMdd + 4 chars, practically unique | Automated unit (run) | 69/69 unit tests passed | Pass |
| ORD-07 | Cancellation | Unpaid order | Customer cancels with reason, then again | First OK and stock returned; second refused; stock restored once | Automated integration (written, not run) |  | Not run |
| ORD-08 | Cancellation | Paid order | Customer / employee tries; admin cancels | Refused / refused / OK with stock and sales count restored | Automated integration (written, not run) |  | Not run |
| ORD-09 | Cancellation | Another customer's order | Cancel by id | Refused | Automated integration (written, not run) |  | Not run |
| ORD-10 | Expiry | Unpaid order older than limit | Run cleanup | Cancelled, stock released; newer order untouched | Automated integration (written, not run) |  | Not run |
| PAY-01 | QR display | Bank settings + QR uploaded | Open unpaid order | Admin's QR image, bank details, amount, exact transfer note shown | Manual |  | Not run |
| PAY-02 | QR display | No QR uploaded | Open unpaid order | Bank details shown with notice; no fake QR | Manual |  | Not run |
| PAY-03 | Proof upload | Unpaid order | Upload PNG receipt | Status Chờ xác minh; NOT paid; proof stored privately | Automated integration (written, not run) |  | Not run |
| PAY-04 | Proof upload | - | Upload PDF / renamed .exe / 6 MB image | Rejected | Automated unit (run) | 69/69 unit tests passed | Pass |
| PAY-05 | Proof access | Proof exists | Open proof URL as owner / reviewer / other customer / anonymous | 200 / 200 / 404 / login redirect | Automated integration (written, not run) |  | Not run |
| PAY-06 | Approval | Pending proof, authorized staff | Approve twice | First: Paid with PaidUtc; second refused; sales count increased once | Automated integration (written, not run) |  | Not run |
| PAY-07 | Approval | No proof uploaded | Approve | Refused | Automated integration (written, not run) |  | Not run |
| PAY-08 | Approval | Customer role | Approve | Refused | Automated integration (written, not run) |  | Not run |
| PAY-09 | Rejection | Pending proof | Reject with empty reason, then with reason | Refused, then PaymentRejected; customer sees reason and can re-upload | Automated integration (written, not run) |  | Not run |
| PAY-10 | Replacement | Pending proof | Upload second proof | Previous proof marked superseded; still pending | Manual |  | Not run |
| PAY-11 | Settings | Admin | Save bank settings without {OrderNumber} in format | Validation error | Manual |  | Not run |
| WF-01 | State machine | - | Normal flow transitions per role | Allowed | Automated unit (run) | 69/69 unit tests passed | Pass |
| WF-02 | State machine | - | Skip steps (Pending→Paid, Paid→Shipped, Delivered→Cancelled...) | Rejected | Automated unit (run) | 69/69 unit tests passed | Pass |
| WF-03 | State machine | - | Customer cancel rules; admin-only cancel of paid orders | As specified | Automated unit (run) | 69/69 unit tests passed | Pass |
| WF-04 | Fulfilment | Paid order | Employee: Processing → Shipped → Delivered | Each step stored in history with user and time | Automated integration (written, not run) |  | Not run |
| WF-05 | Fulfilment | Unpaid order | Employee tries to ship | Refused | Automated integration (written, not run) |  | Not run |
| WF-06 | Staff orders | Mixed orders | Filter by number, status, dates; paginate | Correct subsets | Manual |  | Not run |
| WF-07 | Tracking | Order with phone 0912345678 | Number + phone (also +84 912 345 678); wrong phone; unknown number | Timeline shown / identical 'not found' for wrong inputs | Automated integration (written, not run) |  | Not run |
| WF-08 | Phone normalisation | - | +84912345678, 0912 345 678, 84912345678 | 0912345678 | Automated unit (run) | 69/69 unit tests passed | Pass |
| REP-01 | Revenue | Orders in 6 states | Sales report | Revenue counts only Paid..Delivered | Automated integration (written, not run) |  | Not run |
| REP-02 | Dashboard | - | Open admin dashboard on SQL Server | Totals, pending, low stock, unread messages | Manual |  | Not run |
| REP-03 | Audit | - | Approve payment, edit product, change role | Entries in /Admin/AuditLogs with user, time, IP | Manual |  | Not run |
| REP-04 | Banners | Admin | Add banner with image, link 'javascript:...' | Image shown on home; unsafe link rejected | Manual |  | Not run |
| REP-05 | Website info | Admin | Change shop name/phone/social URL | Header and footer update (within 5 min cache or immediately after save) | Manual |  | Not run |
| REP-06 | Contact | Visitor | Send contact form | Stored; visible in Admin > Messages | Manual |  | Not run |
| UI-01 | Formatting | - | Format 12490000, 1000, 950, 1000.5 | 12.490.000 ₫, 1.000 ₫, 950 ₫, 1.001 ₫ | Automated unit (run) | 69/69 unit tests passed | Pass |
| UI-02 | Responsive | Phone, tablet, desktop widths | Browse, cart, checkout, admin tables | No horizontal page scroll; menus collapse; tables stack | Manual |  | Not run |
| UI-03 | Accessibility | Keyboard only | Tab through header, forms, filters | Visible focus, skip link, labelled controls | Manual |  | Not run |
| UI-04 | Public pages | - | Open /, /san-pham, /gioi-thieu, /lien-he, /hoi-dap, policies, 404 | All load; 404 shows friendly page | Automated integration (written, not run) |  | Not run |
| UI-05 | Security headers | - | Inspect response headers | nosniff, frame deny, referrer policy (+CSP in Production) | Automated integration (written, not run) |  | Not run |
