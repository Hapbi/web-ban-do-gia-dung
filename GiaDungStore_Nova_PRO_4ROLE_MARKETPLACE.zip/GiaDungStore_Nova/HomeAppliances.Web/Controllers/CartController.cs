using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Authorization;
using HomeAppliances.Web.Services;

namespace HomeAppliances.Web.Controllers;

/// <summary>Shopping cart. Guests use the session, signed-in users a saved cart; the browser only sends product ids and quantities.</summary>
[Route("gio-hang")]
public class CartController : Controller
{
    private readonly ICartService _cart;
    public CartController(ICartService cart) => _cart = cart;

    private bool IsAjax => Request.Headers["X-Requested-With"] == "XMLHttpRequest";

    [HttpGet("")]
    public async Task<IActionResult> Index() => View(await _cart.GetAsync());

    [HttpPost("them")]
    public async Task<IActionResult> Add(int productId, int quantity = 1, string? returnUrl = null, bool buyNow = false)
    {
        // Marketplace rule: anonymous visitors may browse, but adding to cart requires an account.
        if (User.Identity?.IsAuthenticated != true)
        {
            var login = Url.Action("Login", "Account", new { returnUrl = returnUrl ?? Request.Path });
            if (IsAjax) return Unauthorized(new { ok = false, requiresLogin = true, loginUrl = login, message = "Bạn cần đăng ký/đăng nhập để thêm sản phẩm vào giỏ." });
            TempData["Error"] = "Vui lòng đăng ký hoặc đăng nhập trước khi thêm sản phẩm vào giỏ.";
            return Redirect(login!);
        }
        var r = await _cart.AddAsync(productId, quantity);
        if (IsAjax) return Json(new { ok = r.Succeeded, message = r.Succeeded ? "Đã thêm vào giỏ hàng." : r.Error, count = await _cart.CountAsync() });
        if (r.Succeeded) TempData["Success"] = "Đã thêm sản phẩm vào giỏ hàng.";
        else TempData["Error"] = r.Error;
        if (buyNow && r.Succeeded) return RedirectToAction(nameof(Index));
        return Url.IsLocalUrl(returnUrl) ? LocalRedirect(returnUrl!) : RedirectToAction(nameof(Index));
    }

    [HttpPost("cap-nhat")]
    public async Task<IActionResult> Update(int productId, int quantity)
    {
        var r = await _cart.SetQuantityAsync(productId, quantity);
        if (!r.Succeeded) TempData["Error"] = r.Error; else TempData["Success"] = "Đã cập nhật giỏ hàng.";
        return RedirectToAction(nameof(Index));
    }

    [HttpPost("xoa")]
    public async Task<IActionResult> Remove(int productId)
    {
        await _cart.RemoveAsync(productId);
        TempData["Success"] = "Đã xóa sản phẩm khỏi giỏ hàng.";
        return RedirectToAction(nameof(Index));
    }

    [HttpPost("xoa-het")]
    public async Task<IActionResult> Clear()
    {
        await _cart.ClearAsync();
        TempData["Success"] = "Đã xóa toàn bộ giỏ hàng.";
        return RedirectToAction(nameof(Index));
    }
}
