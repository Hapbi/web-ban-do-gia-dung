namespace HomeAppliances.Web.Domain;

public record UploadCheck(bool Ok, string? Error, string Extension)
{
    public static UploadCheck Fail(string error) => new(false, error, "");
}

/// <summary>
/// Validates an uploaded image by size, declared extension AND the file's real signature
/// (magic bytes), so a renamed script or HTML file is rejected. Returns a safe extension to use.
/// </summary>
public static class UploadValidator
{
    public const int HeaderLength = 16;

    public static UploadCheck Validate(string? fileName, long length, byte[] header, long maxBytes, bool allowGif = false)
    {
        if (length <= 0) return UploadCheck.Fail("Tệp rỗng.");
        if (length > maxBytes) return UploadCheck.Fail($"Tệp quá lớn (tối đa {maxBytes / 1024 / 1024.0:0.#} MB).");

        var declared = Path.GetExtension(fileName ?? "").ToLowerInvariant();
        var detected = Detect(header);
        if (detected == null || (detected == ".gif" && !allowGif))
            return UploadCheck.Fail("Chỉ chấp nhận ảnh JPG, PNG hoặc WEBP.");

        var declaredOk = detected switch
        {
            ".jpg" => declared is ".jpg" or ".jpeg",
            _ => declared == detected
        };
        if (!declaredOk) return UploadCheck.Fail("Phần mở rộng tệp không khớp với nội dung ảnh.");

        return new UploadCheck(true, null, detected);
    }

    /// <summary>Returns ".jpg", ".png", ".gif", ".webp" or null when the signature is not a supported image.</summary>
    public static string? Detect(byte[] h)
    {
        if (h.Length >= 3 && h[0] == 0xFF && h[1] == 0xD8 && h[2] == 0xFF) return ".jpg";
        if (h.Length >= 8 && h[0] == 0x89 && h[1] == 0x50 && h[2] == 0x4E && h[3] == 0x47 && h[4] == 0x0D && h[5] == 0x0A && h[6] == 0x1A && h[7] == 0x0A) return ".png";
        if (h.Length >= 6 && h[0] == 'G' && h[1] == 'I' && h[2] == 'F' && h[3] == '8') return ".gif";
        if (h.Length >= 12 && h[0] == 'R' && h[1] == 'I' && h[2] == 'F' && h[3] == 'F' && h[8] == 'W' && h[9] == 'E' && h[10] == 'B' && h[11] == 'P') return ".webp";
        return null;
    }
}
