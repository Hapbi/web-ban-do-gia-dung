using System.ComponentModel.DataAnnotations;
using Microsoft.EntityFrameworkCore;

namespace HomeAppliances.Web.Models.Entities;

[Index(nameof(Slug), IsUnique = true)]
public class Category
{
    public int Id { get; set; }
    [MaxLength(100)] public string Name { get; set; } = "";
    [MaxLength(120)] public string Slug { get; set; } = "";
    [MaxLength(500)] public string? Description { get; set; }
    public int DisplayOrder { get; set; }
    public bool IsActive { get; set; } = true;
    public List<Product> Products { get; set; } = new();
}

[Index(nameof(Slug), IsUnique = true)]
[Index(nameof(CategoryId), nameof(IsActive))]
public class Product
{
    public int Id { get; set; }
    [MaxLength(200)] public string Name { get; set; } = "";
    [MaxLength(220)] public string Slug { get; set; } = "";
    public string Description { get; set; } = "";
    [MaxLength(100)] public string Brand { get; set; } = "";
    public int CategoryId { get; set; }
    public Category? Category { get; set; }
    [Precision(18, 0)] public decimal OriginalPrice { get; set; }
    [Precision(18, 0)] public decimal? DiscountPrice { get; set; }
    public int StockQuantity { get; set; }
    public int SoldCount { get; set; }
    public bool IsFeatured { get; set; }
    public bool IsActive { get; set; } = true;
    /// <summary>Null for store-owned catalog products; populated for customer marketplace listings.</summary>
    [MaxLength(450)] public string? OwnerUserId { get; set; }
    public ApplicationUser? OwnerUser { get; set; }
    public bool IsMarketplaceListing { get; set; }
    /// <summary>0 = pending moderation, 1 = approved, 2 = rejected.</summary>
    public int ListingStatus { get; set; } = 1;
    public decimal PlatformFeeRate { get; set; } = 0.07m;
    public DateTime CreatedUtc { get; set; } = DateTime.UtcNow;
    public DateTime UpdatedUtc { get; set; } = DateTime.UtcNow;
    public List<ProductImage> Images { get; set; } = new();
    public List<ProductSpecification> Specifications { get; set; } = new();

    /// <summary>Sale price when valid (0 &lt; sale &lt; original), otherwise the original price.</summary>
    public decimal CurrentPrice => DiscountPrice is > 0 && DiscountPrice < OriginalPrice ? DiscountPrice.Value : OriginalPrice;
}

public class ProductImage
{
    public int Id { get; set; }
    public int ProductId { get; set; }
    public Product? Product { get; set; }
    /// <summary>Web path such as /uploads/products/abc.jpg</summary>
    [MaxLength(300)] public string Path { get; set; } = "";
    public bool IsPrimary { get; set; }
    public int SortOrder { get; set; }
}

public class ProductSpecification
{
    public int Id { get; set; }
    public int ProductId { get; set; }
    public Product? Product { get; set; }
    [MaxLength(100)] public string Name { get; set; } = "";
    [MaxLength(500)] public string Value { get; set; } = "";
    public int SortOrder { get; set; }
}
