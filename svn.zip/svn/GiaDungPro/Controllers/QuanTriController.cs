using CuaHangGiaDungPro.Data;
using CuaHangGiaDungPro.Helpers;
using CuaHangGiaDungPro.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace CuaHangGiaDungPro.Controllers;

[Authorize(Roles = "Admin,NhanVien")]
public partial class QuanTriController : Controller
{
    private readonly AppDb _db;
    private readonly IWebHostEnvironment _env;
    public QuanTriController(AppDb db, IWebHostEnvironment env)
    {
        _db = db; _env = env;
    }

    void GhiNhatKy(string hanhDong, string chiTiet)
    {
        _db.NhatKys.Add(new NhatKy
        {
            NguoiDung = User.Identity?.Name ?? "",
            HanhDong = hanhDong, ChiTiet = chiTiet
        });
    }

    [Route("quan-tri")]
    public async Task<IActionResult> Dashboard()
    {
        if (!QuyenHelper.CoQuyen(User, "baocao"))
        {
            if (QuyenHelper.CoQuyen(User, "sanpham")) return RedirectToAction(nameof(SanPham));
            if (QuyenHelper.CoQuyen(User, "donhang")) return RedirectToAction(nameof(DonHang));
            if (QuyenHelper.CoQuyen(User, "danhgia")) return RedirectToAction(nameof(DanhGia));
            return Forbid();
        }
        var homNay = DateTime.Today;
        var donHangs = await _db.DonHangs.Include(x => x.ChiTiet).ToListAsync();
        var sps = await _db.SanPhams.ToListAsync();

        var daThanhToan = donHangs.Where(x =>
            x.ThanhToan == ThanhToan.DaThanhToan ||
            (x.TrangThai == TrangThaiDon.HoanThanh && x.PhuongThucThanhToan == PhuongThucThanhToan.COD)).ToList();

        ViewBag.DoanhThuHomNay = daThanhToan.Where(x => x.NgayTao.Date == homNay).Sum(x => x.TongTien);
        ViewBag.DoanhThuThang  = daThanhToan.Where(x => x.NgayTao.Month == homNay.Month && x.NgayTao.Year == homNay.Year).Sum(x => x.TongTien);
        ViewBag.SoDonChoXacNhan = donHangs.Count(x => x.TrangThai == TrangThaiDon.ChoXacNhan);
        ViewBag.SoDonDangGiao   = donHangs.Count(x => x.TrangThai == TrangThaiDon.DangGiao);
        ViewBag.SoDonHoanThanh  = donHangs.Count(x => x.TrangThai == TrangThaiDon.HoanThanh);
        ViewBag.SoDonDaHuy      = donHangs.Count(x => x.TrangThai == TrangThaiDon.DaHuy);
        ViewBag.TongDon         = donHangs.Count;
        ViewBag.TongSanPham     = sps.Count;
        ViewBag.SanPhamSapHet   = sps.Where(x => x.TonKho > 0 && x.TonKho <= 5).OrderBy(x => x.TonKho).Take(5).ToList();
        ViewBag.SanPhamHetHang  = sps.Where(x => x.TonKho <= 0).OrderBy(x => x.Ten).Take(5).ToList();
        ViewBag.DonMoiNhat      = donHangs.OrderByDescending(x => x.NgayTao).Take(6).ToList();

        return View();
    }

    [Route("quan-tri/san-pham")]
    public async Task<IActionResult> SanPham(string? q)
    {
        if (!QuyenHelper.CoQuyen(User, "sanpham")) return Forbid();
        var query = _db.SanPhams.Include(x => x.DanhMuc).AsQueryable();
        if (!string.IsNullOrWhiteSpace(q)) query = query.Where(x => x.Ten.Contains(q.Trim()));
        ViewBag.Q = q;
        return View(await query.OrderByDescending(x => x.Id).ToListAsync());
    }

    [HttpGet, Route("quan-tri/san-pham/them")]
    [HttpGet, Route("quan-tri/san-pham/{id:int}/sua")]
    public async Task<IActionResult> SuaSanPham(int? id)
    {
        if (!QuyenHelper.CoQuyen(User, "sanpham")) return Forbid();
        ViewBag.DanhMucs = await _db.DanhMucs.ToListAsync();
        if (id == null) return View(new SanPham { DangBan = true });
        var sp = await _db.SanPhams.FindAsync(id);
        if (sp == null) return NotFound();
        return View(sp);
    }

    [HttpPost, Route("quan-tri/san-pham/luu")]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> LuuSanPham(SanPham input, IFormFile? anhFile)
    {
        if (!QuyenHelper.CoQuyen(User, "sanpham")) return Forbid();

        if (string.IsNullOrWhiteSpace(input.Ten) || input.GiaGoc <= 0 || input.TonKho < 0
            || !await _db.DanhMucs.AnyAsync(x => x.Id == input.DanhMucId))
        {
            TempData["Loi"] = "Vui lòng nhập tên, chọn danh mục hợp lệ, giá > 0 và tồn kho >= 0";
            ViewBag.DanhMucs = await _db.DanhMucs.ToListAsync();
            return View("SuaSanPham", input);
        }

        SanPham sp;
        if (input.Id == 0) { sp = new SanPham(); _db.SanPhams.Add(sp); }
        else
        {
            sp = await _db.SanPhams.FindAsync(input.Id);
            if (sp == null) return NotFound();
        }

        if (anhFile != null && anhFile.Length > 0)
        {
            var ext = Path.GetExtension(anhFile.FileName).ToLowerInvariant();
            var choPhep = new[] { ".jpg", ".jpeg", ".png", ".webp", ".gif" };
            if (!choPhep.Contains(ext))
            {
                TempData["Loi"] = "Chỉ chấp nhận ảnh JPG/PNG/WEBP/GIF";
                ViewBag.DanhMucs = await _db.DanhMucs.ToListAsync();
                return View("SuaSanPham", input);
            }
            if (anhFile.Length > 5 * 1024 * 1024)
            {
                TempData["Loi"] = "Ảnh tối đa 5MB";
                ViewBag.DanhMucs = await _db.DanhMucs.ToListAsync();
                return View("SuaSanPham", input);
            }
            var header = new byte[12];
            using (var imageStream = anhFile.OpenReadStream())
                _ = await imageStream.ReadAsync(header.AsMemory(0, header.Length));
            var anhHopLe = ext switch
            {
                ".jpg" or ".jpeg" => header[0] == 0xFF && header[1] == 0xD8 && header[2] == 0xFF,
                ".png" => header[0] == 0x89 && header[1] == 0x50 && header[2] == 0x4E && header[3] == 0x47,
                ".gif" => System.Text.Encoding.ASCII.GetString(header, 0, 3) == "GIF",
                ".webp" => System.Text.Encoding.ASCII.GetString(header, 0, 4) == "RIFF"
                    && System.Text.Encoding.ASCII.GetString(header, 8, 4) == "WEBP",
                _ => false
            };
            if (!anhHopLe)
            {
                TempData["Loi"] = "Nội dung tệp không phải ảnh hợp lệ hoặc phần mở rộng không khớp.";
                ViewBag.DanhMucs = await _db.DanhMucs.ToListAsync();
                return View("SuaSanPham", input);
            }
            var thuMuc = Path.Combine(_env.WebRootPath, "uploads", "san-pham");
            Directory.CreateDirectory(thuMuc);
            var tenMoi = Guid.NewGuid().ToString("N") + ext;
            using (var fs = System.IO.File.Create(Path.Combine(thuMuc, tenMoi)))
                await anhFile.CopyToAsync(fs);
            sp.AnhChinh = "/uploads/san-pham/" + tenMoi;
        }
        else if (!string.IsNullOrWhiteSpace(input.AnhChinh))
        {
            var anh = input.AnhChinh.Trim();
            if (!((anh.StartsWith("/", StringComparison.Ordinal) && !anh.StartsWith("//", StringComparison.Ordinal)) ||
                  (Uri.TryCreate(anh, UriKind.Absolute, out var uriAnh) &&
                   (uriAnh.Scheme == Uri.UriSchemeHttp || uriAnh.Scheme == Uri.UriSchemeHttps))))
            {
                TempData["Loi"] = "Đường dẫn ảnh phải là đường dẫn nội bộ hoặc URL HTTP/HTTPS hợp lệ.";
                ViewBag.DanhMucs = await _db.DanhMucs.ToListAsync();
                return View("SuaSanPham", input);
            }
            sp.AnhChinh = anh;
        }

        sp.Ten = input.Ten.Trim();
        sp.MoTa = input.MoTa?.Trim() ?? "";
        sp.ThongSo = input.ThongSo?.Trim() ?? "";
        sp.GiaGoc = input.GiaGoc;
        sp.GiaKhuyenMai = input.GiaKhuyenMai > 0 && input.GiaKhuyenMai < input.GiaGoc ? input.GiaKhuyenMai : null;
        sp.TonKho = input.TonKho;
        sp.DanhMucId = input.DanhMucId;
        sp.DangBan = input.DangBan;
        sp.NoiBat = input.NoiBat;

        GhiNhatKy(input.Id == 0 ? "Thêm sản phẩm" : "Sửa sản phẩm", sp.Ten);
        await _db.SaveChangesAsync();
        TempData["ThanhCong"] = input.Id == 0 ? "Đã thêm sản phẩm" : "Đã cập nhật sản phẩm";
        return RedirectToAction(nameof(SanPham));
    }

    [HttpPost, Route("quan-tri/san-pham/{id:int}/xoa")]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> XoaSanPham(int id)
    {
        if (!QuyenHelper.CoQuyen(User, "sanpham")) return Forbid();
        var sp = await _db.SanPhams.FindAsync(id);
        if (sp != null)
        {
            sp.DangBan = false;
            GhiNhatKy("Ẩn sản phẩm", sp.Ten);
            await _db.SaveChangesAsync();
            TempData["ThanhCong"] = "Đã ẩn sản phẩm";
        }
        return RedirectToAction(nameof(SanPham));
    }

    [HttpPost, Route("quan-tri/san-pham/{id:int}/hien")]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> HienSanPham(int id)
    {
        if (!QuyenHelper.CoQuyen(User, "sanpham")) return Forbid();
        var sp = await _db.SanPhams.FindAsync(id);
        if (sp != null)
        {
            sp.DangBan = !sp.DangBan;
            await _db.SaveChangesAsync();
            TempData["ThanhCong"] = "Đã đổi trạng thái";
        }
        return RedirectToAction(nameof(SanPham));
    }
}
