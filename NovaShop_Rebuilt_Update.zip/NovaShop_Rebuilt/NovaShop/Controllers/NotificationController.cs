using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using NovaShop.Services;

namespace NovaShop.Controllers;

public class NotificationController : Controller
{
    private readonly NotificationService _notif;
    private readonly AuthService _auth;
    public NotificationController(NotificationService notif, AuthService auth) { _notif = notif; _auth = auth; }

    [Authorize, Route("thong-bao")]
    public async Task<IActionResult> Index()
    {
        var uid = _auth.GetCurrentId();
        if (uid == null) return Challenge();
        var list = await _notif.GetRecentAsync(uid.Value, 50);
        await _notif.MarkAllReadAsync(uid.Value);
        return View(list);
    }

    [Authorize, HttpPost, Route("thong-bao/danh-dau-da-doc")]
    public async Task<IActionResult> MarkRead()
    {
        var uid = _auth.GetCurrentId();
        if (uid == null) return Unauthorized();
        await _notif.MarkAllReadAsync(uid.Value);
        return Ok(new { ok = true });
    }

    [HttpGet, Route("api/thong-bao/dem")]
    public async Task<IActionResult> UnreadCount()
    {
        var uid = _auth.GetCurrentId();
        if (uid == null) return Json(new { count = 0 });
        return Json(new { count = await _notif.UnreadCountAsync(uid.Value) });
    }
}
