namespace NovaShop.Helpers;

// Hệ thống ảnh: MỖI sản phẩm có ảnh KHÁC NHAU.
// - Index 0,1 trong mỗi danh mục: dùng Unsplash đã kiểm tra (đúng loại sản phẩm)
// - Index >= 2: dùng picsum với seed duy nhất (ảnh thật, luôn chạy, khác nhau)
// - Ảnh bìa hero: Unsplash chất lượng cao
public static class Images
{
    static readonly Dictionary<string, string[]> ByCategory = new()
    {
        ["tu-lanh"] = new[] {
            "https://images.unsplash.com/photo-1571175443880-49e1d25b2bc5?w=800&q=80&auto=format&fit=crop",
            "https://images.unsplash.com/photo-1584568694244-14fbdf83bd30?w=800&q=80&auto=format&fit=crop",
        },
        ["may-giat"] = new[] {
            "https://images.unsplash.com/photo-1626806787461-102c1bfaaea1?w=800&q=80&auto=format&fit=crop",
            "https://images.unsplash.com/photo-1610557892470-55d9e80c0bce?w=800&q=80&auto=format&fit=crop",
        },
        ["dieu-hoa"] = new[] {
            "https://images.unsplash.com/photo-1631545806609-8d3c9c8c8c7a?w=800&q=80&auto=format&fit=crop",
        },
        ["noi-com"] = new[] {
            "https://images.unsplash.com/photo-1585515320310-259814833e62?w=800&q=80&auto=format&fit=crop",
            "https://images.unsplash.com/photo-1556910103-1c02745aae4d?w=800&q=80&auto=format&fit=crop",
        },
        ["lo-vi-song"] = new[] {
            "https://images.unsplash.com/photo-1585659722983-3a675dabf23d?w=800&q=80&auto=format&fit=crop",
        },
        ["may-hut-bui"] = new[] {
            "https://images.unsplash.com/photo-1558317374-067fb5f30001?w=800&q=80&auto=format&fit=crop",
            "https://images.unsplash.com/photo-1518444065439-e933c06ce9cd?w=800&q=80&auto=format&fit=crop",
        },
        ["quat"] = new[] {
            "https://images.unsplash.com/photo-1618941716939-553df3c6c278?w=800&q=80&auto=format&fit=crop",
        },
        ["may-loc-khong-khi"] = new[] {
            "https://images.unsplash.com/photo-1519638831568-d9897f54ed69?w=800&q=80&auto=format&fit=crop",
        },
        ["bep"] = new[] {
            "https://images.unsplash.com/photo-1556909212-d5b604d0c90d?w=800&q=80&auto=format&fit=crop",
            "https://images.unsplash.com/photo-1600585154340-be6161a56a0c?w=800&q=80&auto=format&fit=crop",
        },
        ["do-gia-dung"] = new[] {
            "https://images.unsplash.com/photo-1626074353765-517a681e40be?w=800&q=80&auto=format&fit=crop",
            "https://images.unsplash.com/photo-1522338140262-ff5c60e0e2b6?w=800&q=80&auto=format&fit=crop",
            "https://images.unsplash.com/photo-1574676768250-0b64b325c8b1?w=800&q=80&auto=format&fit=crop",
        },
    };

    // Trả về URL ảnh cho sản phẩm. index = vị trí trong danh mục.
    public static string For(string categorySlug, int index = 0, string fallbackSeed = null)
    {
        if (ByCategory.TryGetValue(categorySlug, out var urls) && index < urls.Length)
            return urls[index];
        // Picsum: ảnh thật, duy nhất theo seed, luôn chạy
        var seed = string.IsNullOrEmpty(fallbackSeed) ? $"{categorySlug}-{index}" : fallbackSeed;
        return $"https://picsum.photos/seed/{Uri.EscapeDataString(seed)}/800/800";
    }

    public static string Placeholder(string slug) =>
        $"https://picsum.photos/seed/{Uri.EscapeDataString(slug)}/800/800";

    public static string Banner(int i) => $"https://images.unsplash.com/photo-1607082348824-0a96f2a4b9da?w=1600&q=80&auto=format&fit=crop";
}
