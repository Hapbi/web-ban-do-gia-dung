using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Caching.Memory;
using HomeAppliances.Web.Data;
using HomeAppliances.Web.Domain;
using HomeAppliances.Web.Infrastructure;
using HomeAppliances.Web.Models.Entities;
using HomeAppliances.Web.Models.ViewModels;
using HomeAppliances.Web.Services;

namespace HomeAppliances.Web.Areas.Admin.Controllers;

public record CategoryRow(int Id, string Name, string Slug, int DisplayOrder, bool IsActive, int ProductCount);

[Area("Admin"), Authorize(Policy = AppPolicies.AdminOnly)]
public class CategoriesController : Controller
{
    private readonly ApplicationDbContext _db;
    private readonly IAuditService _audit;
    private readonly IMemoryCache _cache;
    public CategoriesController(ApplicationDbContext db, IAuditService audit, IMemoryCache cache) { _db = db; _audit = audit; _cache = cache; }

    public async Task<IActionResult> Index() =>
        View(await _db.Categories.AsNoTracking().OrderBy(c => c.DisplayOrder)
            .Select(c => new CategoryRow(c.Id, c.Name, c.Slug, c.DisplayOrder, c.IsActive, c.Products.Count)).ToListAsync());

    public IActionResult Create() => View("Edit", new CategoryEditViewModel());

    public async Task<IActionResult> Edit(int id)
    {
        var c = await _db.Categories.AsNoTracking().FirstOrDefaultAsync(x => x.Id == id);
        return c == null ? NotFound() : View(new CategoryEditViewModel { Id = c.Id, Name = c.Name, Description = c.Description, DisplayOrder = c.DisplayOrder, IsActive = c.IsActive });
    }

    [HttpPost]
    public async Task<IActionResult> Save(CategoryEditViewModel vm)
    {
        if (!ModelState.IsValid) return View("Edit", vm);
        Category c;
        if (vm.Id == 0) { c = new Category(); _db.Categories.Add(c); }
        else { c = (await _db.Categories.FirstOrDefaultAsync(x => x.Id == vm.Id))!; if (c == null) return NotFound(); }

        var slug = SlugHelper.Slugify(vm.Name); if (slug == "") slug = "danh-muc";
        var baseSlug = slug; var n = 2;
        while (await _db.Categories.AnyAsync(x => x.Slug == slug && x.Id != c.Id)) slug = $"{baseSlug}-{n++}";
        c.Name = vm.Name.Trim(); c.Slug = slug; c.Description = vm.Description?.Trim(); c.DisplayOrder = vm.DisplayOrder; c.IsActive = vm.IsActive;
        await _db.SaveChangesAsync();
        _cache.Remove(ProductCatalog.CategoriesCacheKey);
        await _audit.LogAsync(vm.Id == 0 ? "Category.Create" : "Category.Update", "Category", c.Id.ToString(), c.Name);
        TempData["Success"] = "Đã lưu danh mục.";
        return RedirectToAction(nameof(Index));
    }

    [HttpPost]
    public async Task<IActionResult> Delete(int id)
    {
        var c = await _db.Categories.FirstOrDefaultAsync(x => x.Id == id);
        if (c == null) return NotFound();
        if (await _db.Products.AnyAsync(p => p.CategoryId == id)) { TempData["Error"] = "Danh mục còn sản phẩm nên không thể xóa. Hãy ẩn danh mục hoặc chuyển sản phẩm sang danh mục khác."; return RedirectToAction(nameof(Index)); }
        _db.Categories.Remove(c);
        await _db.SaveChangesAsync();
        _cache.Remove(ProductCatalog.CategoriesCacheKey);
        await _audit.LogAsync("Category.Delete", "Category", id.ToString(), c.Name);
        TempData["Success"] = "Đã xóa danh mục.";
        return RedirectToAction(nameof(Index));
    }
}
