using System.Security.Claims;
using HomeAppliances.Web.Domain;
using HomeAppliances.Web.Helpers;
using HomeAppliances.Web.Infrastructure;
using HomeAppliances.Web.Services;
using Microsoft.AspNetCore.Authorization;
using Xunit;

namespace HomeAppliances.Tests.Unit;

public class VndFormatterTests
{
    [Theory]
    [InlineData(0, "0 ₫")]
    [InlineData(950, "950 ₫")]
    [InlineData(12490000, "12.490.000 ₫")]
    [InlineData(1000, "1.000 ₫")]
    public void Formats_with_dot_separators_and_dong_sign(int amount, string expected) => Assert.Equal(expected, ((decimal)amount).ToVnd());

    [Fact] public void Rounds_to_whole_dong() => Assert.Equal("1.001 ₫", 1000.5m.ToVnd());
    [Fact] public void Null_becomes_empty() => Assert.Equal("", ((decimal?)null).ToVnd());
}

public class SlugHelperTests
{
    [Theory]
    [InlineData("Tủ lạnh Inverter 2 cánh 450 lít", "tu-lanh-inverter-2-canh-450-lit")]
    [InlineData("Điều hòa 2 chiều", "dieu-hoa-2-chieu")]
    [InlineData("  Máy   giặt!!  ", "may-giat")]
    [InlineData("Lò vi sóng 23 lít", "lo-vi-song-23-lit")]
    public void Strips_diacritics_and_separators(string input, string expected) => Assert.Equal(expected, SlugHelper.Slugify(input));

    [Fact] public void Empty_input_gives_empty_slug() => Assert.Equal("", SlugHelper.Slugify("   "));
}

public class OrderNumberTests
{
    [Fact]
    public void Has_the_expected_shape()
    {
        var n = OrderNumberGenerator.Generate(new DateTime(2026, 10, 15, 8, 0, 0, DateTimeKind.Utc));
        Assert.Equal(12, n.Length);
        Assert.True(n.StartsWith("DH261015"));
        Assert.True(n.All(char.IsAsciiLetterOrDigit));
    }

    [Fact]
    public void Numbers_are_not_repeated_in_a_small_sample()
    {
        var set = new HashSet<string>();
        for (var i = 0; i < 500; i++) set.Add(OrderNumberGenerator.Generate(DateTime.UtcNow));
        Assert.True(set.Count > 490);
    }

    [Theory]
    [InlineData("{OrderNumber}", "DH2610150001", "DH2610150001")]
    [InlineData("DH {OrderNumber}", "ABC", "DH ABC")]
    [InlineData("", "ABC", "ABC")]
    [InlineData("TT {ordernumber} thanh toan", "ABC", "TT ABC thanh toan")]
    public void Builds_the_transfer_reference(string format, string number, string expected) =>
        Assert.Equal(expected, OrderNumberGenerator.BuildTransferReference(format, number));
}

public class PhoneAndSpecTests
{
    [Theory]
    [InlineData("0912345678", "0912345678")]
    [InlineData("+84912345678", "0912345678")]
    [InlineData("0912 345 678", "0912345678")]
    [InlineData("84912345678", "0912345678")]
    public void Normalises_phone_numbers_for_order_tracking(string input, string expected) => Assert.Equal(expected, OrderService.DigitsOnly(input));

    [Fact]
    public void Parses_specification_lines()
    {
        var specs = ProductAdminService.ParseSpecs("Công suất: 1.800 W\nBảo hành:12 tháng\nDòng không hợp lệ\n: thiếu tên\nTên:\n");
        Assert.Equal(2, specs.Count);
        Assert.Equal("Công suất", specs[0].Name);
        Assert.Equal("1.800 W", specs[0].Value);
        Assert.Equal("12 tháng", specs[1].Value);
    }
}

public class AuthorizationPolicyTests
{
    private static async Task<bool> Allowed(params Claim[] claims)
    {
        var options = new AuthorizationOptions();
        options.AddAppPolicies();
        var req = options.GetPolicy(AppPolicies.CanVerifyPayments)!.Requirements.OfType<Microsoft.AspNetCore.Authorization.Infrastructure.AssertionRequirement>().Single();
        var user = new ClaimsPrincipal(new ClaimsIdentity(claims, "test"));
        return await req.Handler(new AuthorizationHandlerContext(new[] { req }, user, null));
    }

    private static Claim Role(string r) => new(ClaimTypes.Role, r);
    private static readonly Claim Perm = new(AppClaims.PermissionType, AppClaims.VerifyPayments);

    [Fact] public async Task Admin_can_verify_payments() => Assert.True(await Allowed(Role("Admin")));
    [Fact] public async Task Employee_without_permission_cannot() => Assert.False(await Allowed(Role("Employee")));
    [Fact] public async Task Employee_with_permission_can() => Assert.True(await Allowed(Role("Employee"), Perm));
    [Fact] public async Task Customer_cannot_even_with_the_claim() => Assert.False(await Allowed(Role("Customer"), Perm));
    [Fact] public async Task Anonymous_cannot() => Assert.False(await Allowed());
}
