namespace HomeAppliances.Web.Services;

/// <summary>Every 15 minutes cancels orders that stayed unpaid longer than the configured limit, releasing their stock.</summary>
public class UnpaidOrderCleanupService : BackgroundService
{
    private readonly IServiceScopeFactory _scopes;
    private readonly ILogger<UnpaidOrderCleanupService> _log;

    public UnpaidOrderCleanupService(IServiceScopeFactory scopes, ILogger<UnpaidOrderCleanupService> log) { _scopes = scopes; _log = log; }

    protected override async Task ExecuteAsync(CancellationToken stoppingToken)
    {
        await Task.Delay(TimeSpan.FromMinutes(1), stoppingToken);
        using var timer = new PeriodicTimer(TimeSpan.FromMinutes(15));
        do
        {
            try
            {
                using var scope = _scopes.CreateScope();
                var settings = await scope.ServiceProvider.GetRequiredService<ISettingsService>().GetWebsiteAsync();
                if (settings.UnpaidOrderExpiryHours > 0)
                {
                    var n = await scope.ServiceProvider.GetRequiredService<IOrderService>().CancelExpiredUnpaidAsync(DateTime.UtcNow.AddHours(-settings.UnpaidOrderExpiryHours));
                    if (n > 0) _log.LogInformation("Cancelled {Count} expired unpaid orders", n);
                }
            }
            catch (Exception ex) when (ex is not OperationCanceledException) { _log.LogError(ex, "Unpaid-order cleanup failed"); }
        }
        while (await timer.WaitForNextTickAsync(stoppingToken));
    }
}
