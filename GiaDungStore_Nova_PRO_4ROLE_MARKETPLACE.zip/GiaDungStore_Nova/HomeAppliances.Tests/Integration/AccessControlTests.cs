using System.Text.RegularExpressions;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc.Testing;
using Microsoft.Data.Sqlite;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.DependencyInjection.Extensions;
using HomeAppliances.Web.Data;
using HomeAppliances.Web.Domain;
using HomeAppliances.Web.Infrastructure;
using HomeAppliances.Web.Models.Entities;
using Xunit;

namespace HomeAppliances.Tests.Integration;

/// <summary>Boots the real application against in-memory SQLite with seeded test accounts (passwords supplied only here, in test settings).</summary>
public class AppFactory : WebApplicationFactory<Program>
{
    public const string Password = "Test#12345";
    private readonly SqliteConnection _conn = new("DataSource=:memory:");

    protected override void ConfigureWebHost(IWebHostBuilder builder)
    {
        _conn.Open();
        builder.UseEnvironment("Development");
        builder.UseSetting("ConnectionStrings:DefaultConnection", "Server=ignored;Database=ignored");
        builder.UseSetting("Features:UnpaidOrderCleanup", "false");
        builder.UseSetting("Seed:Enabled", "true");
        builder.UseSetting("Seed:SampleData", "true");
        builder.UseSetting("Seed:AdminEmail", "admin@test.local");         builder.UseSetting("Seed:AdminPassword", Password);
        builder.UseSetting("Seed:EmployeeEmail", "employee@test.local");   builder.UseSetting("Seed:EmployeePassword", Password);
        builder.UseSetting("Seed:CustomerEmail", "customer@test.local");   builder.UseSetting("Seed:CustomerPassword", Password);
        builder.ConfigureServices(services =>
        {
            services.RemoveAll<DbContextOptions<ApplicationDbContext>>();
            services.AddDbContext<ApplicationDbContext>(o => o.UseSqlite(_conn));
        });
    }

    public HttpClient NewClient() => CreateClient(new WebApplicationFactoryClientOptions { AllowAutoRedirect = false });

    public async Task<string> CreateUserAsync(string email, string role, bool verifyPayments = false)
    {
        using var scope = Services.CreateScope();
        var users = scope.ServiceProvider.GetRequiredService<UserManager<ApplicationUser>>();
        var u = new ApplicationUser { UserName = email, Email = email, EmailConfirmed = true, FullName = email, PhoneNumber = "0900000001" };
        var r = await users.CreateAsync(u, Password);
        if (!r.Succeeded) throw new InvalidOperationException(string.Join(";", r.Errors.Select(e => e.Description)));
        await users.AddToRoleAsync(u, role);
        if (verifyPayments) await users.AddClaimAsync(u, new System.Security.Claims.Claim(AppClaims.PermissionType, AppClaims.VerifyPayments));
        return u.Id;
    }

}

public static class ClientExtensions
{
    public static string Token(string html) =>
        Regex.Match(html, "name=\"__RequestVerificationToken\"[^>]*value=\"([^\"]+)\"").Groups[1].Value;

    public static async Task<HttpResponseMessage> LoginAsync(this HttpClient c, string email, string password = AppFactory.Password)
    {
        var token = Token(await c.GetStringAsync("/dang-nhap"));
        return await c.PostAsync("/dang-nhap", new FormUrlEncodedContent(new Dictionary<string, string>
        { ["Email"] = email, ["Password"] = password, ["__RequestVerificationToken"] = token }));
    }
}

public class AccessControlTests : IClassFixture<AppFactory>
{
    private readonly AppFactory _f;
    public AccessControlTests(AppFactory f) => _f = f;

    [Theory]
    [InlineData("/")] [InlineData("/san-pham")] [InlineData("/danh-muc/tu-lanh")] [InlineData("/gioi-thieu")] [InlineData("/lien-he")]
    [InlineData("/hoi-dap")] [InlineData("/dang-nhap")] [InlineData("/dang-ky")] [InlineData("/quen-mat-khau")] [InlineData("/gio-hang")] [InlineData("/theo-doi-don-hang")]
    public async Task Public_pages_load(string path) => Assert.Equal(System.Net.HttpStatusCode.OK, (await _f.NewClient().GetAsync(path)).StatusCode);

    [Theory]
    [InlineData("/Admin")] [InlineData("/Admin/Products")] [InlineData("/Admin/Users")] [InlineData("/Admin/BankSettings")]
    [InlineData("/Employee")] [InlineData("/Employee/Orders")]
    [InlineData("/don-hang")] [InlineData("/tai-khoan")] [InlineData("/thanh-toan")]
    public async Task Anonymous_visitors_are_sent_to_the_login_page(string path)
    {
        var r = await _f.NewClient().GetAsync(path);
        Assert.Equal(System.Net.HttpStatusCode.Redirect, r.StatusCode);
        Assert.Contains("/dang-nhap", r.Headers.Location!.ToString());
    }

    [Theory]
    [InlineData("/Admin/Products")] [InlineData("/Admin/Users")] [InlineData("/Admin/BankSettings")] [InlineData("/Employee/Orders")]
    public async Task Customers_are_refused_by_staff_areas(string path)
    {
        var c = _f.NewClient();
        await c.LoginAsync("customer@test.local");
        var r = await c.GetAsync(path);
        Assert.Equal(System.Net.HttpStatusCode.Redirect, r.StatusCode);
        Assert.Contains("/khong-co-quyen", r.Headers.Location!.ToString());
    }

    [Theory]
    [InlineData("/Admin/Products")] [InlineData("/Admin/Users")] [InlineData("/Admin/BankSettings")] [InlineData("/Admin/WebsiteSettings")]
    public async Task Employees_cannot_open_administrator_pages(string path)
    {
        var c = _f.NewClient();
        await c.LoginAsync("employee@test.local");
        Assert.Contains("/khong-co-quyen", (await c.GetAsync(path)).Headers.Location?.ToString() ?? "");
    }

    [Fact]
    public async Task Employees_and_admins_can_open_their_order_screens()
    {
        var e = _f.NewClient(); await e.LoginAsync("employee@test.local");
        Assert.Equal(System.Net.HttpStatusCode.OK, (await e.GetAsync("/Employee/Orders")).StatusCode);
        Assert.Equal(System.Net.HttpStatusCode.OK, (await e.GetAsync("/Employee/Products")).StatusCode);

        var a = _f.NewClient(); await a.LoginAsync("admin@test.local");
        Assert.Equal(System.Net.HttpStatusCode.OK, (await a.GetAsync("/Admin/Orders")).StatusCode);   // dashboards use SQL SUM(decimal), which SQLite cannot run, so they are verified on SQL Server only
        Assert.Equal(System.Net.HttpStatusCode.OK, (await a.GetAsync("/Admin/Products")).StatusCode);
        Assert.Equal(System.Net.HttpStatusCode.OK, (await a.GetAsync("/Admin/Users")).StatusCode);
    }

    [Fact]
    public async Task An_employee_without_the_permission_cannot_approve_payments_even_by_posting_directly()
    {
        await _f.CreateUserAsync("limited@test.local", AppRoles.Employee, verifyPayments: false);
        var c = _f.NewClient();
        await c.LoginAsync("limited@test.local");
        var token = ClientExtensions.Token(await c.GetStringAsync("/tai-khoan/doi-mat-khau"));
        var r = await c.PostAsync("/Employee/Orders/Approve/1", new FormUrlEncodedContent(new Dictionary<string, string> { ["__RequestVerificationToken"] = token }));
        Assert.Contains("/khong-co-quyen", r.Headers.Location?.ToString() ?? "");
    }

    [Fact]
    public async Task A_customer_cannot_read_another_customers_order_or_payment_proof()
    {
        var ownerId = await _f.CreateUserAsync("owner@test.local", AppRoles.Customer);
        string number;
        int proofId;
        using (var scope = _f.Services.CreateScope())
        {
            var db = scope.ServiceProvider.GetRequiredService<ApplicationDbContext>();
            var order = new Order { OrderNumber = "DH261015TEST", UserId = ownerId, CustomerEmail = "owner@test.local", ReceiverName = "Owner", Phone = "0912345678", Address = "12 Phố Test", Total = 100000m, Status = OrderStatus.PendingVerification };
            order.Proofs.Add(new PaymentProof { StoredPath = "payment-proofs/1/x.png", ContentType = "image/png", OriginalFileName = "x.png" });
            db.Orders.Add(order);
            await db.SaveChangesAsync();
            number = order.OrderNumber; proofId = order.Proofs[0].Id;
        }

        var other = _f.NewClient(); await other.LoginAsync("customer@test.local");
        Assert.Equal(System.Net.HttpStatusCode.NotFound, (await other.GetAsync($"/don-hang/{number}")).StatusCode);
        Assert.Equal(System.Net.HttpStatusCode.NotFound, (await other.GetAsync($"/don-hang/bien-lai/{proofId}")).StatusCode);

        var owner = _f.NewClient(); await owner.LoginAsync("owner@test.local");
        Assert.Equal(System.Net.HttpStatusCode.OK, (await owner.GetAsync($"/don-hang/{number}")).StatusCode);
    }

    [Fact]
    public async Task Registering_the_same_email_twice_is_rejected()
    {
        var c = _f.NewClient();
        async Task<string> Register()
        {
            var token = ClientExtensions.Token(await c.GetStringAsync("/dang-ky"));
            var r = await c.PostAsync("/dang-ky", new FormUrlEncodedContent(new Dictionary<string, string>
            { ["FullName"] = "Dup", ["Email"] = "dup@test.local", ["PhoneNumber"] = "0912345678", ["Password"] = "Abcdefg1", ["ConfirmPassword"] = "Abcdefg1", ["__RequestVerificationToken"] = token }));
            return await r.Content.ReadAsStringAsync();
        }
        await Register();
        var c2 = _f.NewClient(); c = c2;
        Assert.Contains("Email này đã được đăng ký", await Register());
    }

    [Fact]
    public async Task Forgot_password_gives_the_same_answer_for_known_and_unknown_emails()
    {
        async Task<string?> Ask(string email)
        {
            var c = _f.NewClient();
            var token = ClientExtensions.Token(await c.GetStringAsync("/quen-mat-khau"));
            var r = await c.PostAsync("/quen-mat-khau", new FormUrlEncodedContent(new Dictionary<string, string> { ["Email"] = email, ["__RequestVerificationToken"] = token }));
            return r.StatusCode + " " + r.Headers.Location;
        }
        Assert.Equal(await Ask("customer@test.local"), await Ask("nobody-here@test.local"));
    }

    [Fact]
    public async Task State_changing_posts_without_an_antiforgery_token_are_rejected()
    {
        var r = await _f.NewClient().PostAsync("/lien-he", new FormUrlEncodedContent(new Dictionary<string, string> { ["FullName"] = "x" }));
        Assert.Equal(System.Net.HttpStatusCode.BadRequest, r.StatusCode);
    }

    [Fact]
    public async Task Responses_carry_basic_security_headers()
    {
        var r = await _f.NewClient().GetAsync("/");
        Assert.True(r.Headers.Contains("X-Content-Type-Options"));
        Assert.True(r.Headers.Contains("X-Frame-Options"));
    }
}
