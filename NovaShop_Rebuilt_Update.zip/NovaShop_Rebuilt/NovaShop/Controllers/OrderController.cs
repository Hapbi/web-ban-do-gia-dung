using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using NovaShop.Models;
using NovaShop.Services;

namespace NovaShop.Controllers;

[Authorize]
public class OrderController : Controller
{
    private readonly OrderService _orders;
    private readonly CartService _cart;
    private readonly AuthService _auth;
    private readonly SettingsService _settings;

    public OrderController(OrderService orders, CartService cart, AuthService auth, SettingsService settings)
    { _orders = orders; _cart = cart; _auth = auth; _settings = settings; }

    [Route("thanh-toan")]
    public async Task<IActionResult> Checkout()
    {
        var cart = await _cart.GetAsync();
        if (cart.IsEmpty) return RedirectToAction("Index", "Cart");
        var user = await _auth.GetCurrentAsync();
        var vm = new CheckoutVM
        {
            CustomerName = user?.FullName ?? "",
            Phone = user?.Phone ?? "",
            Email = user?.Email ?? "",
            Cart = cart
        };
        return View(vm);
    }

    [HttpPost, Route("thanh-toan")]
    public async Task<IActionResult> Checkout(CheckoutVM vm)
    {
        var cart = await _cart.GetAsync(vm.CouponCode);
        vm.Cart = cart;
        if (!ModelState.IsValid) return View(vm);
        var (ok, code, err) = await _orders.PlaceOrderAsync(vm);
        if (!ok)
        {
            TempData["Error"] = err;
            return RedirectToAction("Index", "Cart");
        }
        TempData["Success"] = $"Đơn hàng #{code} đã được tạo";
        return RedirectToAction(nameof(MyOrders));
    }

    [Route("don-hang")]
    public async Task<IActionResult> MyOrders() =>
        View(await _orders.GetMyOrdersAsync());

    [Route("don-hang/{code}")]
    public async Task<IActionResult> Detail(string code)
    {
        var order = await _orders.GetByCodeAsync(code);
        if (order == null) return NotFound();
        ViewBag.Bank = await _settings.GetBankAsync();
        return View(order);
    }
}
