using System.Globalization;
using System.Security.Claims;
using System.Text;
using System.Text.RegularExpressions;

namespace NovaShop.Helpers;

public static class Ext
{
    public const string PermClaim = "shop:perm";

    public static bool Can(this ClaimsPrincipal u, string perm) =>
        u.IsInRole("Admin") ||
        (u.IsInRole("Staff") && u.FindAll(PermClaim).Any(c => c.Value == perm));

    public static bool CanProducts(this ClaimsPrincipal u) => u.Can("product.manage");

    public static bool IsBackoffice(this ClaimsPrincipal u) =>
        u.IsInRole("Admin") || u.IsInRole("Staff");

    public static string Money(this decimal n) =>
        n.ToString("#,##0", CultureInfo.InvariantCulture).Replace(',', '.') + "đ";

    public static string MoneyShort(this decimal n) =>
        n >= 1_000_000 ? (n / 1_000_000).ToString("0.#") + "tr"
        : n >= 1_000 ? (n / 1_000).ToString("0") + "k"
        : n.ToString("0");

    public static string Slugify(string text)
    {
        if (string.IsNullOrWhiteSpace(text)) return Guid.NewGuid().ToString("N")[..8];
        var s = text.ToLower().Normalize(NormalizationForm.FormD);
        var sb = new StringBuilder();
        foreach (var c in s)
        {
            if (CharUnicodeInfo.GetUnicodeCategory(c) == UnicodeCategory.NonSpacingMark) continue;
            sb.Append(char.IsLetterOrDigit(c) ? c : '-');
        }
        return Regex.Replace(sb.ToString(), "-+", "-").Trim('-');
    }
}
