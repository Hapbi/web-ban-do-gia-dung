using System.Globalization;
using System.Text.Encodings.Web;
using System.Text.Unicode;
using System.Threading.RateLimiting;
using Microsoft.AspNetCore.HttpOverrides;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Localization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using HomeAppliances.Web.Data;
using HomeAppliances.Web.Infrastructure;
using HomeAppliances.Web.Models.Entities;
using HomeAppliances.Web.Services;

var builder = WebApplication.CreateBuilder(args);
var isDev = builder.Environment.IsDevelopment();

// ---- Configuration ---------------------------------------------------------
builder.Services.Configure<EmailOptions>(builder.Configuration.GetSection(EmailOptions.SectionName));
builder.Services.Configure<StorageOptions>(builder.Configuration.GetSection(StorageOptions.SectionName));
var emailOptions = builder.Configuration.GetSection(EmailOptions.SectionName).Get<EmailOptions>() ?? new EmailOptions();
var emailEnabled = emailOptions.Enabled && !string.IsNullOrWhiteSpace(emailOptions.SmtpHost);

// ---- Database + Identity ---------------------------------------------------
var connectionString = builder.Configuration.GetConnectionString("DefaultConnection")
    ?? throw new InvalidOperationException("Missing ConnectionStrings:DefaultConnection. Set it in user secrets or appsettings.");
builder.Services.AddDbContext<ApplicationDbContext>(o => o.UseSqlServer(connectionString));

builder.Services.AddIdentity<ApplicationUser, IdentityRole>(o =>
{
    o.User.RequireUniqueEmail = true;
    o.Password.RequiredLength = 8;
    o.Password.RequireDigit = true;
    o.Password.RequireLowercase = true;
    o.Password.RequireUppercase = false;
    o.Password.RequireNonAlphanumeric = false;
    o.Lockout.MaxFailedAccessAttempts = 5;
    o.Lockout.DefaultLockoutTimeSpan = TimeSpan.FromMinutes(15);
    o.Lockout.AllowedForNewUsers = true;
    o.SignIn.RequireConfirmedEmail = emailEnabled;     // only enforced when email delivery works
})
.AddEntityFrameworkStores<ApplicationDbContext>()
.AddDefaultTokenProviders();

builder.Services.Configure<DataProtectionTokenProviderOptions>(o => o.TokenLifespan = TimeSpan.FromHours(2));   // password-reset links expire
// Re-check the security stamp on every request so deactivating a user or changing roles takes effect immediately.
builder.Services.Configure<SecurityStampValidatorOptions>(o => o.ValidationInterval = TimeSpan.Zero);

var cookieSecure = isDev ? CookieSecurePolicy.SameAsRequest : CookieSecurePolicy.Always;
builder.Services.ConfigureApplicationCookie(o =>
{
    o.LoginPath = "/dang-nhap";
    o.AccessDeniedPath = "/khong-co-quyen";
    o.Cookie.Name = ".HomeAppliances.Auth";
    o.Cookie.HttpOnly = true;
    o.Cookie.SameSite = SameSiteMode.Lax;
    o.Cookie.SecurePolicy = cookieSecure;
    o.SlidingExpiration = true;
    o.ExpireTimeSpan = TimeSpan.FromDays(14);
});
builder.Services.AddAntiforgery(o =>
{
    o.Cookie.Name = ".HomeAppliances.Antiforgery";
    o.Cookie.HttpOnly = true;
    o.Cookie.SameSite = SameSiteMode.Strict;
    o.Cookie.SecurePolicy = cookieSecure;
});
builder.Services.AddAuthorization(o => o.AddAppPolicies());

builder.Services.AddDistributedMemoryCache();
builder.Services.AddSession(o =>
{
    o.Cookie.Name = ".HomeAppliances.Session";
    o.Cookie.HttpOnly = true;
    o.Cookie.IsEssential = true;
    o.Cookie.SecurePolicy = cookieSecure;
    o.IdleTimeout = TimeSpan.FromHours(8);
});
builder.Services.AddMemoryCache();
builder.Services.AddHttpContextAccessor();

// Throttle credential-guessing and lookup endpoints per IP.
builder.Services.AddRateLimiter(o =>
{
    o.RejectionStatusCode = StatusCodes.Status429TooManyRequests;
    o.AddPolicy("auth", ctx => RateLimitPartition.GetFixedWindowLimiter(
        ctx.Connection.RemoteIpAddress?.ToString() ?? "unknown",
        _ => new FixedWindowRateLimiterOptions { PermitLimit = 20, Window = TimeSpan.FromMinutes(1) }));
});

// Vietnamese characters are written as-is; markup characters are still HTML-encoded.
builder.Services.AddSingleton(HtmlEncoder.Create(UnicodeRanges.All));

builder.Services.AddControllersWithViews(o =>
{
    o.Filters.Add(new AutoValidateAntiforgeryTokenAttribute());
    // Only [Required] makes a field mandatory (with our Vietnamese message); non-nullable C# strings are not implicitly required.
    o.SuppressImplicitRequiredAttributeForNonNullableReferenceTypes = true;
});

// ---- Application services --------------------------------------------------
builder.Services.AddScoped<ISettingsService, SettingsService>();
builder.Services.AddScoped<IProductCatalog, ProductCatalog>();
builder.Services.AddScoped<ICartService, CartService>();
builder.Services.AddScoped<IOrderService, OrderService>();
builder.Services.AddScoped<IProductAdminService, ProductAdminService>();
builder.Services.AddScoped<IReportService, ReportService>();
builder.Services.AddScoped<IAuditService, AuditService>();
builder.Services.AddScoped<IFileStorage, FileStorage>();
if (emailEnabled) builder.Services.AddSingleton<IEmailService, SmtpEmailService>();
else builder.Services.AddSingleton<IEmailService, LogEmailService>();
builder.Services.AddSingleton<ISiteInfoAccessor, SiteInfoAccessor>();
if (builder.Configuration.GetValue("Features:UnpaidOrderCleanup", true)) builder.Services.AddHostedService<UnpaidOrderCleanupService>();

// Behind a TLS-terminating reverse proxy (IIS, nginx, Azure App Service...) set Hosting:BehindProxy=true so the app
// sees the original https scheme; otherwise secure cookies and antiforgery would refuse every request.
if (builder.Configuration.GetValue<bool>("Hosting:BehindProxy"))
{
    builder.Services.Configure<ForwardedHeadersOptions>(o =>
    {
        o.ForwardedHeaders = ForwardedHeaders.XForwardedFor | ForwardedHeaders.XForwardedProto;
        o.KnownNetworks.Clear();   // trust the proxy in front of the app; make sure the app is not reachable except through it
        o.KnownProxies.Clear();
    });
}

var app = builder.Build();
if (app.Configuration.GetValue<bool>("Hosting:BehindProxy")) app.UseForwardedHeaders();

// ---- Database ---------------------------------------------------------------
if (app.Configuration.GetValue("Database:AutoInitialize", true))
{
    try { await DbInitializer.InitializeAsync(app.Services); }
    catch (Exception ex)
    {
        app.Logger.LogCritical(ex, "Database initialisation failed. Check ConnectionStrings:DefaultConnection and that SQL Server is reachable.");
        throw;
    }
}

// ---- HTTP pipeline ----------------------------------------------------------
var vi = new CultureInfo("vi-VN");
app.UseRequestLocalization(new RequestLocalizationOptions
{
    DefaultRequestCulture = new RequestCulture(vi),
    SupportedCultures = new[] { vi },
    SupportedUICultures = new[] { vi }
});

if (!isDev)
{
    app.UseExceptionHandler("/loi");
    app.UseHsts();
}
app.UseMiddleware<SecurityHeadersMiddleware>(!isDev);
app.UseStatusCodePagesWithReExecute("/khong-tim-thay", "?code={0}");
app.UseHttpsRedirection();
app.UseStaticFiles();
app.UseRouting();
app.UseRateLimiter();
app.UseSession();
app.UseAuthentication();
app.UseAuthorization();
app.UseMiddleware<SiteInfoMiddleware>();

app.MapControllerRoute(name: "areas", pattern: "{area:exists}/{controller=Dashboard}/{action=Index}/{id?}");
app.MapControllerRoute(name: "default", pattern: "{controller=Home}/{action=Index}/{id?}");

app.Run();

// Exposed so integration tests (WebApplicationFactory<Program>) can reference it.
public partial class Program { }
