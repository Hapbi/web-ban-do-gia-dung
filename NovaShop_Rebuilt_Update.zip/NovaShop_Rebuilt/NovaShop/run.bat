@echo off
echo ================================================
echo   NovaShop - Web ban do gia dung thong minh
echo ================================================
where dotnet >nul 2>&1
if errorlevel 1 (
  echo [LOI] Chua cai .NET 8 SDK. Tai tai: https://dotnet.microsoft.com/download/dotnet/8.0
  pause & exit /b 1
)
echo [1/3] Restore packages...
dotnet restore
if errorlevel 1 ( pause & exit /b 1 )
echo [2/3] Build...
dotnet build -c Release --no-restore
if errorlevel 1 ( pause & exit /b 1 )
echo [3/3] Mo trinh duyet va chay server...
start http://localhost:5080
dotnet run -c Release --no-build --urls "http://localhost:5080"
pause
