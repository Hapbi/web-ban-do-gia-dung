using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using HomeAppliances.Web.Data;
using HomeAppliances.Web.Domain;
using HomeAppliances.Web.Infrastructure;
using HomeAppliances.Web.Models.ViewModels;
using HomeAppliances.Web.Services;

namespace HomeAppliances.Web.Controllers.Base;

/// <summary>
/// Order handling shared by the Admin and Employee areas. The derived controllers decide who may enter
/// the area; this class additionally enforces the finer rules (state machine per role, payment permission).
/// </summary>
public abstract class StaffOrdersControllerBase : Controller
{
    private readonly IOrderService _orders;
    private readonly ISettingsService _settings;
    private readonly IFileStorage _files;
    private readonly IAuthorizationService _auth;

    protected StaffOrdersControllerBase(IOrderService orders, ISettingsService settings, IFileStorage files, IAuthorizationService auth)
    { _orders = orders; _settings = settings; _files = files; _auth = auth; }

    private ActorRole Actor => User.IsInRole(AppRoles.Admin) ? ActorRole.Admin : ActorRole.Employee;
    private string Uid => User.GetUserId()!;
    private Task<bool> CanVerifyAsync() => _auth.AuthorizeAsync(User, AppPolicies.CanVerifyPayments).ContinueWith(t => t.Result.Succeeded);

    public async Task<IActionResult> Index(OrderSearch search)
    {
        ViewData["CanVerify"] = await CanVerifyAsync();
        return View(new StaffOrderListViewModel { Search = search, Result = await _orders.SearchAsync(search) });
    }

    public async Task<IActionResult> Details(int id)
    {
        var order = await _orders.GetForStaffAsync(id);
        if (order == null) return NotFound();
        var bank = await _settings.GetBankAsync();
        var next = OrderStateMachine.AllowedNext(order.Status, Actor)
            .Where(s => s is OrderStatus.Processing or OrderStatus.Shipped or OrderStatus.Delivered).ToList();
        return View(new OrderDetailViewModel
        {
            Order = order, Bank = bank, Actor = Actor, NextStatuses = next,
            TransferReference = OrderNumberGenerator.BuildTransferReference(bank.ReferenceFormat, order.OrderNumber),
            CanVerifyPayments = await CanVerifyAsync(),
            CanStaffCancel = OrderStateMachine.CanTransition(order.Status, OrderStatus.Cancelled, Actor),
            LatestProof = order.Proofs.OrderByDescending(p => p.UploadedUtc).FirstOrDefault()
        });
    }

    [HttpPost]
    public async Task<IActionResult> UpdateStatus(int id, OrderStatus next, string? note)
    {
        var r = await _orders.AdvanceStatusAsync(id, next, Actor, Uid, User.GetEmail(), note);
        if (r.Succeeded) TempData["Success"] = "Đã cập nhật trạng thái đơn hàng."; else TempData["Error"] = r.Error;
        return RedirectToAction(nameof(Details), new { id });
    }

    [HttpPost]
    public async Task<IActionResult> Approve(int id)
    {
        if (!await CanVerifyAsync()) return Forbid();   // server-side check; hiding the button is not enough
        var r = await _orders.ApproveAsync(id, Uid, User.GetEmail(), Actor);
        if (r.Succeeded) TempData["Success"] = "Đã xác nhận thanh toán."; else TempData["Error"] = r.Error;
        return RedirectToAction(nameof(Details), new { id });
    }

    [HttpPost]
    public async Task<IActionResult> Reject(int id, string? reason)
    {
        if (!await CanVerifyAsync()) return Forbid();
        var r = await _orders.RejectAsync(id, Uid, User.GetEmail(), Actor, reason ?? "");
        if (r.Succeeded) TempData["Success"] = "Đã từ chối biên lai. Khách hàng sẽ thấy lý do và có thể gửi lại."; else TempData["Error"] = r.Error;
        return RedirectToAction(nameof(Details), new { id });
    }

    [HttpPost]
    public async Task<IActionResult> Cancel(int id, string? reason)
    {
        var r = await _orders.CancelAsync(id, Actor, Uid, User.GetEmail(), reason);
        if (r.Succeeded) TempData["Success"] = "Đã hủy đơn hàng và hoàn lại tồn kho."; else TempData["Error"] = r.Error;
        return RedirectToAction(nameof(Details), new { id });
    }

    public async Task<IActionResult> Proof(int proofId, [FromServices] ApplicationDbContext db)
    {
        if (!await CanVerifyAsync()) return Forbid();
        var path = await db.PaymentProofs.AsNoTracking().Where(p => p.Id == proofId).Select(p => p.StoredPath).FirstOrDefaultAsync();
        if (path == null) return NotFound();
        var file = _files.OpenPrivate(path);
        if (file == null) return NotFound();
        Response.Headers["Cache-Control"] = "private, no-store";
        Response.Headers["X-Content-Type-Options"] = "nosniff";
        return File(file.Value.Stream, file.Value.ContentType);
    }
}
