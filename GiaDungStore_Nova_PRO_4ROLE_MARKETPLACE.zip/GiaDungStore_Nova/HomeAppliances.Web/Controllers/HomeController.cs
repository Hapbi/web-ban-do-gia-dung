using System.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using HomeAppliances.Web.Models.ViewModels;
using HomeAppliances.Web.Services;

namespace HomeAppliances.Web.Controllers;

public class HomeController : Controller
{
    private readonly IProductCatalog _catalog;

    public HomeController(IProductCatalog catalog) => _catalog = catalog;

    public async Task<IActionResult> Index() => View(await _catalog.GetHomePageAsync());

    [Route("loi")]
    [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
    public IActionResult Error() =>
        View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });

    /// <summary>Target of UseStatusCodePagesWithReExecute for 404 and other client errors.</summary>
    [Route("khong-tim-thay")]
    public IActionResult NotFound(int? code)
    {
        Response.StatusCode = code ?? 404;
        return View("NotFound");
    }
}
