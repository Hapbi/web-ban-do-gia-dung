using System.Security.Cryptography;

namespace HomeAppliances.Web.Domain;

public static class OrderNumberGenerator
{
    // No 0/O/1/I so the number is easy to read and to type into a bank transfer note.
    private const string Alphabet = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";

    /// <summary>e.g. DH261015K7QX = "DH" + yyMMdd + 4 random characters.</summary>
    public static string Generate(DateTime utcNow)
    {
        var chars = new char[4];
        for (var i = 0; i < chars.Length; i++) chars[i] = Alphabet[RandomNumberGenerator.GetInt32(Alphabet.Length)];
        return "DH" + utcNow.ToString("yyMMdd") + new string(chars);
    }

    public static string BuildTransferReference(string? format, string orderNumber)
    {
        var f = string.IsNullOrWhiteSpace(format) ? "{OrderNumber}" : format;
        return f.Replace("{OrderNumber}", orderNumber, StringComparison.OrdinalIgnoreCase).Trim();
    }
}
