using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using HomeAppliances.Web.Controllers.Base;
using HomeAppliances.Web.Infrastructure;
using HomeAppliances.Web.Services;

namespace HomeAppliances.Web.Areas.Employee.Controllers;

[Area("Employee"), Authorize(Policy = AppPolicies.StaffOnly)]
public class OrdersController : StaffOrdersControllerBase
{
    public OrdersController(IOrderService o, ISettingsService s, IFileStorage f, IAuthorizationService a) : base(o, s, f, a) { }
}
