using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using NovaShop.Data;
using NovaShop.Models;
using NovaShop.Services;

namespace NovaShop.Controllers;

[Authorize(Roles = "Staff,Admin")]
public class StaffController : Controller
{
    private readonly AppDbContext _db;
    private readonly ReportService _reports;
    private readonly OrderService _orders;

    public StaffController(AppDbContext db, ReportService reports, OrderService orders)
    { _db = db; _reports = reports; _orders = orders; }

    [Route("staff")]
    public async Task<IActionResult> Index() => View(await _reports.GetDashboardAsync());

    [Route("staff/kanban")]
    public async Task<IActionResult> Kanban()
    {
        var orders = await _db.Orders.Include(o => o.Items).ToListAsync();
        ViewBag.Pending = orders.Where(o => o.Status == OrderStatus.Pending).OrderBy(o => o.CreatedAt).ToList();
        ViewBag.Confirmed = orders.Where(o => o.Status == OrderStatus.Confirmed).OrderBy(o => o.CreatedAt).ToList();
        ViewBag.Packing = orders.Where(o => o.Status == OrderStatus.Packing).OrderBy(o => o.CreatedAt).ToList();
        ViewBag.Shipping = orders.Where(o => o.Status == OrderStatus.Shipping).OrderBy(o => o.CreatedAt).ToList();
        ViewBag.Delivered = orders.Where(o => o.Status == OrderStatus.Delivered).OrderByDescending(o => o.DeliveredAt).Take(10).ToList();
        return View();
    }

    [HttpPost, Route("staff/don/{id}/xac-nhan")]
    public async Task<IActionResult> Confirm(int id)
    {
        var (ok, msg) = await _orders.ConfirmAsync(id, User.Identity!.Name!);
        TempData[ok ? "Success" : "Error"] = msg;
        return RedirectToAction(nameof(Kanban));
    }

    [HttpPost, Route("staff/don/{id}/dong-goi")]
    public async Task<IActionResult> Pack(int id)
    {
        var (ok, msg) = await _orders.PackAsync(id, User.Identity!.Name!);
        TempData[ok ? "Success" : "Error"] = msg;
        return RedirectToAction(nameof(Kanban));
    }

    [HttpPost, Route("staff/don/{id}/giao")]
    public async Task<IActionResult> Ship(int id)
    {
        var (ok, msg) = await _orders.ShipAsync(id, User.Identity!.Name!);
        TempData[ok ? "Success" : "Error"] = msg;
        return RedirectToAction(nameof(Kanban));
    }

    [HttpPost, Route("staff/don/{id}/giao-xong")]
    public async Task<IActionResult> Deliver(int id)
    {
        var (ok, msg) = await _orders.DeliverAsync(id, User.Identity!.Name!);
        TempData[ok ? "Success" : "Error"] = msg;
        return RedirectToAction(nameof(Kanban));
    }

    [HttpPost, Route("staff/don/{id}/huy")]
    public async Task<IActionResult> Cancel(int id)
    {
        var (ok, msg) = await _orders.CancelAsync(id, User.Identity!.Name!);
        TempData[ok ? "Success" : "Error"] = msg;
        return RedirectToAction(nameof(Kanban));
    }
}


####################################################################################################
