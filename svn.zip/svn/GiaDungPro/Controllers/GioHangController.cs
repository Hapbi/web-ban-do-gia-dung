using CuaHangGiaDungPro.Data;
using CuaHangGiaDungPro.Helpers;
using Microsoft.AspNetCore.Mvc;

namespace CuaHangGiaDungPro.Controllers;

public class GioHangController : Controller
{
    private readonly AppDb _db;
    public GioHangController(AppDb db) => _db = db;

    [Route("gio-hang")]
    public IActionResult Index()
    {
        var list = GioHangHelper.DanhSach(HttpContext.Session, _db);
        ViewBag.CauHinh = _db.CauHinhs.FirstOrDefault();
        return View(list);
    }

    [HttpPost, Route("gio-hang/them")]
    [ValidateAntiForgeryToken]
    public IActionResult Them(int sanPhamId, int soLuong = 1, string? returnUrl = null, bool muaLuon = false)
    {
        var sp = _db.SanPhams.FirstOrDefault(x => x.Id == sanPhamId && x.DangBan);
        if (sp == null)
        {
            TempData["Loi"] = "Sản phẩm không tồn tại";
            return RedirectToAction(nameof(Index));
        }
        if (sp.TonKho <= 0)
        {
            TempData["Loi"] = "Sản phẩm đã hết hàng";
            return RedirectToAction(nameof(Index));
        }

        var hienTai = GioHangHelper.Lay(HttpContext.Session).GetValueOrDefault(sanPhamId);
        var moi = hienTai + Math.Max(1, soLuong);
        if (moi > sp.TonKho)
        {
            TempData["Loi"] = $"Chỉ còn {sp.TonKho} sản phẩm";
            moi = sp.TonKho;
        }
        GioHangHelper.Dat(HttpContext.Session, sanPhamId, moi);
        TempData["ThanhCong"] = "Đã thêm vào giỏ hàng";

        if (muaLuon) return RedirectToAction("ThanhToan", "DonHang");
        if (!string.IsNullOrWhiteSpace(returnUrl) && Url.IsLocalUrl(returnUrl))
            return Redirect(returnUrl);
        return RedirectToAction(nameof(Index));
    }

    [HttpPost, Route("gio-hang/cap-nhat")]
    [ValidateAntiForgeryToken]
    public IActionResult CapNhat(int sanPhamId, int delta)
    {
        var sp = _db.SanPhams.FirstOrDefault(x => x.Id == sanPhamId && x.DangBan);
        if (sp == null) return Json(new { ok = false, thongBao = "Sản phẩm không tồn tại" });

        var gio = GioHangHelper.Lay(HttpContext.Session);
        var soLuongMoi = gio.GetValueOrDefault(sanPhamId) + delta;
        if (sp.TonKho <= 0 || soLuongMoi <= 0)
            gio.Remove(sanPhamId);
        else
            gio[sanPhamId] = Math.Min(soLuongMoi, sp.TonKho);
        GioHangHelper.Luu(HttpContext.Session, gio);

        var list = GioHangHelper.DanhSach(HttpContext.Session, _db);
        var tongTien = list.Sum(x => x.ThanhTien);
        var tongSoLuong = list.Sum(x => x.SoLuong);
        var soLuongCuaSp = gio.GetValueOrDefault(sanPhamId);

        return Json(new {
            ok = true, sanPhamId, soLuong = soLuongCuaSp,
            thanhTien = (soLuongCuaSp * sp.GiaHienTai),
            thanhTienFormat = TienIch.Tien(soLuongCuaSp * sp.GiaHienTai),
            tongTien, tongTienFormat = TienIch.Tien(tongTien),
            tongSoLuong, daXoa = soLuongCuaSp == 0
        });
    }

    [HttpPost, Route("gio-hang/xoa")]
    [ValidateAntiForgeryToken]
    public IActionResult Xoa(int sanPhamId)
    {
        GioHangHelper.Xoa(HttpContext.Session, sanPhamId);
        TempData["ThanhCong"] = "Đã xoá sản phẩm khỏi giỏ";
        return RedirectToAction(nameof(Index));
    }

    [HttpPost, Route("gio-hang/xoa-het")]
    [ValidateAntiForgeryToken]
    public IActionResult XoaHet()
    {
        GioHangHelper.XoaHet(HttpContext.Session);
        TempData["ThanhCong"] = "Đã xoá toàn bộ giỏ hàng";
        return RedirectToAction(nameof(Index));
    }
}
