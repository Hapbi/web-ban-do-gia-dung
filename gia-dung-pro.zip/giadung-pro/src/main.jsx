import React,{useState} from "react";
import {createRoot} from "react-dom/client";
import {motion,AnimatePresence} from "framer-motion";
import {ShoppingCart,Search,User,Heart,Menu,X,ShieldCheck,Truck,RotateCcw,Headphones,ChevronRight,Plus,Minus} from "lucide-react";
import "./style.css";

const products=[
 {id:1,name:"Nồi chiên không dầu Philips 6.2L",price:2490000,old:3290000,cat:"Nhà bếp",img:"https://images.unsplash.com/photo-1585515320310-259814833e62?w=900&q=85"},
 {id:2,name:"Máy lọc không khí Xiaomi Smart 4",price:3190000,old:3990000,cat:"Điện gia dụng",img:"https://images.unsplash.com/photo-1585771724684-38269d6639fd?w=900&q=85"},
 {id:3,name:"Robot hút bụi Dreame L10s",price:7490000,old:8990000,cat:"Vệ sinh",img:"https://images.unsplash.com/photo-1558317374-067fb5f30001?w=900&q=85"},
 {id:4,name:"Máy xay sinh tố Panasonic",price:1290000,old:1690000,cat:"Nhà bếp",img:"https://images.unsplash.com/photo-1570222094114-d054a817e56b?w=900&q=85"},
 {id:5,name:"Ấm siêu tốc Bear 1.5L",price:590000,old:790000,cat:"Nhà bếp",img:"https://images.unsplash.com/photo-1594213114663-d94db9b171c4?w=900&q=85"},
 {id:6,name:"Máy hút bụi cầm tay Deerma",price:990000,old:1290000,cat:"Vệ sinh",img:"https://images.unsplash.com/photo-1558317374-067fb5f30001?w=900&q=85"}
];
const money=n=>n.toLocaleString("vi-VN")+"₫";

function App(){
 const [cart,setCart]=useState([]);
 const [login,setLogin]=useState(false);
 const [cartOpen,setCartOpen]=useState(false);
 const [menu,setMenu]=useState(false);
 const [search,setSearch]=useState("");
 const [cat,setCat]=useState("Tất cả");
 const [toast,setToast]=useState("");
 const [role,setRole]=useState("Khách hàng");

 const add=p=>{setCart(c=>[...c,p]);setCartOpen(true);setToast("Đã thêm sản phẩm vào giỏ");setTimeout(()=>setToast(""),1800)};
 const filtered=products.filter(p=>(cat==="Tất cả"||p.cat===cat)&&p.name.toLowerCase().includes(search.toLowerCase()));
 const total=cart.reduce((s,p)=>s+p.price,0);

 return <div className="app">
  <div className="top">MIỄN PHÍ VẬN CHUYỂN ĐƠN TỪ 500.000₫ <span>•</span> HỖ TRỢ ZALO 24/7</div>
  <header>
   <div className="brand"><div className="logo">G</div><div><b>GIA DỤNG</b><small>PRO</small></div></div>
   <div className="search"><Search size={20}/><input value={search} onChange={e=>setSearch(e.target.value)} placeholder="Tìm kiếm sản phẩm, thương hiệu..."/></div>
   <nav>
    <a href="#products">Sản phẩm</a><a href="#categories">Danh mục</a><a href="#seller">Đăng bán</a>
    <button className="icon" onClick={()=>setLogin(true)}><User size={21}/></button>
    <button className="cart" onClick={()=>setCartOpen(true)}><ShoppingCart size={20}/><span>{cart.length}</span></button>
   </nav>
   <button className="mobile" onClick={()=>setMenu(!menu)}>{menu?<X/>:<Menu/>}</button>
  </header>
  {menu&&<div className="mobileMenu"><a href="#products">Sản phẩm</a><a href="#categories">Danh mục</a><a href="#seller">Đăng bán</a><button onClick={()=>setLogin(true)}>Tài khoản</button></div>}

  <section className="hero">
   <div className="heroText">
    <p className="eyebrow">GIA DỤNG • SMART LIVING</p>
    <h1>Nâng tầm<br/><i>không gian sống.</i></h1>
    <p className="desc">Khám phá những thiết bị gia dụng thông minh, thiết kế đẹp và hiệu năng đáng tin cậy cho ngôi nhà hiện đại.</p>
    <div className="actions"><a href="#products" className="primary">Khám phá sản phẩm <ChevronRight size={18}/></a><a href="#seller" className="secondary">Bạn muốn bán hàng?</a></div>
    <div className="trust"><div><ShieldCheck/> <span>Chính hãng<br/><b>100% cam kết</b></span></div><div><Truck/><span>Giao nhanh<br/><b>Toàn quốc</b></span></div></div>
   </div>
   <div className="heroVisual"><div className="blob"></div><img src={products[0].img}/><div className="floating"><b>-24%</b><small>Ưu đãi hôm nay</small></div></div>
  </section>

  <section className="strip"><div><Truck/> Miễn phí giao hàng</div><div><RotateCcw/> Đổi trả 7 ngày</div><div><ShieldCheck/> Bảo hành chính hãng</div><div><Headphones/> Hỗ trợ tận tâm</div></section>

  <section id="categories" className="categories"><div className="sectionHead"><div><p className="eyebrow">KHÁM PHÁ</p><h2>Danh mục nổi bật</h2></div><a href="#products">Xem tất cả <ChevronRight/></a></div>
   <div className="catGrid">{["Nhà bếp","Điện gia dụng","Vệ sinh","Đồ dùng thông minh"].map((x,i)=><button key={x} onClick={()=>{setCat(x);document.querySelector("#products").scrollIntoView({behavior:"smooth"})}} className="catCard"><span>0{i+1}</span><h3>{x}</h3><small>{i===0?"Máy xay • Nồi chiên • Ấm":i===1?"Máy lọc • Quạt • Máy hút":"Robot • Máy hút • Phụ kiện"}</small><ChevronRight/></button>)}</div>
  </section>

  <section id="products" className="products"><div className="sectionHead"><div><p className="eyebrow">BEST SELLER</p><h2>Sản phẩm được yêu thích</h2></div><div className="filters">{["Tất cả","Nhà bếp","Điện gia dụng","Vệ sinh"].map(x=><button className={cat===x?"active":""} onClick={()=>setCat(x)}>{x}</button>)}</div></div>
   <div className="productGrid">{filtered.map(p=><motion.article layout key={p.id} className="product"><div className="pic"><img src={p.img}/><button className="heart"><Heart size={18}/></button>{p.old>p.price&&<b className="sale">SALE</b>}</div><div className="pbody"><small>{p.cat}</small><h3>{p.name}</h3><div className="price">{money(p.price)} <del>{money(p.old)}</del></div><button className="add" onClick={()=>add(p)}>Thêm vào giỏ <Plus size={18}/></button></div></motion.article>)}</div>
  </section>

  <section id="seller" className="seller"><div><p className="eyebrow">DÀNH CHO KHÁCH HÀNG</p><h2>Có đồ gia dụng muốn bán?</h2><p>Đăng sản phẩm của bạn, đặt giá và tiếp cận cộng đồng mua sắm trên Gia Dụng Pro.</p><button onClick={()=>setLogin(true)}>Đăng nhập để bán hàng <ChevronRight/></button></div><div className="sellerShape">SELL<br/><i>SMART.</i></div></section>

  <footer><div className="brand"><div className="logo">G</div><div><b>GIA DỤNG</b><small>PRO</small></div></div><p>Thiết bị tốt hơn. Cuộc sống tiện nghi hơn.</p><div><b>Hỗ trợ Zalo 24/7</b><br/>Tư vấn • Đổi trả • Bảo hành</div></footer>

  <AnimatePresence>{toast&&<motion.div initial={{y:30,opacity:0}} animate={{y:0,opacity:1}} exit={{opacity:0}} className="toast">{toast}</motion.div>}</AnimatePresence>

  {cartOpen&&<div className="overlay" onClick={()=>setCartOpen(false)}><motion.aside initial={{x:"100%"}} animate={{x:0}} className="drawer" onClick={e=>e.stopPropagation()}><div className="drawerHead"><h2>Giỏ hàng</h2><button onClick={()=>setCartOpen(false)}><X/></button></div>{cart.length===0?<div className="empty">Giỏ hàng đang trống.<br/><a href="#products" onClick={()=>setCartOpen(false)}>Khám phá sản phẩm</a></div>:<><div className="cartItems">{cart.map((p,i)=><div className="cartItem" key={i}><img src={p.img}/><div><b>{p.name}</b><span>{money(p.price)}</span></div><button onClick={()=>setCart(c=>c.filter((_,j)=>j!==i))}><X size={15}/></button></div>)}</div><div className="checkout"><div><span>Tạm tính</span><b>{money(total)}</b></div><button>Tiến hành thanh toán</button></div></>}</motion.aside></div>}

  {login&&<div className="modalBg" onClick={()=>setLogin(false)}><motion.div initial={{scale:.94,opacity:0}} animate={{scale:1,opacity:1}} className="modal" onClick={e=>e.stopPropagation()}><button className="close" onClick={()=>setLogin(false)}><X/></button><p className="eyebrow">GIA DỤNG PRO</p><h2>Chào mừng trở lại</h2><p className="muted">Đăng nhập để mua hàng, xem lịch sử và đăng bán sản phẩm.</p><input placeholder="Email / số điện thoại"/><input type="password" placeholder="Mật khẩu"/><button className="primary full" onClick={()=>{setLogin(false);setRole("Khách hàng")}}>Đăng nhập</button><p className="register">Chưa có tài khoản? <b>Đăng ký ngay</b></p></motion.div></div>}
 </div>
}
createRoot(document.getElementById("root")).render(<App/>);