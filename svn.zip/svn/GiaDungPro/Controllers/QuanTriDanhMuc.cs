using CuaHangGiaDungPro.Data;
using CuaHangGiaDungPro.Helpers;
using CuaHangGiaDungPro.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace CuaHangGiaDungPro.Controllers;

public partial class QuanTriController
{
    [Route("quan-tri/danh-muc")]
    public async Task<IActionResult> DanhMuc()
    {
        if (!QuyenHelper.CoQuyen(User, "danhmuc")) return Forbid();
        return View(await _db.DanhMucs.Include(x => x.DanhSachSanPham).OrderBy(x => x.Id).ToListAsync());
    }

    [HttpPost, Route("quan-tri/danh-muc/luu")]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> LuuDanhMuc(int id, string ten, string icon)
    {
        if (!QuyenHelper.CoQuyen(User, "danhmuc")) return Forbid();
        if (string.IsNullOrWhiteSpace(ten))
        {
            TempData["Loi"] = "Tên danh mục không được trống";
            return RedirectToAction(nameof(DanhMuc));
        }
        DanhMuc dm;
        if (id == 0) { dm = new DanhMuc(); _db.DanhMucs.Add(dm); }
        else
        {
            dm = await _db.DanhMucs.FindAsync(id);
            if (dm == null) return NotFound();
        }
        dm.Ten = ten.Trim();
        dm.Icon = string.IsNullOrWhiteSpace(icon) ? "📦" : icon.Trim();
        await _db.SaveChangesAsync();
        TempData["ThanhCong"] = "Đã lưu danh mục";
        return RedirectToAction(nameof(DanhMuc));
    }

    [HttpPost, Route("quan-tri/danh-muc/{id:int}/xoa")]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> XoaDanhMuc(int id)
    {
        if (!QuyenHelper.CoQuyen(User, "danhmuc")) return Forbid();
        var dm = await _db.DanhMucs.Include(x => x.DanhSachSanPham).FirstOrDefaultAsync(x => x.Id == id);
        if (dm == null) return NotFound();
        if (dm.DanhSachSanPham.Any())
        {
            TempData["Loi"] = "Không xóa được: danh mục còn sản phẩm";
            return RedirectToAction(nameof(DanhMuc));
        }
        _db.DanhMucs.Remove(dm);
        await _db.SaveChangesAsync();
        TempData["ThanhCong"] = "Đã xóa danh mục";
        return RedirectToAction(nameof(DanhMuc));
    }

    [Authorize(Roles = "Admin"), Route("quan-tri/banner")]
    public async Task<IActionResult> Banner()
        => View(await _db.Banners.OrderBy(x => x.ThuTu).ThenBy(x => x.Id).ToListAsync());

    [HttpPost, Authorize(Roles = "Admin"), Route("quan-tri/banner/luu")]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> LuuBanner(Banner input)
    {
        Banner b;
        if (input.Id == 0) { b = new Banner(); _db.Banners.Add(b); }
        else
        {
            b = await _db.Banners.FindAsync(input.Id);
            if (b == null) return NotFound();
        }
        b.TieuDe = input.TieuDe?.Trim() ?? "";
        b.AnhUrl = input.AnhUrl?.Trim() ?? "";
        b.LienKet = input.LienKet?.Trim() ?? "";
        b.ThuTu = input.ThuTu;
        b.DangHienThi = input.DangHienThi;
        await _db.SaveChangesAsync();
        TempData["ThanhCong"] = "Đã lưu banner";
        return RedirectToAction(nameof(Banner));
    }

    [HttpPost, Authorize(Roles = "Admin"), Route("quan-tri/banner/{id:int}/xoa")]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> XoaBanner(int id)
    {
        var b = await _db.Banners.FindAsync(id);
        if (b != null)
        {
            _db.Banners.Remove(b);
            await _db.SaveChangesAsync();
            TempData["ThanhCong"] = "Đã xóa banner";
        }
        return RedirectToAction(nameof(Banner));
    }

    [Authorize(Roles = "Admin"), Route("quan-tri/bai-viet")]
    public async Task<IActionResult> BaiViet()
        => View(await _db.BaiViets.OrderByDescending(x => x.NgayTao).ToListAsync());

    [HttpGet, Authorize(Roles = "Admin"), Route("quan-tri/bai-viet/sua/{id:int?}")]
    public async Task<IActionResult> SuaBaiViet(int? id)
    {
        if (id == null) return View(new BaiViet { DaDang = true });
        var bv = await _db.BaiViets.FindAsync(id);
        return bv == null ? NotFound() : View(bv);
    }

    [HttpPost, Authorize(Roles = "Admin"), Route("quan-tri/bai-viet/luu")]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> LuuBaiViet(BaiViet input)
    {
        if (string.IsNullOrWhiteSpace(input.TieuDe))
        {
            TempData["Loi"] = "Vui lòng nhập tiêu đề";
            return View("SuaBaiViet", input);
        }
        BaiViet bv;
        if (input.Id == 0)
        {
            bv = new BaiViet { TacGia = User.Identity?.Name ?? "" };
            _db.BaiViets.Add(bv);
        }
        else
        {
            bv = await _db.BaiViets.FindAsync(input.Id);
            if (bv == null) return NotFound();
        }
        bv.TieuDe = input.TieuDe.Trim();
        bv.TomTat = input.TomTat?.Trim() ?? "";
        bv.NoiDung = input.NoiDung?.Trim() ?? "";
        bv.AnhBia = input.AnhBia?.Trim() ?? "";
        bv.DaDang = input.DaDang;
        await _db.SaveChangesAsync();
        TempData["ThanhCong"] = "Đã lưu bài viết";
        return RedirectToAction(nameof(BaiViet));
    }

    [HttpPost, Authorize(Roles = "Admin"), Route("quan-tri/bai-viet/{id:int}/xoa")]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> XoaBaiViet(int id)
    {
        var bv = await _db.BaiViets.FindAsync(id);
        if (bv != null)
        {
            _db.BaiViets.Remove(bv);
            await _db.SaveChangesAsync();
            TempData["ThanhCong"] = "Đã xóa bài viết";
        }
        return RedirectToAction(nameof(BaiViet));
    }

    [HttpPost, Authorize(Roles = "Admin"), Route("quan-tri/bai-viet/{id:int}/doi-trang-thai")]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> DoiTrangThaiBaiViet(int id)
    {
        var bv = await _db.BaiViets.FindAsync(id);
        if (bv != null)
        {
            bv.DaDang = !bv.DaDang;
            await _db.SaveChangesAsync();
            TempData["ThanhCong"] = bv.DaDang ? "Đã đăng bài viết" : "Đã ẩn bài viết";
        }
        return RedirectToAction(nameof(BaiViet));
    }

    [Route("quan-tri/lien-he")]
    public async Task<IActionResult> LienHe(string? trangThai)
    {
        if (!QuyenHelper.CoQuyen(User, "donhang")) return Forbid();
        var query = _db.LienHes.AsQueryable();
        if (!string.IsNullOrWhiteSpace(trangThai)) query = query.Where(x => x.TrangThai == trangThai);
        ViewBag.TrangThai = trangThai;
        ViewBag.SoMoi = await _db.LienHes.CountAsync(x => x.TrangThai == "Moi");
        return View(await query.OrderByDescending(x => x.NgayTao).ToListAsync());
    }

    [HttpPost, Route("quan-tri/lien-he/{id:int}/cap-nhat")]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> CapNhatLienHe(int id, string trangThai, string ghiChuXuLy)
    {
        if (!QuyenHelper.CoQuyen(User, "donhang")) return Forbid();
        var lh = await _db.LienHes.FindAsync(id);
        if (lh == null) return NotFound();
        var hopLe = new[] { "Moi", "DangXuLy", "DaXuLy" };
        if (!hopLe.Contains(trangThai)) return BadRequest();
        lh.TrangThai = trangThai;
        lh.GhiChuXuLy = ghiChuXuLy?.Trim() ?? "";
        await _db.SaveChangesAsync();
        TempData["ThanhCong"] = "Đã cập nhật liên hệ";
        return RedirectToAction(nameof(LienHe));
    }
}
