using System.Security.Claims;
using Microsoft.AspNetCore.Authorization;

namespace HomeAppliances.Web.Infrastructure;

public static class AppRoles
{
    public const string Customer = "Customer";
    public const string Employee = "Employee";
    public const string Admin = "Admin";
    public static readonly string[] All = { Customer, Employee, Admin };
}

public static class AppPolicies
{
    public const string AdminOnly = "AdminOnly";
    public const string StaffOnly = "StaffOnly";
    /// <summary>Admins always; employees only when an administrator granted them the permission claim.</summary>
    public const string CanVerifyPayments = "CanVerifyPayments";
}

public static class AppClaims
{
    public const string PermissionType = "permission";
    public const string VerifyPayments = "verify_payments";
}

public static class SecurityExtensions
{
    public static void AddAppPolicies(this AuthorizationOptions o)
    {
        o.AddPolicy(AppPolicies.AdminOnly, p => p.RequireRole(AppRoles.Admin));
        o.AddPolicy(AppPolicies.StaffOnly, p => p.RequireRole(AppRoles.Admin, AppRoles.Employee));
        o.AddPolicy(AppPolicies.CanVerifyPayments, p => p.RequireAssertion(ctx =>
            ctx.User.IsInRole(AppRoles.Admin) ||
            (ctx.User.IsInRole(AppRoles.Employee) && ctx.User.HasClaim(AppClaims.PermissionType, AppClaims.VerifyPayments))));
    }

    public static string? GetUserId(this ClaimsPrincipal u) => u.FindFirstValue(ClaimTypes.NameIdentifier);
    public static string GetEmail(this ClaimsPrincipal u) => u.FindFirstValue(ClaimTypes.Email) ?? u.Identity?.Name ?? "";
}
