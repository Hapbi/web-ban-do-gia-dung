using Microsoft.AspNetCore.Mvc;
using NovaShop.Data;
using NovaShop.Models;

namespace NovaShop.Controllers;

public class ContactController : Controller
{
    private readonly AppDbContext _db;
    public ContactController(AppDbContext db) => _db = db;

    [HttpGet, Route("lien-he")]
    public IActionResult Index() => View(new ContactMessage());

    [HttpPost, Route("lien-he")]
    public async Task<IActionResult> Index(ContactMessage m)
    {
        if (string.IsNullOrWhiteSpace(m.FullName) || string.IsNullOrWhiteSpace(m.Message) ||
            (string.IsNullOrWhiteSpace(m.Email) && string.IsNullOrWhiteSpace(m.Phone)))
        {
            TempData["Error"] = "Vui lòng nhập đủ họ tên, nội dung và ít nhất email hoặc SĐT";
            return View(m);
        }
        m.FullName = m.FullName.Trim();
        m.Email = (m.Email ?? "").Trim();
        m.Phone = (m.Phone ?? "").Trim();
        m.Subject = (m.Subject ?? "").Trim();
        m.Message = m.Message.Trim();
        m.Status = ContactStatus.New;
        m.CreatedAt = DateTime.Now;
        _db.ContactMessages.Add(m);
        await _db.SaveChangesAsync();
        TempData["Success"] = "Cảm ơn bạn! Shop sẽ liên hệ sớm.";
        return RedirectToAction("Index", "Home");
    }
}
