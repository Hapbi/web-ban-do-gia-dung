using System.Net;
using System.Net.Mail;
using Microsoft.Extensions.Options;

namespace HomeAppliances.Web.Services;

public interface IEmailService
{
    /// <summary>False when SMTP is not configured; emails are only written to the log.</summary>
    bool IsEnabled { get; }
    Task SendAsync(string to, string subject, string htmlBody);
}

/// <summary>Sends mail through SMTP using the "Email" configuration section.</summary>
public class SmtpEmailService : IEmailService
{
    private readonly EmailOptions _o;
    private readonly ILogger<SmtpEmailService> _log;

    public SmtpEmailService(IOptions<EmailOptions> o, ILogger<SmtpEmailService> log) { _o = o.Value; _log = log; }

    public bool IsEnabled => true;

    public async Task SendAsync(string to, string subject, string htmlBody)
    {
        using var client = new SmtpClient(_o.SmtpHost, _o.SmtpPort) { EnableSsl = _o.UseSsl };
        if (!string.IsNullOrEmpty(_o.Username)) client.Credentials = new NetworkCredential(_o.Username, _o.Password);
        using var msg = new MailMessage { From = new MailAddress(_o.FromAddress, _o.FromName), Subject = subject, Body = htmlBody, IsBodyHtml = true };
        msg.To.Add(to);
        await client.SendMailAsync(msg);
        _log.LogInformation("Email sent to {To}: {Subject}", to, subject);
    }
}

/// <summary>Used when email is not configured: writes the message to the log so developers can copy links.</summary>
public class LogEmailService : IEmailService
{
    private readonly ILogger<LogEmailService> _log;
    public LogEmailService(ILogger<LogEmailService> log) => _log = log;
    public bool IsEnabled => false;

    public Task SendAsync(string to, string subject, string htmlBody)
    {
        _log.LogWarning("EMAIL NOT SENT (SMTP disabled). To: {To} | Subject: {Subject} | Body: {Body}", to, subject, htmlBody);
        return Task.CompletedTask;
    }
}
