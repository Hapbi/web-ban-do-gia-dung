using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using HomeAppliances.Web.Controllers.Base;
using HomeAppliances.Web.Infrastructure;
using HomeAppliances.Web.Services;

namespace HomeAppliances.Web.Areas.Admin.Controllers;

[Area("Admin"), Authorize(Policy = AppPolicies.AdminOnly)]
public class OrdersController : StaffOrdersControllerBase
{
    public OrdersController(IOrderService o, ISettingsService s, IFileStorage f, IAuthorizationService a) : base(o, s, f, a) { }
}
