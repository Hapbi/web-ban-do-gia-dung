using System.Security.Claims;
using CuaHangGiaDungPro.Data;
using CuaHangGiaDungPro.Helpers;
using CuaHangGiaDungPro.Models;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace CuaHangGiaDungPro.Controllers;

public class TaiKhoanController : Controller
{
    private readonly AppDb _db;
    public TaiKhoanController(AppDb db) => _db = db;

    [Route("tai-khoan/dang-nhap")]
    public IActionResult DangNhap(string? returnUrl = null)
    {
        ViewBag.ReturnUrl = returnUrl;
        return View();
    }

    [HttpPost, Route("tai-khoan/dang-nhap")]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> DangNhap(string email, string matKhau, string? returnUrl)
    {
        if (string.IsNullOrWhiteSpace(email) || string.IsNullOrWhiteSpace(matKhau))
        {
            TempData["Loi"] = "Vui lòng nhập email và mật khẩu";
            return View();
        }
        email = email.Trim().ToLower();
        var user = await _db.NguoiDungs.FirstOrDefaultAsync(x => x.Email.ToLower() == email);
        if (user == null || user.BiKhoa || !MatKhauHelper.KiemTra(matKhau, user.MatKhauHash))
        {
            TempData["Loi"] = "Email hoặc mật khẩu không đúng";
            return View();
        }

        if (MatKhauHelper.LaHashCu(user.MatKhauHash))
        {
            user.MatKhauHash = MatKhauHelper.Hash(matKhau);
            await _db.SaveChangesAsync();
        }

        var claims = new List<Claim>
        {
            new(ClaimTypes.NameIdentifier, user.Id.ToString()),
            new(ClaimTypes.Name, user.HoTen),
            new(ClaimTypes.Email, user.Email),
            new(ClaimTypes.Role, user.VaiTro)
        };
        foreach (var q in QuyenHelper.HieuLuc(user.VaiTro, user.Quyen))
            claims.Add(new Claim("Quyen", q));

        var identity = new ClaimsIdentity(claims, CookieAuthenticationDefaults.AuthenticationScheme);
        await HttpContext.SignInAsync(new ClaimsPrincipal(identity));

        TempData["ThanhCong"] = $"Xin chào {user.HoTen}!";

        if (!string.IsNullOrWhiteSpace(returnUrl) && Url.IsLocalUrl(returnUrl))
            return Redirect(returnUrl);

        return user.VaiTro == VaiTro.KhachHang
            ? RedirectToAction("Index", "TrangChu")
            : RedirectToAction("Dashboard", "QuanTri");
    }

    [HttpPost, Route("tai-khoan/dang-xuat")]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> DangXuat()
    {
        await HttpContext.SignOutAsync(CookieAuthenticationDefaults.AuthenticationScheme);
        return RedirectToAction("Index", "TrangChu");
    }

    [Route("tai-khoan/dang-ky")]
    public IActionResult DangKy() => View();

    [HttpPost, Route("tai-khoan/dang-ky")]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> DangKy(string hoTen, string email, string dienThoai, string matKhau, string xacNhanMatKhau)
    {
        if (string.IsNullOrWhiteSpace(hoTen) || string.IsNullOrWhiteSpace(email) || string.IsNullOrWhiteSpace(matKhau))
        {
            TempData["Loi"] = "Vui lòng nhập đầy đủ thông tin";
            return View();
        }
        if (matKhau.Length < 8) { TempData["Loi"] = "Mật khẩu tối thiểu 8 ký tự"; return View(); }
        if (matKhau != xacNhanMatKhau) { TempData["Loi"] = "Mật khẩu xác nhận không khớp"; return View(); }

        email = email.Trim().ToLower();
        if (await _db.NguoiDungs.AnyAsync(x => x.Email.ToLower() == email))
        {
            TempData["Loi"] = "Email đã tồn tại";
            return View();
        }

        var user = new NguoiDung
        {
            Email = email, HoTen = hoTen.Trim(),
            DienThoai = dienThoai?.Trim() ?? "",
            VaiTro = VaiTro.KhachHang,
            MatKhauHash = MatKhauHelper.Hash(matKhau)
        };
        _db.NguoiDungs.Add(user);
        await _db.SaveChangesAsync();

        var claims = new List<Claim>
        {
            new(ClaimTypes.NameIdentifier, user.Id.ToString()),
            new(ClaimTypes.Name, user.HoTen),
            new(ClaimTypes.Email, user.Email),
            new(ClaimTypes.Role, user.VaiTro)
        };
        var identity = new ClaimsIdentity(claims, CookieAuthenticationDefaults.AuthenticationScheme);
        await HttpContext.SignInAsync(new ClaimsPrincipal(identity));

        TempData["ThanhCong"] = "Đăng ký thành công!";
        return RedirectToAction("Index", "TrangChu");
    }

    [Route("tai-khoan/tu-choi")]
    public IActionResult TuChoi() => Content("Bạn không có quyền truy cập trang này.");
}
