using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using HomeAppliances.Web.Data;
using HomeAppliances.Web.Infrastructure;
using HomeAppliances.Web.Models.ViewModels;
using HomeAppliances.Web.Services;

namespace HomeAppliances.Web.Areas.Employee.Controllers;

[Area("Employee"), Authorize(Policy = AppPolicies.StaffOnly)]
public class ProductsController : Controller
{
    private readonly IProductAdminService _products; private readonly ApplicationDbContext _db;
    public ProductsController(IProductAdminService products, ApplicationDbContext db) { _products=products; _db=db; }
    public async Task<IActionResult> Index(string? q, int? categoryId, bool? active, bool lowStock=false, int page=1)
    {
        ViewData["Q"]=q; ViewData["CategoryId"]=categoryId; ViewData["Active"]=active; ViewData["LowStock"]=lowStock; ViewData["Categories"]=await CategoryItemsAsync();
        return View(await _products.SearchAsync(q, categoryId, active, lowStock, page));
    }
    public async Task<IActionResult> Edit(int id)
    {
        var p=await _products.GetAsync(id); if(p==null)return NotFound();
        return View(await FillAsync(new ProductEditViewModel { Id=p.Id,Name=p.Name,Slug=p.Slug,Description=p.Description,Brand=p.Brand,CategoryId=p.CategoryId,OriginalPrice=p.OriginalPrice,DiscountPrice=p.DiscountPrice,StockQuantity=p.StockQuantity,IsFeatured=p.IsFeatured,IsActive=p.IsActive,SpecificationsText=string.Join("\n",p.Specifications.OrderBy(x=>x.SortOrder).Select(x=>$"{x.Name}: {x.Value}")),Images=p.Images.OrderByDescending(x=>x.IsPrimary).ThenBy(x=>x.SortOrder).ToList()}));
    }
    [HttpPost, RequestSizeLimit(30*1024*1024), RequestFormLimits(MultipartBodyLengthLimit=30*1024*1024)]
    public async Task<IActionResult> Save(ProductEditViewModel vm, List<IFormFile>? images)
    {
        if(ModelState.IsValid){var r=await _products.SaveAsync(vm,images??new());if(r.Succeeded){TempData["Success"]="Đã lưu sản phẩm.";return RedirectToAction(nameof(Edit),new{id=r.Value});}ModelState.AddModelError("",r.Error!);}
        if(vm.Id!=0) vm.Images=(await _products.GetAsync(vm.Id))?.Images.ToList()??new();
        return View("Edit",await FillAsync(vm));
    }
    [HttpPost] public async Task<IActionResult> Toggle(int id){var r=await _products.ToggleActiveAsync(id);TempData[r.Succeeded?"Success":"Error"]=r.Succeeded?"Đã đổi trạng thái bán.":r.Error;return RedirectToAction(nameof(Index));}
    private async Task<List<SelectListItem>> CategoryItemsAsync() => (await _db.Categories.AsNoTracking().OrderBy(c=>c.DisplayOrder).ToListAsync()).Select(c=>new SelectListItem(c.Name,c.Id.ToString())).ToList();
    private async Task<ProductEditViewModel> FillAsync(ProductEditViewModel vm){vm.Categories=await CategoryItemsAsync();return vm;}
}
