using System.Security.Claims;
using HomeAppliances.Web.Data;
using HomeAppliances.Web.Models.Entities;

namespace HomeAppliances.Web.Services;

public interface IAuditService
{
    /// <summary>Records a sensitive action for the current user (or "system" when there is none).</summary>
    Task LogAsync(string action, string entityType, string? entityId, string? details = null);
}

public class AuditService : IAuditService
{
    private readonly ApplicationDbContext _db;
    private readonly IHttpContextAccessor _http;

    public AuditService(ApplicationDbContext db, IHttpContextAccessor http) { _db = db; _http = http; }

    public async Task LogAsync(string action, string entityType, string? entityId, string? details = null)
    {
        var ctx = _http.HttpContext;
        var user = ctx?.User;
        _db.AuditLogs.Add(new AuditLog
        {
            UserId = user?.FindFirstValue(ClaimTypes.NameIdentifier),
            UserEmail = user?.FindFirstValue(ClaimTypes.Email) ?? user?.Identity?.Name ?? "system",
            Action = action,
            EntityType = entityType,
            EntityId = entityId,
            Details = details is { Length: > 2000 } ? details[..2000] : details,
            IpAddress = ctx?.Connection.RemoteIpAddress?.ToString(),
            CreatedUtc = DateTime.UtcNow
        });
        await _db.SaveChangesAsync();
    }
}
