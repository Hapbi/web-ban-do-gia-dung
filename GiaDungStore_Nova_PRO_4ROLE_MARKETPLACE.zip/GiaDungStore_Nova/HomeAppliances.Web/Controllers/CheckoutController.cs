using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using HomeAppliances.Web.Data;
using HomeAppliances.Web.Infrastructure;
using HomeAppliances.Web.Models.Entities;
using HomeAppliances.Web.Models.ViewModels;
using HomeAppliances.Web.Services;

namespace HomeAppliances.Web.Controllers;

/// <summary>Checkout for customers. Totals shown here are recomputed on the server when the order is created.</summary>
[Authorize(Roles = AppRoles.Customer)]
[Route("thanh-toan")]
public class CheckoutController : Controller
{
    private readonly ICartService _cart;
    private readonly IOrderService _orders;
    private readonly ApplicationDbContext _db;
    private readonly UserManager<ApplicationUser> _users;

    public CheckoutController(ICartService cart, IOrderService orders, ApplicationDbContext db, UserManager<ApplicationUser> users)
    { _cart = cart; _orders = orders; _db = db; _users = users; }

    private string Uid => User.GetUserId()!;

    [HttpGet("")]
    public async Task<IActionResult> Index()
    {
        var cart = await _cart.GetAsync();
        if (cart.IsEmpty) { TempData["Error"] = "Giỏ hàng của bạn đang trống."; return RedirectToAction("Index", "Cart"); }
        if (cart.HasProblems) { TempData["Error"] = "Một số sản phẩm không đủ số lượng. Vui lòng điều chỉnh giỏ hàng."; return RedirectToAction("Index", "Cart"); }

        var addresses = await _db.ShippingAddresses.AsNoTracking().Where(a => a.UserId == Uid).OrderByDescending(a => a.IsDefault).ToListAsync();
        var vm = new CheckoutViewModel { Cart = cart, SavedAddresses = addresses };
        var def = addresses.FirstOrDefault();
        if (def != null) { vm.ReceiverName = def.ReceiverName; vm.Phone = def.Phone; vm.Address = def.Address; }
        else
        {
            var u = await _users.GetUserAsync(User);
            vm.ReceiverName = u?.FullName ?? ""; vm.Phone = u?.PhoneNumber ?? "";
        }
        return View(vm);
    }

    [HttpPost("")]
    public async Task<IActionResult> Index(CheckoutViewModel vm)
    {
        async Task<IActionResult> Redisplay()
        {
            vm.Cart = await _cart.GetAsync();
            vm.SavedAddresses = await _db.ShippingAddresses.AsNoTracking().Where(a => a.UserId == Uid).OrderByDescending(a => a.IsDefault).ToListAsync();
            return View(vm);
        }

        if (!ModelState.IsValid) return await Redisplay();

        var result = await _orders.PlaceOrderAsync(Uid, User.GetEmail(), new CheckoutInput(vm.ReceiverName, vm.Phone, vm.Address, vm.Notes));
        if (!result.Succeeded)
        {
            ModelState.AddModelError("", result.Error!);
            return await Redisplay();
        }

        if (vm.SaveAddress && !await _db.ShippingAddresses.AnyAsync(a => a.UserId == Uid && a.Address == vm.Address.Trim() && a.Phone == vm.Phone.Trim()))
        {
            var hasAny = await _db.ShippingAddresses.AnyAsync(a => a.UserId == Uid);
            _db.ShippingAddresses.Add(new ShippingAddress { UserId = Uid, ReceiverName = vm.ReceiverName.Trim(), Phone = vm.Phone.Trim(), Address = vm.Address.Trim(), IsDefault = !hasAny });
            await _db.SaveChangesAsync();
        }
        TempData["Success"] = "Đặt hàng thành công. Vui lòng chuyển khoản và tải biên lai để hoàn tất.";
        return RedirectToAction("Details", "Orders", new { orderNumber = result.Value!.OrderNumber });
    }
}
