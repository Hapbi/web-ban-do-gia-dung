using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using NovaShop.Data;
using NovaShop.Helpers;
using NovaShop.Models;
using NovaShop.Services;
using System.Security.Claims;

namespace NovaShop.Controllers;

[Authorize(Roles = "Admin,Staff")]
[Route("quan-tri")]
public class AdminController : Controller
{
    private readonly AppDbContext _db;
    private readonly ReportService _reports;
    private readonly AuditService _audit;

    public AdminController(AppDbContext db, ReportService reports, AuditService audit)
    {
        _db = db;
        _reports = reports;
        _audit = audit;
    }

    [HttpGet("")]
    public async Task<IActionResult> Index()
    {
        if (!User.IsInRole("Admin") && !User.Can("revenue.view") && !User.Can("stock.view") && !User.Can("order.view"))
            return Forbid();
        ViewBag.CanRevenue = User.Can("revenue.view");
        ViewBag.CanOrders = User.Can("order.view");
        return View(await _reports.GetDashboardAsync());
    }

    [HttpGet("san-pham")]
    [RequirePerm("product.manage")]
    public async Task<IActionResult> Products(string? q, bool showHidden = false)
    {
        var query = _db.Products.Include(p => p.Category).Include(p => p.Brand).AsQueryable();
        if (!showHidden) query = query.Where(p => p.IsActive);
        if (!string.IsNullOrWhiteSpace(q))
            query = query.Where(p => p.Name.Contains(q) || p.Slug.Contains(q));
        ViewBag.Query = q;
        ViewBag.ShowHidden = showHidden;
        return View(await query.OrderByDescending(p => p.CreatedAt).Take(300).ToListAsync());
    }

    [HttpGet("san-pham/them")]
    [RequirePerm("product.manage")]
    public async Task<IActionResult> CreateProduct()
    {
        var vm = new ProductEditVM();
        await LoadProductOptions(vm);
        return View("ProductEdit", vm);
    }

    [HttpPost("san-pham/them")]
    [ValidateAntiForgeryToken]
    [RequirePerm("product.manage")]
    public async Task<IActionResult> CreateProduct(ProductEditVM vm)
    {
        if (!ModelState.IsValid)
        {
            await LoadProductOptions(vm);
            return View("ProductEdit", vm);
        }
        var slug = string.IsNullOrWhiteSpace(vm.Slug) ? Ext.Slugify(vm.Name) : Ext.Slugify(vm.Slug);
        if (await _db.Products.AnyAsync(p => p.Slug == slug))
            slug += "-" + Guid.NewGuid().ToString("N")[..5];

        var product = new Product
        {
            Name = vm.Name.Trim(), Slug = slug, ShortDescription = vm.ShortDescription ?? "",
            Description = vm.Description ?? "", CategoryId = vm.CategoryId, BrandId = vm.BrandId,
            OriginalPrice = vm.OriginalPrice, SalePrice = vm.SalePrice, Stock = vm.Stock,
            IsFeatured = vm.IsFeatured, IsActive = vm.IsActive, Tags = vm.Tags ?? "",
            CreatedAt = DateTime.Now, UpdatedAt = DateTime.Now
        };
        AddImage(product, vm.ImageUrlsText);
        _db.Products.Add(product);
        await _db.SaveChangesAsync();
        await Log("Tạo sản phẩm", "Product", product.Id.ToString(), product.Name);
        TempData["Success"] = "Đã thêm sản phẩm.";
        return RedirectToAction(nameof(Products));
    }

    [HttpGet("san-pham/sua/{id:int}")]
    [RequirePerm("product.manage")]
    public async Task<IActionResult> EditProduct(int id)
    {
        var p = await _db.Products.Include(x => x.Images).FirstOrDefaultAsync(x => x.Id == id);
        if (p == null) return NotFound();
        var vm = new ProductEditVM
        {
            Id = p.Id, Name = p.Name, Slug = p.Slug, ShortDescription = p.ShortDescription,
            Description = p.Description, CategoryId = p.CategoryId, BrandId = p.BrandId,
            OriginalPrice = p.OriginalPrice, SalePrice = p.SalePrice, Stock = p.Stock,
            IsFeatured = p.IsFeatured, IsActive = p.IsActive, Tags = p.Tags,
            ImageUrlsText = string.Join(Environment.NewLine, p.Images.OrderByDescending(x => x.IsPrimary).Select(x => x.Url))
        };
        await LoadProductOptions(vm);
        return View("ProductEdit", vm);
    }

    [HttpPost("san-pham/sua/{id:int}")]
    [ValidateAntiForgeryToken]
    [RequirePerm("product.manage")]
    public async Task<IActionResult> EditProduct(int id, ProductEditVM vm)
    {
        if (id != vm.Id) return BadRequest();
        var p = await _db.Products.Include(x => x.Images).FirstOrDefaultAsync(x => x.Id == id);
        if (p == null) return NotFound();
        if (!ModelState.IsValid)
        {
            await LoadProductOptions(vm);
            return View("ProductEdit", vm);
        }
        p.Name = vm.Name.Trim();
        var slug = string.IsNullOrWhiteSpace(vm.Slug) ? Ext.Slugify(vm.Name) : Ext.Slugify(vm.Slug);
        if (await _db.Products.AnyAsync(x => x.Id != id && x.Slug == slug))
            slug += "-" + Guid.NewGuid().ToString("N")[..5];
        p.Slug = slug;
        p.ShortDescription = vm.ShortDescription ?? "";
        p.Description = vm.Description ?? "";
        p.CategoryId = vm.CategoryId;
        p.BrandId = vm.BrandId;
        p.OriginalPrice = vm.OriginalPrice;
        p.SalePrice = vm.SalePrice;
        p.Stock = vm.Stock;
        p.IsFeatured = vm.IsFeatured;
        p.IsActive = vm.IsActive;
        p.Tags = vm.Tags ?? "";
        p.UpdatedAt = DateTime.Now;
        _db.ProductImages.RemoveRange(p.Images);
        p.Images.Clear();
        AddImage(p, vm.ImageUrlsText);
        await _db.SaveChangesAsync();
        await Log("Cập nhật sản phẩm", "Product", p.Id.ToString(), p.Name);
        TempData["Success"] = "Đã cập nhật sản phẩm.";
        return RedirectToAction(nameof(Products));
    }

    [HttpPost("san-pham/an-hien/{id:int}")]
    [ValidateAntiForgeryToken]
    [RequirePerm("product.manage")]
    public async Task<IActionResult> ToggleProduct(int id)
    {
        var p = await _db.Products.FindAsync(id);
        if (p == null) return NotFound();
        p.IsActive = !p.IsActive;
        p.UpdatedAt = DateTime.Now;
        await _db.SaveChangesAsync();
        await Log(p.IsActive ? "Hiện sản phẩm" : "Ẩn sản phẩm", "Product", id.ToString(), p.Name);
        TempData["Success"] = p.IsActive ? "Đã hiển thị sản phẩm." : "Đã ẩn sản phẩm.";
        return RedirectToAction(nameof(Products));
    }

    [HttpPost("san-pham/xoa/{id:int}")]
    [ValidateAntiForgeryToken]
    [RequirePerm("product.delete")]
    public async Task<IActionResult> DeleteProduct(int id)
    {
        var p = await _db.Products.Include(x => x.Images).Include(x => x.Specs).FirstOrDefaultAsync(x => x.Id == id);
        if (p == null) return NotFound();
        if (await _db.OrderItems.AnyAsync(x => x.ProductId == id))
        {
            TempData["Error"] = "Sản phẩm đã nằm trong đơn hàng nên không thể xóa vĩnh viễn. Hãy ẩn sản phẩm.";
            return RedirectToAction(nameof(Products));
        }
        _db.Products.Remove(p);
        await _db.SaveChangesAsync();
        await Log("Xóa sản phẩm", "Product", id.ToString(), p.Name);
        TempData["Success"] = "Đã xóa sản phẩm.";
        return RedirectToAction(nameof(Products));
    }

    [HttpGet("don-hang")]
    [RequirePerm("order.view")]
    public async Task<IActionResult> Orders(string? q, OrderStatus? status)
    {
        var query = _db.Orders.Include(o => o.Items).AsQueryable();
        if (!string.IsNullOrWhiteSpace(q))
            query = query.Where(o => o.Code.Contains(q) || o.CustomerName.Contains(q) || o.Phone.Contains(q));
        if (status.HasValue) query = query.Where(o => o.Status == status.Value);
        ViewBag.Query = q;
        ViewBag.Status = status;
        ViewBag.Statuses = Enum.GetValues<OrderStatus>();
        return View(await query.OrderByDescending(o => o.CreatedAt).Take(300).ToListAsync());
    }

    [HttpPost("don-hang/trang-thai/{id:int}")]
    [ValidateAntiForgeryToken]
    [RequirePerm("order.status")]
    public async Task<IActionResult> UpdateOrderStatus(int id, OrderStatus status)
    {
        var order = await _db.Orders.FirstOrDefaultAsync(o => o.Id == id);
        if (order == null) return NotFound();
        order.Status = status;
        if (status == OrderStatus.Confirmed && order.ConfirmedAt == null) order.ConfirmedAt = DateTime.Now;
        if (status == OrderStatus.Shipping && order.ShippedAt == null) order.ShippedAt = DateTime.Now;
        if (status == OrderStatus.Delivered && order.DeliveredAt == null) order.DeliveredAt = DateTime.Now;
        if (status == OrderStatus.Cancelled && order.CancelledAt == null) order.CancelledAt = DateTime.Now;
        _db.OrderHistories.Add(new OrderStatusHistory {
            OrderId = order.Id, Status = status, Note = "Cập nhật từ trang quản trị",
            ChangedBy = User.Identity?.Name ?? User.FindFirstValue(ClaimTypes.Email) ?? "Staff"
        });
        await _db.SaveChangesAsync();
        await Log("Đổi trạng thái đơn", "Order", id.ToString(), $"{order.Code}: {status.Label()}");
        TempData["Success"] = $"Đã cập nhật đơn {order.Code}.";
        return RedirectToAction(nameof(Orders));
    }

    [HttpPost("don-hang/xac-nhan-thanh-toan/{id:int}")]
    [ValidateAntiForgeryToken]
    [RequirePerm("payment.verify")]
    public async Task<IActionResult> VerifyPayment(int id, bool paid = true)
    {
        var order = await _db.Orders.FirstOrDefaultAsync(o => o.Id == id);
        if (order == null) return NotFound();
        order.Payment = paid ? PaymentStatus.Paid : PaymentStatus.Unpaid;
        order.PaymentNote = paid ? "Đã xác minh bởi nhân viên" : "Chưa xác minh";
        await _db.SaveChangesAsync();
        await Log(paid ? "Xác nhận thanh toán" : "Bỏ xác nhận thanh toán", "Order", id.ToString(), order.Code);
        TempData["Success"] = "Đã cập nhật thanh toán.";
        return RedirectToAction(nameof(Orders));
    }

    [HttpGet("nguoi-dung")]
    [Authorize(Roles = "Admin")]
    public async Task<IActionResult> Users(string? q)
    {
        var query = _db.Users.AsQueryable();
        if (!string.IsNullOrWhiteSpace(q))
            query = query.Where(u => u.Email.Contains(q) || u.FullName.Contains(q) || u.Phone.Contains(q));
        ViewBag.Query = q;
        return View(await query.OrderByDescending(u => u.CreatedAt).Take(300).ToListAsync());
    }

    [HttpPost("nguoi-dung/trang-thai/{id:int}")]
    [ValidateAntiForgeryToken]
    [Authorize(Roles = "Admin")]
    public async Task<IActionResult> ToggleUser(int id)
    {
        var user = await _db.Users.FindAsync(id);
        if (user == null) return NotFound();
        if (user.Id == int.Parse(User.FindFirstValue(ClaimTypes.NameIdentifier) ?? "0"))
        {
            TempData["Error"] = "Không thể tự khóa tài khoản đang đăng nhập.";
            return RedirectToAction(nameof(Users));
        }
        user.IsActive = !user.IsActive;
        await _db.SaveChangesAsync();
        await Log(user.IsActive ? "Mở khóa người dùng" : "Khóa người dùng", "User", id.ToString(), user.Email);
        TempData["Success"] = "Đã cập nhật tài khoản.";
        return RedirectToAction(nameof(Users));
    }

    [HttpPost("nguoi-dung/vai-tro/{id:int}")]
    [ValidateAntiForgeryToken]
    [Authorize(Roles = "Admin")]
    public async Task<IActionResult> UpdateRole(int id, string role)
    {
        if (!new[] { "Customer", "Staff", "Admin" }.Contains(role)) return BadRequest();
        var user = await _db.Users.FindAsync(id);
        if (user == null) return NotFound();
        if (user.Id == int.Parse(User.FindFirstValue(ClaimTypes.NameIdentifier) ?? "0"))
        {
            TempData["Error"] = "Không thể tự đổi vai trò của mình.";
            return RedirectToAction(nameof(Users));
        }
        user.Role = role;
        user.Permissions = role == "Staff" ? string.Join(",", Perm.Staff) : "";
        await _db.SaveChangesAsync();
        await Log("Đổi vai trò", "User", id.ToString(), $"{user.Email}: {role}");
        TempData["Success"] = "Đã đổi vai trò tài khoản.";
        return RedirectToAction(nameof(Users));
    }

    [HttpGet("nhat-ky")]
    [RequirePerm("log.view")]
    public async Task<IActionResult> Logs()
        => View(await _db.AuditLogs.OrderByDescending(x => x.CreatedAt).Take(250).ToListAsync());

    [HttpGet("cau-hinh")]
    [RequirePerm("settings.manage")]
    public async Task<IActionResult> Settings()
    {
        ViewBag.Bank = await _db.BankSettings.FirstOrDefaultAsync() ?? new BankSettings();
        return View(await _db.SiteSettings.FirstOrDefaultAsync() ?? new SiteSettings());
    }

    [HttpPost("cau-hinh")]
    [ValidateAntiForgeryToken]
    [RequirePerm("settings.manage")]
    public async Task<IActionResult> Settings(SiteSettings model, string bankName, string accountNumber, string accountHolder, string branch)
    {
        var site = await _db.SiteSettings.FirstOrDefaultAsync();
        if (site == null) { site = new SiteSettings(); _db.SiteSettings.Add(site); }
        site.SiteName = model.SiteName;
        site.Tagline = model.Tagline;
        site.Address = model.Address;
        site.Phone = model.Phone;
        site.Email = model.Email;
        site.OpenHours = model.OpenHours;
        site.ShippingFee = model.ShippingFee;
        site.FreeShipThreshold = model.FreeShipThreshold;
        site.UpdatedAt = DateTime.Now;
        var bank = await _db.BankSettings.FirstOrDefaultAsync();
        if (bank == null) { bank = new BankSettings(); _db.BankSettings.Add(bank); }
        bank.BankName = bankName ?? "";
        bank.AccountNumber = accountNumber ?? "";
        bank.AccountHolder = accountHolder ?? "";
        bank.Branch = branch ?? "";
        bank.UpdatedAt = DateTime.Now;
        await _db.SaveChangesAsync();
        await Log("Cập nhật cấu hình", "Settings", site.Id.ToString(), site.SiteName);
        TempData["Success"] = "Đã lưu cấu hình.";
        return RedirectToAction(nameof(Settings));
    }

    private async Task LoadProductOptions(ProductEditVM vm)
    {
        vm.Categories = await _db.Categories.Where(c => c.IsActive).OrderBy(c => c.DisplayOrder).ToListAsync();
        vm.Brands = await _db.Brands.Where(b => b.IsActive).OrderBy(b => b.Name).ToListAsync();
    }

    private static void AddImage(Product p, string? urls)
    {
        var url = (urls ?? "").Split('\n', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries)
            .Select(x => x.TrimEnd('\r')).FirstOrDefault(x => Uri.TryCreate(x, UriKind.Absolute, out var u) && (u.Scheme == "https" || u.Scheme == "http"));
        if (!string.IsNullOrWhiteSpace(url))
            p.Images.Add(new ProductImage { Url = url, IsPrimary = true, SortOrder = 0 });
    }

    private async Task Log(string action, string entity, string entityId, string details)
    {
        try { await _audit.LogAsync(User.FindFirst(System.Security.Claims.ClaimTypes.Email)?.Value ?? "system", action, entity, entityId, details); }
        catch { /* A logging failure should not undo a successful admin action. */ }
    }
}
