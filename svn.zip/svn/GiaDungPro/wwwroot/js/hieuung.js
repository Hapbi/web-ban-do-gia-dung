/* =========================================================
   HIỆU ỨNG JS — SCROLL REVEAL, TILT, RIPPLE, CURSOR, BANNER
   ========================================================= */
(function () {
    "use strict";

    // ---------- 1. THANH TIẾN TRÌNH CUỘN ----------
    var thanhTienTrinh = document.getElementById("tienTrinhCuon");
    function capNhatTienTrinh() {
        if (!thanhTienTrinh) return;
        var scrollTop = window.scrollY || document.documentElement.scrollTop;
        var chieuCao = document.documentElement.scrollHeight - window.innerHeight;
        var phanTram = chieuCao > 0 ? (scrollTop / chieuCao) * 100 : 0;
        thanhTienTrinh.style.width = phanTram + "%";
    }
    window.addEventListener("scroll", capNhatTienTrinh, { passive: true });
    capNhatTienTrinh();

    // ---------- 2. SCROLL REVEAL ----------
    var cacPhanTu = document.querySelectorAll('[data-hieuung="truot-len"]');
    if ("IntersectionObserver" in window && cacPhanTu.length) {
        var ob = new IntersectionObserver(function (entries) {
            entries.forEach(function (entry) {
                if (entry.isIntersecting) {
                    entry.target.classList.add("hien-ra");
                    ob.unobserve(entry.target);
                }
            });
        }, { threshold: 0.12, rootMargin: "0px 0px -50px 0px" });
        cacPhanTu.forEach(function (el) { ob.observe(el); });
    } else {
        cacPhanTu.forEach(function (el) { el.classList.add("hien-ra"); });
    }

    // ---------- 3. 3D TILT CHO CARD ----------
    if (window.matchMedia("(hover: hover)").matches) {
        document.querySelectorAll('[data-hieuung="the-san-pham"]').forEach(function (the) {
            the.addEventListener("mousemove", function (e) {
                var rect = the.getBoundingClientRect();
                var x = e.clientX - rect.left;
                var y = e.clientY - rect.top;
                var giuaX = rect.width / 2;
                var giuaY = rect.height / 2;
                var gocX = (y - giuaY) / giuaY * -4;
                var gocY = (x - giuaX) / giuaX * 4;
                the.style.transform = "perspective(800px) rotateX(" + gocX + "deg) rotateY(" + gocY + "deg) translateY(-6px)";
            });
            the.addEventListener("mouseleave", function () {
                the.style.transform = "";
            });
        });
    }

    // ---------- 4. RIPPLE ----------
    document.querySelectorAll("[data-nut-ripple]").forEach(function (nut) {
        nut.addEventListener("click", function (e) {
            var rect = nut.getBoundingClientRect();
            var kichThuoc = Math.max(rect.width, rect.height);
            var x = e.clientX - rect.left - kichThuoc / 2;
            var y = e.clientY - rect.top - kichThuoc / 2;
            var ripple = document.createElement("span");
            ripple.className = "ripple";
            ripple.style.width = ripple.style.height = kichThuoc + "px";
            ripple.style.left = x + "px";
            ripple.style.top = y + "px";
            nut.appendChild(ripple);
            setTimeout(function () { ripple.remove(); }, 600);
        });
    });

    // ---------- 5. ĐẾM SỐ ----------
    var dsDemSo = document.querySelectorAll("[data-dem-so]");
    if ("IntersectionObserver" in window && dsDemSo.length) {
        var obDem = new IntersectionObserver(function (entries) {
            entries.forEach(function (entry) {
                if (entry.isIntersecting) {
                    var el = entry.target;
                    var dich = parseInt(el.dataset.demSo || "0", 10);
                    var hienTai = 0;
                    var buoc = Math.max(1, Math.ceil(dich / 40));
                    var tg = 0;
                    var interval = setInterval(function () {
                        hienTai += buoc;
                        tg += 25;
                        if (hienTai >= dich || tg >= 1000) {
                            hienTai = dich;
                            clearInterval(interval);
                        }
                        el.textContent = hienTai.toLocaleString("vi-VN");
                    }, 25);
                    obDem.unobserve(el);
                }
            });
        }, { threshold: 0.5 });
        dsDemSo.forEach(function (el) { obDem.observe(el); });
    }

    // ---------- 6. NÚT LÊN ĐẦU ----------
    var nutLenDau = document.getElementById("nutLenDau");
    if (nutLenDau) {
        window.addEventListener("scroll", function () {
            if (window.scrollY > 400) nutLenDau.classList.add("hien");
            else nutLenDau.classList.remove("hien");
        }, { passive: true });
        nutLenDau.addEventListener("click", function (e) {
            e.preventDefault();
            window.scrollTo({ top: 0, behavior: "smooth" });
        });
    }

    // ---------- 7. TỰ ẨN THÔNG BÁO ----------
    setTimeout(function () {
        document.querySelectorAll(".thong-bao").forEach(function (tb) {
            tb.style.transition = "all .3s";
            tb.style.opacity = "0";
            tb.style.transform = "translateX(30px)";
            setTimeout(function () { tb.remove(); }, 300);
        });
    }, 5500);

    // ---------- 8. CURSOR GLOW (chỉ desktop) ----------
    if (window.matchMedia("(hover: hover)").matches) {
        var cursor = document.createElement("div");
        cursor.style.cssText = "position:fixed;width:20px;height:20px;border-radius:50%;background:radial-gradient(circle,rgba(255,26,64,0.4),transparent 70%);pointer-events:none;z-index:9999;transform:translate(-50%,-50%);transition:width .2s,height .2s;";
        document.body.appendChild(cursor);
        var cx = 0, cy = 0, tx = 0, ty = 0;
        document.addEventListener("mousemove", function (e) {
            tx = e.clientX;
            ty = e.clientY;
        });
        function vongLap() {
            cx += (tx - cx) * 0.15;
            cy += (ty - cy) * 0.15;
            cursor.style.left = cx + "px";
            cursor.style.top = cy + "px";
            requestAnimationFrame(vongLap);
        }
        vongLap();
        document.querySelectorAll("a, button, .the-san-pham").forEach(function (el) {
            el.addEventListener("mouseenter", function () {
                cursor.style.width = "40px";
                cursor.style.height = "40px";
            });
            el.addEventListener("mouseleave", function () {
                cursor.style.width = "20px";
                cursor.style.height = "20px";
            });
        });
    }
})();
