@echo off
setlocal
cd /d "%~dp0"
where dotnet >nul 2>nul
if errorlevel 1 (
  echo Khong tim thay .NET SDK. Hay cai .NET 8 SDK truoc.
  echo https://dotnet.microsoft.com/download/dotnet/8.0
  pause
  exit /b 1
)
echo Dang khoi tao goi NuGet...
dotnet restore
if errorlevel 1 goto error
echo Dang khoi dong Gia Dung Pro...
dotnet run
if errorlevel 1 goto error
exit /b 0
:error
echo Co loi khi khoi dong. Hay chup noi dung cua so nay de kiem tra.
pause
exit /b 1
