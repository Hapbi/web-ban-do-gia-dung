PHAN CODE THEO THANH VIEN
Đặng Công Bách – Leader: Tích hợp / cấu hình / giao diện chung

Phạm vi phụ trách:
Cấu hình project, Program.cs, csproj, layout chung, CSS/JS, README và script chạy; phụ trách tích hợp và kiểm thử.

Lưu ý:
- Đây là gói phân chia file từ project gốc, không phải 4 website độc lập.
- Giữ nguyên đường dẫn thư mục BTVH_Website/NovaShop/... khi chép/ghép code.
- Khi tích hợp, chỉ đưa các file trong gói này vào project chung; không ghi đè file của thành viên khác nếu chưa thống nhất.
- Các file dùng chung/ảnh có thể cần được thành viên phụ trách hoặc Leader cung cấp khi chạy project hoàn chỉnh.
- Leader nên nhận code qua Git branch/Pull Request, build và test sau mỗi lần merge.
