using Microsoft.AspNetCore.Identity;

namespace HomeAppliances.Web.Infrastructure;

public static class IdentityErrors
{
    /// <summary>Vietnamese text for the Identity error codes we can hit.</summary>
    public static string Translate(IdentityError e) => e.Code switch
    {
        "DuplicateUserName" or "DuplicateEmail" => "Email này đã được đăng ký.",
        "InvalidEmail" or "InvalidUserName" => "Email không hợp lệ.",
        "PasswordTooShort" => "Mật khẩu phải có ít nhất 8 ký tự.",
        "PasswordRequiresDigit" => "Mật khẩu phải có ít nhất một chữ số.",
        "PasswordRequiresLower" => "Mật khẩu phải có ít nhất một chữ thường.",
        "PasswordRequiresUpper" => "Mật khẩu phải có ít nhất một chữ hoa.",
        "PasswordRequiresNonAlphanumeric" => "Mật khẩu phải có ít nhất một ký tự đặc biệt.",
        "PasswordMismatch" => "Mật khẩu hiện tại không đúng.",
        "InvalidToken" => "Liên kết đã hết hạn hoặc không hợp lệ. Vui lòng yêu cầu lại.",
        _ => "Không thể thực hiện thao tác. Vui lòng kiểm tra lại thông tin."
    };
}
