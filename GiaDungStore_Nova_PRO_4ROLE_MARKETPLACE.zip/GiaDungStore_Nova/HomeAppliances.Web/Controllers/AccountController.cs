using System.Net;
using System.Text;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.RateLimiting;
using Microsoft.AspNetCore.WebUtilities;
using HomeAppliances.Web.Infrastructure;
using HomeAppliances.Web.Models.Entities;
using HomeAppliances.Web.Models.ViewModels;
using HomeAppliances.Web.Services;

namespace HomeAppliances.Web.Controllers;

/// <summary>Registration, login/logout, e-mail confirmation and password recovery (ASP.NET Core Identity).</summary>
public class AccountController : Controller
{
    private readonly UserManager<ApplicationUser> _users;
    private readonly SignInManager<ApplicationUser> _signIn;
    private readonly IEmailService _email;
    private readonly ICartService _cart;
    private readonly IConfiguration _cfg;
    private readonly ILogger<AccountController> _log;

    public AccountController(UserManager<ApplicationUser> users, SignInManager<ApplicationUser> signIn, IEmailService email, ICartService cart, IConfiguration cfg, ILogger<AccountController> log)
    { _users = users; _signIn = signIn; _email = email; _cart = cart; _cfg = cfg; _log = log; }

    // ---- register -----------------------------------------------------------

    [HttpGet("dang-ky")]
    public IActionResult Register() => User.Identity?.IsAuthenticated == true ? RedirectToAction("Index", "Home") : View(new RegisterViewModel());

    [HttpPost("dang-ky"), EnableRateLimiting("auth")]
    public async Task<IActionResult> Register(RegisterViewModel vm)
    {
        if (!ModelState.IsValid) return View(vm);

        var email = vm.Email.Trim();
        var user = new ApplicationUser { UserName = email, Email = email, FullName = vm.FullName.Trim(), PhoneNumber = vm.PhoneNumber.Trim() };
        var result = await _users.CreateAsync(user, vm.Password);   // password is hashed by Identity
        if (!result.Succeeded)
        {
            foreach (var e in result.Errors)
                ModelState.AddModelError(e.Code.Contains("Email") || e.Code.Contains("UserName") ? nameof(vm.Email) : nameof(vm.Password), IdentityErrors.Translate(e));
            return View(vm);
        }
        await _users.AddToRoleAsync(user, AppRoles.Customer);

        if (_email.IsEnabled)
        {
            await SendConfirmationAsync(user);
            return RedirectToAction(nameof(RegisterConfirmation), new { email });
        }

        // No e-mail delivery configured: accounts are usable immediately.
        await _signIn.SignInAsync(user, isPersistent: false);
        await _cart.MergeGuestCartAsync(user.Id);
        TempData["Success"] = "Đăng ký thành công. Chào mừng bạn!";
        return RedirectToAction("Index", "Home");
    }

    [HttpGet("dang-ky/xac-nhan")]
    public IActionResult RegisterConfirmation(string? email) { ViewData["Email"] = email; return View(); }

    [HttpGet("xac-nhan-email")]
    public async Task<IActionResult> ConfirmEmail(string? userId, string? code)
    {
        if (userId == null || code == null) return RedirectToAction("Index", "Home");
        var user = await _users.FindByIdAsync(userId);
        var ok = false;
        if (user != null)
        {
            try { ok = (await _users.ConfirmEmailAsync(user, Encoding.UTF8.GetString(WebEncoders.Base64UrlDecode(code)))).Succeeded; }
            catch (FormatException) { }
        }
        ViewData["Success"] = ok;
        return View();
    }

    [HttpPost("gui-lai-xac-nhan"), EnableRateLimiting("auth")]
    public async Task<IActionResult> ResendConfirmation(string? email)
    {
        var user = string.IsNullOrWhiteSpace(email) ? null : await _users.FindByEmailAsync(email.Trim());
        if (user != null && !await _users.IsEmailConfirmedAsync(user)) await SendConfirmationAsync(user);
        TempData["Success"] = "Nếu email tồn tại và chưa xác nhận, chúng tôi đã gửi lại liên kết xác nhận.";
        return RedirectToAction(nameof(Login));
    }

    // ---- login / logout -----------------------------------------------------

    [HttpGet("dang-nhap")]
    public IActionResult Login(string? returnUrl = null) =>
        User.Identity?.IsAuthenticated == true ? RedirectToAction("Index", "Home") : View(new LoginViewModel { ReturnUrl = returnUrl });

    [HttpPost("dang-nhap"), EnableRateLimiting("auth")]
    public async Task<IActionResult> Login(LoginViewModel vm)
    {
        if (!ModelState.IsValid) return View(vm);

        var loginId = vm.Email.Trim();
        var user = await _users.FindByNameAsync(loginId) ?? await _users.FindByEmailAsync(loginId);
        if (user != null && !user.IsActive && await _users.CheckPasswordAsync(user, vm.Password))
        {
            ModelState.AddModelError("", "Tài khoản của bạn đã bị vô hiệu hóa. Vui lòng liên hệ cửa hàng.");
            return View(vm);
        }
        if (user == null || !user.IsActive)
        {
            ModelState.AddModelError("", "Email hoặc mật khẩu không đúng.");
            return View(vm);
        }

        var result = await _signIn.PasswordSignInAsync(user, vm.Password, vm.RememberMe, lockoutOnFailure: true);
        if (result.Succeeded)
        {
            await _cart.MergeGuestCartAsync(user.Id);
            if (Url.IsLocalUrl(vm.ReturnUrl)) return LocalRedirect(vm.ReturnUrl!);
            var roles = await _users.GetRolesAsync(user);
            if (roles.Contains(AppRoles.Admin)) return Redirect("/Admin");
            if (roles.Contains(AppRoles.Employee)) return Redirect("/Employee");
            return RedirectToAction("Index", "Home");
        }
        if (result.IsLockedOut) ModelState.AddModelError("", "Tài khoản tạm thời bị khóa do nhập sai nhiều lần. Vui lòng thử lại sau 15 phút.");
        else if (result.IsNotAllowed)
        {
            ModelState.AddModelError("", "Bạn cần xác nhận email trước khi đăng nhập.");
            ViewData["ShowResend"] = true;
        }
        else ModelState.AddModelError("", "Email hoặc mật khẩu không đúng.");
        return View(vm);
    }

    [HttpPost("dang-xuat")]
    public async Task<IActionResult> Logout()
    {
        await _signIn.SignOutAsync();
        return RedirectToAction("Index", "Home");
    }

    [HttpGet("khong-co-quyen")]
    public IActionResult AccessDenied() { Response.StatusCode = 403; return View(); }

    // ---- forgot / reset password -------------------------------------------

    [HttpGet("quen-mat-khau")]
    public IActionResult ForgotPassword() => View(new ForgotPasswordViewModel());

    [HttpPost("quen-mat-khau"), EnableRateLimiting("auth")]
    public async Task<IActionResult> ForgotPassword(ForgotPasswordViewModel vm)
    {
        if (!ModelState.IsValid) return View(vm);

        var loginId = vm.Email.Trim();
        var user = await _users.FindByNameAsync(loginId) ?? await _users.FindByEmailAsync(loginId);
        if (user != null && user.IsActive && (!_users.Options.SignIn.RequireConfirmedEmail || await _users.IsEmailConfirmedAsync(user)))
        {
            var token = await _users.GeneratePasswordResetTokenAsync(user);    // single-use, expires after 2 hours
            var code = WebEncoders.Base64UrlEncode(Encoding.UTF8.GetBytes(token));
            var link = BuildLink(Url.Action(nameof(ResetPassword), "Account", new { email = user.Email, code })!);
            try
            {
                await _email.SendAsync(user.Email!, "Đặt lại mật khẩu",
                    $"<p>Bạn (hoặc ai đó) đã yêu cầu đặt lại mật khẩu.</p><p><a href=\"{WebUtility.HtmlEncode(link)}\">Bấm vào đây để đặt mật khẩu mới</a>. Liên kết có hiệu lực trong 2 giờ.</p><p>Nếu không phải bạn, hãy bỏ qua email này.</p>");
            }
            catch (Exception ex) { _log.LogError(ex, "Could not send password reset email"); }
        }
        // Same answer whether or not the address exists: never reveal which emails are registered.
        return RedirectToAction(nameof(ForgotPasswordConfirmation));
    }

    [HttpGet("quen-mat-khau/da-gui")]
    public IActionResult ForgotPasswordConfirmation() => View();

    [HttpGet("dat-lai-mat-khau")]
    public IActionResult ResetPassword(string? email, string? code) =>
        email == null || code == null ? RedirectToAction(nameof(ForgotPassword)) : View(new ResetPasswordViewModel { Email = email, Code = code });

    [HttpPost("dat-lai-mat-khau"), EnableRateLimiting("auth")]
    public async Task<IActionResult> ResetPassword(ResetPasswordViewModel vm)
    {
        if (!ModelState.IsValid) return View(vm);
        var user = await _users.FindByEmailAsync(vm.Email);
        if (user == null) return RedirectToAction(nameof(ResetPasswordConfirmation));   // do not reveal unknown emails

        IdentityResult result;
        try { result = await _users.ResetPasswordAsync(user, Encoding.UTF8.GetString(WebEncoders.Base64UrlDecode(vm.Code)), vm.Password); }
        catch (FormatException) { result = IdentityResult.Failed(new IdentityError { Code = "InvalidToken" }); }

        if (result.Succeeded) return RedirectToAction(nameof(ResetPasswordConfirmation));
        foreach (var e in result.Errors) ModelState.AddModelError("", IdentityErrors.Translate(e));
        return View(vm);
    }

    [HttpGet("dat-lai-mat-khau/thanh-cong")]
    public IActionResult ResetPasswordConfirmation() => View();

    // ---- helpers ------------------------------------------------------------

    private async Task SendConfirmationAsync(ApplicationUser user)
    {
        var code = WebEncoders.Base64UrlEncode(Encoding.UTF8.GetBytes(await _users.GenerateEmailConfirmationTokenAsync(user)));
        var link = BuildLink(Url.Action(nameof(ConfirmEmail), "Account", new { userId = user.Id, code })!);
        try { await _email.SendAsync(user.Email!, "Xác nhận email", $"<p>Cảm ơn bạn đã đăng ký.</p><p><a href=\"{WebUtility.HtmlEncode(link)}\">Bấm vào đây để xác nhận email</a>.</p>"); }
        catch (Exception ex) { _log.LogError(ex, "Could not send confirmation email"); }
    }

    /// <summary>Absolute link. Uses App:PublicBaseUrl when set so links never depend on the (spoofable) Host header.</summary>
    private string BuildLink(string relative)
    {
        var baseUrl = _cfg["App:PublicBaseUrl"];
        return string.IsNullOrWhiteSpace(baseUrl) ? $"{Request.Scheme}://{Request.Host}{relative}" : baseUrl.TrimEnd('/') + relative;
    }
}
