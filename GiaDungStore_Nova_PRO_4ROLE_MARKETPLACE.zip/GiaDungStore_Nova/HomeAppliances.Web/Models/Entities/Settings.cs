using System.ComponentModel.DataAnnotations;
using Microsoft.EntityFrameworkCore;

namespace HomeAppliances.Web.Models.Entities;

/// <summary>Single-row table (Id = 1) editable by the administrator.</summary>
public class BankTransferSettings
{
    public int Id { get; set; }
    [MaxLength(100)] public string BankName { get; set; } = "";
    [MaxLength(150)] public string AccountHolder { get; set; } = "";
    [MaxLength(50)] public string AccountNumber { get; set; } = "";
    [MaxLength(150)] public string? Branch { get; set; }
    [MaxLength(1000)] public string Instructions { get; set; } = "";
    /// <summary>Web path of the QR image uploaded by the administrator.</summary>
    [MaxLength(300)] public string? QrImagePath { get; set; }
    /// <summary>Transfer note template; {OrderNumber} is replaced, e.g. "DH {OrderNumber}".</summary>
    [MaxLength(100)] public string ReferenceFormat { get; set; } = "{OrderNumber}";
    public DateTime UpdatedUtc { get; set; } = DateTime.UtcNow;
}

/// <summary>Single-row table (Id = 1): company details shown in header/footer plus shop rules.</summary>
public class WebsiteSettings
{
    public int Id { get; set; }
    [MaxLength(150)] public string SiteName { get; set; } = "";
    [MaxLength(200)] public string Tagline { get; set; } = "";
    [MaxLength(1000)] public string Introduction { get; set; } = "";
    [MaxLength(300)] public string Address { get; set; } = "";
    [MaxLength(50)] public string Phone { get; set; } = "";
    [MaxLength(200)] public string Email { get; set; } = "";
    [MaxLength(200)] public string OpeningHours { get; set; } = "";
    [MaxLength(300)] public string? FacebookUrl { get; set; }
    [MaxLength(300)] public string? YoutubeUrl { get; set; }
    [MaxLength(300)] public string? ZaloUrl { get; set; }
    [MaxLength(300)] public string? TiktokUrl { get; set; }
    [Precision(18, 0)] public decimal ShippingFee { get; set; } = 30000;
    /// <summary>Orders at or above this merchandise total ship free. 0 disables free shipping.</summary>
    [Precision(18, 0)] public decimal FreeShippingThreshold { get; set; } = 5000000;
    /// <summary>Unpaid orders older than this are cancelled automatically (stock released). 0 disables.</summary>
    public int UnpaidOrderExpiryHours { get; set; } = 48;
    public DateTime UpdatedUtc { get; set; } = DateTime.UtcNow;
}

public class Banner
{
    public int Id { get; set; }
    [MaxLength(150)] public string Title { get; set; } = "";
    [MaxLength(300)] public string? Subtitle { get; set; }
    [MaxLength(300)] public string ImagePath { get; set; } = "";
    [MaxLength(300)] public string? LinkUrl { get; set; }
    public bool IsActive { get; set; } = true;
    public int SortOrder { get; set; }
}

public class ShippingAddress
{
    public int Id { get; set; }
    public string UserId { get; set; } = "";
    public ApplicationUser? User { get; set; }
    [MaxLength(100)] public string ReceiverName { get; set; } = "";
    [MaxLength(20)] public string Phone { get; set; } = "";
    [MaxLength(300)] public string Address { get; set; } = "";
    public bool IsDefault { get; set; }
}

[Index(nameof(CreatedUtc))]
public class AuditLog
{
    public long Id { get; set; }
    [MaxLength(450)] public string? UserId { get; set; }
    [MaxLength(256)] public string? UserEmail { get; set; }
    [MaxLength(100)] public string Action { get; set; } = "";
    [MaxLength(100)] public string EntityType { get; set; } = "";
    [MaxLength(100)] public string? EntityId { get; set; }
    [MaxLength(2000)] public string? Details { get; set; }
    [MaxLength(64)] public string? IpAddress { get; set; }
    public DateTime CreatedUtc { get; set; } = DateTime.UtcNow;
}

public class ContactMessage
{
    public int Id { get; set; }
    [MaxLength(100)] public string FullName { get; set; } = "";
    [MaxLength(200)] public string Email { get; set; } = "";
    [MaxLength(20)] public string? Phone { get; set; }
    [MaxLength(2000)] public string Message { get; set; } = "";
    public DateTime CreatedUtc { get; set; } = DateTime.UtcNow;
    public bool IsRead { get; set; }
}
