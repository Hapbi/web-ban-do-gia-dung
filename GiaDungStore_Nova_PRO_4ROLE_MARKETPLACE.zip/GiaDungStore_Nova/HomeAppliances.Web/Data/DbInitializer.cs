using System.Security.Claims;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using HomeAppliances.Web.Domain;
using HomeAppliances.Web.Infrastructure;
using HomeAppliances.Web.Models.Entities;
using HomeAppliances.Web.Services;

namespace HomeAppliances.Web.Data;

/// <summary>
/// Creates/updates the schema and seeds required data. Accounts are created only when
/// Seed:Enabled is true AND a password is supplied through configuration (user secrets or
/// environment variables). No password is ever stored in source code.
/// </summary>
public static class DbInitializer
{
    public static async Task InitializeAsync(IServiceProvider services)
    {
        using var scope = services.CreateScope();
        var sp = scope.ServiceProvider;
        var db = sp.GetRequiredService<ApplicationDbContext>();
        var cfg = sp.GetRequiredService<IConfiguration>();
        var log = sp.GetRequiredService<ILoggerFactory>().CreateLogger("DbInitializer");

        // With EF migrations present, apply them. Otherwise create the schema from the model.
        if (db.Database.GetMigrations().Any()) await db.Database.MigrateAsync();
        else await db.Database.EnsureCreatedAsync();

        var roles = sp.GetRequiredService<RoleManager<IdentityRole>>();
        foreach (var r in AppRoles.All)
            if (!await roles.RoleExistsAsync(r)) await roles.CreateAsync(new IdentityRole(r));

        if (!await db.WebsiteSettings.AnyAsync()) db.WebsiteSettings.Add(SettingsService.DefaultWebsite());
        if (!await db.BankTransferSettings.AnyAsync())
            db.BankTransferSettings.Add(new BankTransferSettings
            {
                BankName = "[Tên ngân hàng]", AccountHolder = "[Chủ tài khoản]", AccountNumber = "[Số tài khoản]",
                Instructions = "Mở ứng dụng ngân hàng, quét mã QR và chuyển đúng số tiền. Ghi đúng nội dung chuyển khoản bên dưới để chúng tôi đối soát nhanh.",
                ReferenceFormat = "{OrderNumber}"
            });
        await db.SaveChangesAsync();

        if (cfg.GetValue<bool>("Seed:SampleData") && !await db.Categories.AnyAsync()) await SeedSampleCatalogAsync(db);

        if (cfg.GetValue<bool>("Seed:Enabled"))
        {
            var users = sp.GetRequiredService<UserManager<ApplicationUser>>();
            await EnsureUserAsync(users, log, cfg["Seed:AdminEmail"], cfg["Seed:AdminPassword"], "Quản trị viên", AppRoles.Admin, false, "admin");
            await EnsureUserAsync(users, log, cfg["Seed:EmployeeEmail"], cfg["Seed:EmployeePassword"], "Nhân viên mẫu", AppRoles.Employee, true);
            await EnsureUserAsync(users, log, cfg["Seed:CustomerEmail"], cfg["Seed:CustomerPassword"], "Khách hàng mẫu", AppRoles.Customer, false);
        }
    }

    private static async Task EnsureUserAsync(UserManager<ApplicationUser> users, ILogger log, string? email, string? password, string fullName, string role, bool canVerifyPayments, string? username = null)
    {
        if (string.IsNullOrWhiteSpace(email)) return;
        if (string.IsNullOrWhiteSpace(password))
        {
            log.LogWarning("Seed account {Email} skipped: no password configured. Set it with: dotnet user-secrets set \"Seed:{Role}Password\" \"<password>\" --project HomeAppliances.Web", email, role);
            return;
        }
        if (await users.FindByEmailAsync(email) != null) return;

        var user = new ApplicationUser { UserName = username ?? email, Email = email, EmailConfirmed = true, FullName = fullName, PhoneNumber = "0900000000", PhoneNumberConfirmed = true };
        var result = await users.CreateAsync(user, password);
        if (!result.Succeeded)
        {
            log.LogError("Could not create seed account {Email}: {Errors}", email, string.Join("; ", result.Errors.Select(e => e.Description)));
            return;
        }
        await users.AddToRoleAsync(user, role);
        if (canVerifyPayments) await users.AddClaimAsync(user, new Claim(AppClaims.PermissionType, AppClaims.VerifyPayments));
        log.LogInformation("Seeded {Role} account {Email}", role, email);
    }

    private static async Task SeedSampleCatalogAsync(ApplicationDbContext db)
    {
        var cats = new (string Slug, string Name)[]
        {
            ("tu-lanh", "Tủ lạnh"), ("may-giat", "Máy giặt"), ("dieu-hoa", "Điều hòa"), ("noi-com-dien", "Nồi cơm điện"),
            ("lo-vi-song", "Lò vi sóng"), ("may-hut-bui", "Máy hút bụi"), ("quat", "Quạt"), ("loc-khong-khi", "Máy lọc không khí")
        };
        var order = 0;
        foreach (var c in cats) db.Categories.Add(new Category { Slug = c.Slug, Name = c.Name, DisplayOrder = order++ });
        await db.SaveChangesAsync();
        var catIds = await db.Categories.ToDictionaryAsync(c => c.Slug, c => c.Id);

        // category, name, brand (fictional), original, sale (0 = none), stock, sold, age in days, featured
        var rows = new (string Cat, string Name, string Brand, decimal Price, decimal Sale, int Stock, int Sold, int Age, bool Feat)[]
        {
            ("tu-lanh","Tủ lạnh Inverter 2 cánh 450 lít","Aurel",14990000,12490000,14,320,40,true),
            ("tu-lanh","Tủ lạnh mini 90 lít","Tano",3290000,0,30,540,200,false),
            ("tu-lanh","Tủ lạnh side-by-side 600 lít","Mizuka",24900000,21900000,4,95,12,true),
            ("tu-lanh","Tủ lạnh ngăn đá dưới 300 lít","Aurel",9490000,0,0,210,90,false),
            ("may-giat","Máy giặt cửa trước 9 kg Inverter","Mizuka",8990000,7490000,22,410,25,true),
            ("may-giat","Máy giặt cửa trên 10 kg","Tano",5290000,0,18,380,150,false),
            ("may-giat","Máy giặt sấy 10/6 kg","Aurel",16990000,14990000,6,120,8,false),
            ("dieu-hoa","Điều hòa 1 chiều 9.000 BTU","Kitora",6490000,5690000,40,600,60,true),
            ("dieu-hoa","Điều hòa 2 chiều Inverter 12.000 BTU","Kitora",10990000,9990000,25,290,18,false),
            ("dieu-hoa","Điều hòa tủ đứng 24.000 BTU","Mizuka",22900000,0,3,40,300,false),
            ("noi-com-dien","Nồi cơm điện tử 1,8 lít","Tano",1890000,1490000,60,900,120,false),
            ("noi-com-dien","Nồi cơm cao tần 1 lít","Viva",3990000,0,15,260,35,false),
            ("noi-com-dien","Nồi cơm nắp gài 1,2 lít","Viva",790000,650000,80,1200,400,false),
            ("lo-vi-song","Lò vi sóng 23 lít có nướng","Viva",2190000,1790000,28,330,70,false),
            ("lo-vi-song","Lò nướng điện 32 lít","Kitora",2790000,0,12,180,10,false),
            ("lo-vi-song","Lò vi sóng cơ 20 lít","Tano",1290000,0,35,450,260,false),
            ("may-hut-bui","Máy hút bụi cầm tay không dây","Kitora",3490000,2890000,20,280,15,false),
            ("may-hut-bui","Robot hút bụi lau nhà","Aurel",7990000,6490000,9,150,5,false),
            ("may-hut-bui","Máy hút bụi dạng hộp 1.600 W","Tano",1590000,0,0,220,180,false),
            ("quat","Quạt đứng điều khiển từ xa","Viva",890000,750000,70,800,90,false),
            ("quat","Quạt điều hòa hơi nước 40 lít","Kitora",3290000,0,16,140,45,false),
            ("quat","Quạt hộp để bàn 3 tốc độ","Tano",390000,0,120,1500,365,false),
            ("loc-khong-khi","Máy lọc không khí phòng 40 m²","Aurel",4590000,3990000,11,175,22,false),
            ("loc-khong-khi","Máy lọc không khí phòng ngủ 20 m²","Mizuka",2490000,0,5,90,3,false),
        };
        var now = DateTime.UtcNow;
        foreach (var r in rows)
        {
            var p = new Product
            {
                Name = r.Name, Slug = SlugHelper.Slugify(r.Name), Brand = r.Brand, CategoryId = catIds[r.Cat],
                OriginalPrice = r.Price, DiscountPrice = r.Sale > 0 ? r.Sale : null, StockQuantity = r.Stock, SoldCount = r.Sold,
                IsFeatured = r.Feat, CreatedUtc = now.AddDays(-r.Age), UpdatedUtc = now,
                Description = "Sản phẩm mẫu dùng để thử nghiệm. Quản trị viên có thể thay bằng mô tả thật trong trang quản lý sản phẩm."
            };
            // Ảnh minh họa từ Unsplash, mỗi sản phẩm có ảnh để catalog không bị trống.
            var imageId = r.Cat switch
            {
                "tu-lanh" => "1571175443880-49e1d25b2bc5",
                "may-giat" => "1626806787461-102c1bfaaea1",
                "dieu-hoa" => "1631545806609-8d3c9c8c8c7a",
                "noi-com-dien" => "1585515320310-259814833e62",
                "lo-vi-song" => "1585659722983-3a675dabf23d",
                "may-hut-bui" => "1558317374-067fb5f30001",
                "quat" => "1618941716939-553df3c6c278",
                _ => "1519638831568-d9897f54ed69"
            };
            p.Images.Add(new ProductImage
            {
                Path = $"https://images.unsplash.com/photo-{imageId}?auto=format&fit=crop&w=900&q=85",
                IsPrimary = true,
                SortOrder = 0
            });
            p.Specifications.Add(new ProductSpecification { Name = "Thương hiệu", Value = r.Brand, SortOrder = 0 });
            p.Specifications.Add(new ProductSpecification { Name = "Bảo hành", Value = "12 tháng (mẫu)", SortOrder = 1 });
            p.Specifications.Add(new ProductSpecification { Name = "Điện áp", Value = "220 V / 50 Hz", SortOrder = 2 });
            db.Products.Add(p);
        }
        await db.SaveChangesAsync();
    }
}
