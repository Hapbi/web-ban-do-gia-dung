using Microsoft.EntityFrameworkCore;
using HomeAppliances.Web.Domain;
using HomeAppliances.Web.Models.Entities;
using Xunit;

namespace HomeAppliances.Tests.Integration;

public class OrderServiceTests : IDisposable
{
    private readonly TestDb _t = new();
    public void Dispose() => _t.Dispose();

    private async Task<int> StockAsync(int productId) => (await _t.Fresh().Products.AsNoTracking().FirstAsync(p => p.Id == productId)).StockQuantity;

    // ---- checkout + inventory ----------------------------------------------

    [Fact]
    public async Task Checkout_reserves_stock_empties_the_cart_and_creates_a_pending_payment_order()
    {
        var user = _t.AddUser("alice"); var p = _t.AddProduct("Tủ lạnh A", 1_000_000m, 10);
        var order = await _t.PlaceOrderAsync(user, p, 3);

        Assert.Equal(OrderStatus.PendingPayment, order.Status);
        Assert.StartsWith("DH", order.OrderNumber);
        Assert.Equal(3_000_000m + 30_000m, order.Total);          // default flat shipping applies below the free-shipping threshold
        Assert.Equal(7, await StockAsync(p.Id));
        Assert.Equal(0, await _t.Fresh().CartItems.CountAsync());
        Assert.Equal(1, await _t.Fresh().OrderStatusHistory.CountAsync(h => h.OrderId == order.Id));
    }

    [Fact]
    public async Task Checkout_is_refused_and_stock_untouched_when_quantity_exceeds_stock()
    {
        var user = _t.AddUser("alice"); var p = _t.AddProduct("Tủ lạnh A", 1_000_000m, 2);
        _t.PutInCart(user, p, 3);

        var r = await _t.Orders().PlaceOrderAsync(user.Id, user.Email!, new Web.Services.CheckoutInput("Alice", "0912345678", "12 Phố Test, Quận 1", null));

        Assert.False(r.Succeeded);
        Assert.Equal(2, await StockAsync(p.Id));
        Assert.Equal(0, await _t.Fresh().Orders.CountAsync());
    }

    [Fact]
    public async Task The_last_unit_can_only_be_bought_once()
    {
        var a = _t.AddUser("alice"); var b = _t.AddUser("bob"); var p = _t.AddProduct("Hàng cuối", 500_000m, 1);
        _t.PutInCart(a, p, 1); _t.PutInCart(b, p, 1);
        var input = new Web.Services.CheckoutInput("X", "0912345678", "12 Phố Test, Quận 1", null);

        var first = await _t.Orders().PlaceOrderAsync(a.Id, a.Email!, input);
        var second = await _t.Orders().PlaceOrderAsync(b.Id, b.Email!, input);

        Assert.True(first.Succeeded);
        Assert.False(second.Succeeded);
        Assert.Equal(0, await StockAsync(p.Id));   // never negative
    }

    [Fact]
    public async Task Order_lines_keep_the_price_paid_even_if_the_product_price_changes_later()
    {
        var user = _t.AddUser("alice"); var p = _t.AddProduct("Máy giặt", 2_000_000m, 5, sale: 1_800_000m);
        var order = await _t.PlaceOrderAsync(user, p, 1);

        var db = _t.Fresh();
        var product = await db.Products.FirstAsync(x => x.Id == p.Id);
        product.OriginalPrice = 9_000_000m; product.DiscountPrice = null;
        await db.SaveChangesAsync();

        var saved = await _t.Fresh().Orders.AsNoTracking().Include(o => o.Items).FirstAsync(o => o.Id == order.Id);
        Assert.Equal(1_800_000m, saved.Items[0].UnitPrice);
        Assert.Equal(200_000m, saved.DiscountTotal);
    }

    // ---- cancellation + stock release --------------------------------------

    [Fact]
    public async Task Cancelling_releases_stock_exactly_once()
    {
        var user = _t.AddUser("alice"); var p = _t.AddProduct("Tủ lạnh A", 1_000_000m, 10);
        var order = await _t.PlaceOrderAsync(user, p, 3);
        Assert.Equal(7, await StockAsync(p.Id));

        var first = await _t.Orders().CancelAsync(order.Id, ActorRole.Customer, user.Id, "alice", "Đổi ý", user.Id);
        var second = await _t.Orders().CancelAsync(order.Id, ActorRole.Customer, user.Id, "alice", "Đổi ý", user.Id);

        Assert.True(first.Succeeded);
        Assert.False(second.Succeeded);
        Assert.Equal(10, await StockAsync(p.Id));
        Assert.Equal(OrderStatus.Cancelled, (await _t.Fresh().Orders.AsNoTracking().FirstAsync(o => o.Id == order.Id)).Status);
    }

    [Fact]
    public async Task A_customer_cannot_cancel_someone_elses_order()
    {
        var a = _t.AddUser("alice"); var b = _t.AddUser("bob"); var p = _t.AddProduct("Tủ lạnh A", 1_000_000m, 10);
        var order = await _t.PlaceOrderAsync(a, p, 1);

        var r = await _t.Orders().CancelAsync(order.Id, ActorRole.Customer, b.Id, "bob", "x", mustOwnUserId: b.Id);

        Assert.False(r.Succeeded);
        Assert.Equal(OrderStatus.PendingPayment, (await _t.Fresh().Orders.AsNoTracking().FirstAsync(o => o.Id == order.Id)).Status);
    }

    [Fact]
    public async Task Cancelling_requires_a_reason_from_people()
    {
        var user = _t.AddUser("alice"); var p = _t.AddProduct("A", 1_000_000m, 10);
        var order = await _t.PlaceOrderAsync(user, p, 1);
        Assert.False((await _t.Orders().CancelAsync(order.Id, ActorRole.Customer, user.Id, "alice", "  ", user.Id)).Succeeded);
    }

    [Fact]
    public async Task Unpaid_orders_past_the_deadline_are_cancelled_and_their_stock_returned()
    {
        var user = _t.AddUser("alice"); var p = _t.AddProduct("A", 1_000_000m, 10);
        var old = await _t.PlaceOrderAsync(user, p, 2);
        var fresh = await _t.PlaceOrderAsync(user, p, 1);
        var db = _t.Fresh();
        (await db.Orders.FirstAsync(o => o.Id == old.Id)).CreatedUtc = DateTime.UtcNow.AddHours(-72);
        await db.SaveChangesAsync();

        var n = await _t.Orders().CancelExpiredUnpaidAsync(DateTime.UtcNow.AddHours(-48));

        Assert.Equal(1, n);
        Assert.Equal(9, await StockAsync(p.Id));   // 10 - 2 - 1 + 2
        Assert.Equal(OrderStatus.PendingPayment, (await _t.Fresh().Orders.AsNoTracking().FirstAsync(o => o.Id == fresh.Id)).Status);
    }

    // ---- payment proof + verification --------------------------------------

    [Fact]
    public async Task Uploading_a_proof_requests_verification_but_never_marks_the_order_paid()
    {
        var user = _t.AddUser("alice"); var p = _t.AddProduct("A", 1_000_000m, 10);
        var order = await _t.PlaceOrderAsync(user, p, 1);

        var r = await _t.Orders().UploadProofAsync(user.Id, order.OrderNumber, TestDb.Png());

        Assert.True(r.Succeeded);
        var saved = await _t.Fresh().Orders.AsNoTracking().Include(o => o.Proofs).FirstAsync(o => o.Id == order.Id);
        Assert.Equal(OrderStatus.PendingVerification, saved.Status);
        Assert.Null(saved.PaidUtc);
        Assert.Equal(PaymentProofStatus.Pending, saved.Proofs[0].Status);
    }

    [Fact]
    public async Task A_customer_cannot_upload_a_proof_to_someone_elses_order()
    {
        var a = _t.AddUser("alice"); var b = _t.AddUser("bob"); var p = _t.AddProduct("A", 1_000_000m, 10);
        var order = await _t.PlaceOrderAsync(a, p, 1);
        Assert.False((await _t.Orders().UploadProofAsync(b.Id, order.OrderNumber, TestDb.Png())).Succeeded);
    }

    [Fact]
    public async Task Approval_marks_paid_and_a_second_approval_is_refused()
    {
        var user = _t.AddUser("alice"); var staff = _t.AddUser("staff"); var p = _t.AddProduct("A", 1_000_000m, 10);
        var order = await _t.PlaceOrderAsync(user, p, 2);
        await _t.Orders().UploadProofAsync(user.Id, order.OrderNumber, TestDb.Png());

        var first = await _t.Orders().ApproveAsync(order.Id, staff.Id, "staff", ActorRole.Employee);
        var second = await _t.Orders().ApproveAsync(order.Id, staff.Id, "staff", ActorRole.Admin);

        Assert.True(first.Succeeded);
        Assert.False(second.Succeeded);
        var db = _t.Fresh();
        var saved = await db.Orders.AsNoTracking().FirstAsync(o => o.Id == order.Id);
        Assert.Equal(OrderStatus.Paid, saved.Status);
        Assert.NotNull(saved.PaidUtc);
        Assert.Equal(2, (await db.Products.AsNoTracking().FirstAsync(x => x.Id == p.Id)).SoldCount);   // counted once, not twice
        Assert.Equal(1, await db.PaymentProofs.CountAsync(x => x.Status == PaymentProofStatus.Approved));
    }

    [Fact]
    public async Task An_order_without_a_proof_cannot_be_approved()
    {
        var user = _t.AddUser("alice"); var p = _t.AddProduct("A", 1_000_000m, 10);
        var order = await _t.PlaceOrderAsync(user, p, 1);
        Assert.False((await _t.Orders().ApproveAsync(order.Id, "s", "staff", ActorRole.Admin)).Succeeded);
    }

    [Fact]
    public async Task A_customer_actor_can_never_approve()
    {
        var user = _t.AddUser("alice"); var p = _t.AddProduct("A", 1_000_000m, 10);
        var order = await _t.PlaceOrderAsync(user, p, 1);
        await _t.Orders().UploadProofAsync(user.Id, order.OrderNumber, TestDb.Png());
        Assert.False((await _t.Orders().ApproveAsync(order.Id, user.Id, "alice", ActorRole.Customer)).Succeeded);
    }

    [Fact]
    public async Task Rejection_needs_a_reason_shows_it_and_lets_the_customer_resubmit()
    {
        var user = _t.AddUser("alice"); var p = _t.AddProduct("A", 1_000_000m, 10);
        var order = await _t.PlaceOrderAsync(user, p, 1);
        await _t.Orders().UploadProofAsync(user.Id, order.OrderNumber, TestDb.Png());

        Assert.False((await _t.Orders().RejectAsync(order.Id, "s", "staff", ActorRole.Employee, "")).Succeeded);
        Assert.True((await _t.Orders().RejectAsync(order.Id, "s", "staff", ActorRole.Employee, "Sai số tiền")).Succeeded);

        var rejected = await _t.Fresh().Orders.AsNoTracking().Include(o => o.Proofs).FirstAsync(o => o.Id == order.Id);
        Assert.Equal(OrderStatus.PaymentRejected, rejected.Status);
        Assert.Equal("Sai số tiền", rejected.Proofs[0].RejectionReason);

        Assert.True((await _t.Orders().UploadProofAsync(user.Id, order.OrderNumber, TestDb.Png())).Succeeded);
        Assert.Equal(OrderStatus.PendingVerification, (await _t.Fresh().Orders.AsNoTracking().FirstAsync(o => o.Id == order.Id)).Status);
    }

    // ---- fulfilment ---------------------------------------------------------

    [Fact]
    public async Task Fulfilment_must_follow_the_workflow_in_order()
    {
        var user = _t.AddUser("alice"); var p = _t.AddProduct("A", 1_000_000m, 10);
        var order = await _t.PlaceOrderAsync(user, p, 1);

        Assert.False((await _t.Orders().AdvanceStatusAsync(order.Id, OrderStatus.Shipped, ActorRole.Employee, "s", "staff", null)).Succeeded);   // unpaid cannot ship
        await _t.Orders().UploadProofAsync(user.Id, order.OrderNumber, TestDb.Png());
        await _t.Orders().ApproveAsync(order.Id, "s", "staff", ActorRole.Admin);
        Assert.False((await _t.Orders().AdvanceStatusAsync(order.Id, OrderStatus.Shipped, ActorRole.Employee, "s", "staff", null)).Succeeded);   // must be Processing first
        Assert.True((await _t.Orders().AdvanceStatusAsync(order.Id, OrderStatus.Processing, ActorRole.Employee, "s", "staff", null)).Succeeded);
        Assert.True((await _t.Orders().AdvanceStatusAsync(order.Id, OrderStatus.Shipped, ActorRole.Employee, "s", "staff", "Giao qua GHN")).Succeeded);
        Assert.True((await _t.Orders().AdvanceStatusAsync(order.Id, OrderStatus.Delivered, ActorRole.Employee, "s", "staff", null)).Succeeded);
        Assert.Equal(OrderStatus.Delivered, (await _t.Fresh().Orders.AsNoTracking().FirstAsync(o => o.Id == order.Id)).Status);
        Assert.True(await _t.Fresh().OrderStatusHistory.CountAsync(h => h.OrderId == order.Id) >= 6);   // audit trail kept
    }

    [Fact]
    public async Task Employees_cannot_cancel_a_paid_order_but_admins_can_and_stock_returns()
    {
        var user = _t.AddUser("alice"); var p = _t.AddProduct("A", 1_000_000m, 10);
        var order = await _t.PlaceOrderAsync(user, p, 2);
        await _t.Orders().UploadProofAsync(user.Id, order.OrderNumber, TestDb.Png());
        await _t.Orders().ApproveAsync(order.Id, "s", "staff", ActorRole.Admin);

        Assert.False((await _t.Orders().CancelAsync(order.Id, ActorRole.Employee, "e", "emp", "x")).Succeeded);
        Assert.True((await _t.Orders().CancelAsync(order.Id, ActorRole.Admin, "a", "admin", "Hoàn tiền cho khách")).Succeeded);
        Assert.Equal(10, await StockAsync(p.Id));
        Assert.Equal(0, (await _t.Fresh().Products.AsNoTracking().FirstAsync(x => x.Id == p.Id)).SoldCount);   // sales count reversed
    }

    // ---- data isolation, tracking, reports ---------------------------------

    [Fact]
    public async Task Customers_only_see_their_own_orders()
    {
        var a = _t.AddUser("alice"); var b = _t.AddUser("bob"); var p = _t.AddProduct("A", 1_000_000m, 10);
        var orderA = await _t.PlaceOrderAsync(a, p, 1);

        Assert.NotNull(await _t.Orders().GetCustomerOrderAsync(a.Id, orderA.OrderNumber));
        Assert.Null(await _t.Orders().GetCustomerOrderAsync(b.Id, orderA.OrderNumber));
        Assert.Empty((await _t.Orders().GetCustomerOrdersAsync(b.Id, 1)).Items);
        Assert.Single((await _t.Orders().GetCustomerOrdersAsync(a.Id, 1)).Items);
    }

    [Fact]
    public async Task Tracking_needs_both_the_order_number_and_the_matching_phone()
    {
        var user = _t.AddUser("alice"); var p = _t.AddProduct("A", 1_000_000m, 10);
        var order = await _t.PlaceOrderAsync(user, p, 1, phone: "0912345678");

        Assert.NotNull(await _t.Orders().TrackAsync(order.OrderNumber, "0912345678"));
        Assert.NotNull(await _t.Orders().TrackAsync(order.OrderNumber.ToLower(), "+84 912 345 678"));
        Assert.Null(await _t.Orders().TrackAsync(order.OrderNumber, "0999999999"));
        Assert.Null(await _t.Orders().TrackAsync("DH000000NOPE", "0912345678"));
        Assert.Null(await _t.Orders().TrackAsync(order.OrderNumber, ""));
    }

    [Fact]
    public async Task Revenue_counts_only_verified_payments()
    {
        var user = _t.AddUser("alice"); var p = _t.AddProduct("A", 1_000_000m, 50);
        var now = DateTime.UtcNow;
        async Task<Order> Make(OrderStatus status, bool paid)
        {
            var o = await _t.PlaceOrderAsync(user, p, 1);
            var db = _t.Fresh();
            var row = await db.Orders.FirstAsync(x => x.Id == o.Id);
            row.Status = status; row.PaidUtc = paid ? now : null; row.Total = 1_000_000m;
            await db.SaveChangesAsync();
            return o;
        }
        await Make(OrderStatus.PendingPayment, false);
        await Make(OrderStatus.PendingVerification, false);
        await Make(OrderStatus.PaymentRejected, false);
        await Make(OrderStatus.Cancelled, false);
        await Make(OrderStatus.Paid, true);
        await Make(OrderStatus.Delivered, true);

        var report = await _t.Reports().GetSalesReportAsync(now.AddDays(-1), now);

        Assert.Equal(2_000_000m, report.Revenue);
        Assert.Equal(2, report.PaidOrders);
        Assert.Equal(6, report.OrdersCreated);
    }
}
