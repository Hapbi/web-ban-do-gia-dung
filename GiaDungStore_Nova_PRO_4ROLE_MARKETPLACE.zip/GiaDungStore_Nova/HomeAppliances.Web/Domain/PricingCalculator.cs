namespace HomeAppliances.Web.Domain;

public record PricingLine(decimal OriginalPrice, decimal CurrentPrice, int Quantity);

public record PricingResult(decimal Subtotal, decimal DiscountTotal, decimal ShippingFee, decimal Total);

/// <summary>
/// Server-side totals. Subtotal uses original prices, DiscountTotal is the saving from sale prices,
/// shipping is a flat fee that is waived once the discounted merchandise total reaches the threshold.
/// </summary>
public static class PricingCalculator
{
    public static PricingResult Calculate(IEnumerable<PricingLine> lines, decimal shippingFee, decimal freeShippingThreshold)
    {
        decimal subtotal = 0, discount = 0;
        var any = false;
        foreach (var l in lines)
        {
            if (l.Quantity <= 0) continue;
            any = true;
            var current = Math.Min(l.CurrentPrice, l.OriginalPrice);
            subtotal += l.OriginalPrice * l.Quantity;
            discount += (l.OriginalPrice - current) * l.Quantity;
        }
        var merchandise = subtotal - discount;
        var shipping = !any ? 0m
            : (freeShippingThreshold > 0 && merchandise >= freeShippingThreshold) ? 0m
            : Math.Max(0, shippingFee);
        return new PricingResult(subtotal, discount, shipping, merchandise + shipping);
    }
}
