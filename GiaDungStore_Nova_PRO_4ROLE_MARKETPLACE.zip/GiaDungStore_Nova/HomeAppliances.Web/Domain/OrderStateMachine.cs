namespace HomeAppliances.Web.Domain;

public enum OrderStatus
{
    PendingPayment = 0,
    PendingVerification = 1,
    Paid = 2,
    Processing = 3,
    Shipped = 4,
    Delivered = 5,
    Cancelled = 6,
    PaymentRejected = 7
}

public enum ActorRole { Customer, Employee, Admin, System }

/// <summary>
/// Single source of truth for which order status changes are legal and who may make them.
/// Pending Payment -> Pending Verification -> Paid -> Processing -> Shipped -> Delivered,
/// plus Cancelled and Payment Rejected.
/// </summary>
public static class OrderStateMachine
{
    private static readonly Dictionary<OrderStatus, Dictionary<OrderStatus, ActorRole[]>> Map = new()
    {
        [OrderStatus.PendingPayment] = new()
        {
            [OrderStatus.PendingVerification] = new[] { ActorRole.Customer, ActorRole.System },
            [OrderStatus.Cancelled] = new[] { ActorRole.Customer, ActorRole.Employee, ActorRole.Admin, ActorRole.System },
        },
        [OrderStatus.PendingVerification] = new()
        {
            [OrderStatus.Paid] = new[] { ActorRole.Employee, ActorRole.Admin },
            [OrderStatus.PaymentRejected] = new[] { ActorRole.Employee, ActorRole.Admin },
            [OrderStatus.PendingVerification] = new[] { ActorRole.Customer }, // replacing the proof
            [OrderStatus.Cancelled] = new[] { ActorRole.Customer, ActorRole.Employee, ActorRole.Admin },
        },
        [OrderStatus.PaymentRejected] = new()
        {
            [OrderStatus.PendingVerification] = new[] { ActorRole.Customer },
            [OrderStatus.Cancelled] = new[] { ActorRole.Customer, ActorRole.Employee, ActorRole.Admin, ActorRole.System },
        },
        [OrderStatus.Paid] = new()
        {
            [OrderStatus.Processing] = new[] { ActorRole.Employee, ActorRole.Admin },
            [OrderStatus.Cancelled] = new[] { ActorRole.Admin },
        },
        [OrderStatus.Processing] = new()
        {
            [OrderStatus.Shipped] = new[] { ActorRole.Employee, ActorRole.Admin },
            [OrderStatus.Cancelled] = new[] { ActorRole.Admin },
        },
        [OrderStatus.Shipped] = new()
        {
            [OrderStatus.Delivered] = new[] { ActorRole.Employee, ActorRole.Admin },
        },
        [OrderStatus.Delivered] = new(),
        [OrderStatus.Cancelled] = new(),
    };

    public static bool CanTransition(OrderStatus from, OrderStatus to, ActorRole actor) =>
        Map.TryGetValue(from, out var next) && next.TryGetValue(to, out var roles) && roles.Contains(actor);

    /// <summary>Statuses a staff member can move an order to by hand (payment decisions go through approve/reject).</summary>
    public static IReadOnlyList<OrderStatus> AllowedNext(OrderStatus from, ActorRole actor) =>
        Map.TryGetValue(from, out var next)
            ? next.Where(kv => kv.Value.Contains(actor) && kv.Key != from).Select(kv => kv.Key).ToList()
            : new List<OrderStatus>();

    /// <summary>True once a verified payment exists (used for revenue and "paid" labels).</summary>
    public static bool IsPaid(OrderStatus s) =>
        s is OrderStatus.Paid or OrderStatus.Processing or OrderStatus.Shipped or OrderStatus.Delivered;

    public static bool CanUploadProof(OrderStatus s) =>
        s is OrderStatus.PendingPayment or OrderStatus.PendingVerification or OrderStatus.PaymentRejected;

    public static bool IsFinal(OrderStatus s) => s is OrderStatus.Delivered or OrderStatus.Cancelled;

    public static string DisplayName(OrderStatus s) => s switch
    {
        OrderStatus.PendingPayment => "Chờ thanh toán",
        OrderStatus.PendingVerification => "Chờ xác minh thanh toán",
        OrderStatus.Paid => "Đã thanh toán",
        OrderStatus.Processing => "Đang xử lý",
        OrderStatus.Shipped => "Đang giao hàng",
        OrderStatus.Delivered => "Đã giao hàng",
        OrderStatus.Cancelled => "Đã hủy",
        OrderStatus.PaymentRejected => "Thanh toán bị từ chối",
        _ => s.ToString()
    };

    public static string PaymentLabel(OrderStatus s) => s switch
    {
        OrderStatus.PendingPayment => "Chưa thanh toán",
        OrderStatus.PendingVerification => "Chờ xác minh",
        OrderStatus.PaymentRejected => "Bị từ chối",
        OrderStatus.Cancelled => "Đã hủy",
        _ => "Đã thanh toán"
    };

    public static string CssClass(OrderStatus s) => s switch
    {
        OrderStatus.PendingPayment => "badge--warn",
        OrderStatus.PendingVerification => "badge--info",
        OrderStatus.Paid or OrderStatus.Processing or OrderStatus.Shipped or OrderStatus.Delivered => "badge--ok",
        _ => "badge--danger"
    };
}
