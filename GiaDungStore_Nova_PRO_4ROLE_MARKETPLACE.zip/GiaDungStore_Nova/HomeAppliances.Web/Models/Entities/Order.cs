using System.ComponentModel.DataAnnotations;
using Microsoft.EntityFrameworkCore;
using HomeAppliances.Web.Domain;

namespace HomeAppliances.Web.Models.Entities;

[Index(nameof(OrderNumber), IsUnique = true)]
[Index(nameof(UserId), nameof(CreatedUtc))]
[Index(nameof(Status))]
public class Order
{
    public int Id { get; set; }
    [MaxLength(24)] public string OrderNumber { get; set; } = "";
    public string UserId { get; set; } = "";
    public ApplicationUser? User { get; set; }
    [MaxLength(256)] public string CustomerEmail { get; set; } = "";
    [MaxLength(100)] public string ReceiverName { get; set; } = "";
    [MaxLength(20)] public string Phone { get; set; } = "";
    [MaxLength(300)] public string Address { get; set; } = "";
    [MaxLength(500)] public string? Notes { get; set; }

    // Amounts are copied at order time and never recalculated from live prices afterwards.
    [Precision(18, 0)] public decimal Subtotal { get; set; }
    [Precision(18, 0)] public decimal DiscountTotal { get; set; }
    [Precision(18, 0)] public decimal ShippingFee { get; set; }
    [Precision(18, 0)] public decimal Total { get; set; }

    public OrderStatus Status { get; set; } = OrderStatus.PendingPayment;
    public DateTime CreatedUtc { get; set; } = DateTime.UtcNow;
    public DateTime UpdatedUtc { get; set; } = DateTime.UtcNow;
    public DateTime? PaidUtc { get; set; }
    public DateTime? ShippedUtc { get; set; }
    public DateTime? DeliveredUtc { get; set; }
    public DateTime? CancelledUtc { get; set; }
    [MaxLength(500)] public string? CancelReason { get; set; }

    public List<OrderItem> Items { get; set; } = new();
    public List<OrderStatusHistory> History { get; set; } = new();
    public List<PaymentProof> Proofs { get; set; } = new();

    public bool IsPaid => OrderStateMachine.IsPaid(Status);
}

public class OrderItem
{
    public int Id { get; set; }
    public int OrderId { get; set; }
    public Order? Order { get; set; }
    public int ProductId { get; set; }
    public Product? Product { get; set; }
    [MaxLength(200)] public string ProductName { get; set; } = "";
    [MaxLength(220)] public string ProductSlug { get; set; } = "";
    [Precision(18, 0)] public decimal OriginalUnitPrice { get; set; }
    [Precision(18, 0)] public decimal UnitPrice { get; set; }
    public int Quantity { get; set; }
    [MaxLength(450)] public string? SellerUserId { get; set; }
    [Precision(18, 0)] public decimal PlatformFee { get; set; }
    [Precision(18, 0)] public decimal LineTotal { get; set; }
}

/// <summary>Audit trail of every status change of an order.</summary>
public class OrderStatusHistory
{
    public int Id { get; set; }
    public int OrderId { get; set; }
    public Order? Order { get; set; }
    public OrderStatus? FromStatus { get; set; }
    public OrderStatus ToStatus { get; set; }
    [MaxLength(450)] public string? ChangedByUserId { get; set; }
    [MaxLength(100)] public string ChangedByName { get; set; } = "";
    public ActorRole ChangedByRole { get; set; }
    [MaxLength(500)] public string? Note { get; set; }
    public DateTime CreatedUtc { get; set; } = DateTime.UtcNow;
}

public enum PaymentProofStatus { Pending = 0, Approved = 1, Rejected = 2, Superseded = 3 }

public class PaymentProof
{
    public int Id { get; set; }
    public int OrderId { get; set; }
    public Order? Order { get; set; }
    /// <summary>Path relative to the private storage root. Never served as a static file.</summary>
    [MaxLength(300)] public string StoredPath { get; set; } = "";
    [MaxLength(200)] public string OriginalFileName { get; set; } = "";
    [MaxLength(50)] public string ContentType { get; set; } = "";
    public long SizeBytes { get; set; }
    public DateTime UploadedUtc { get; set; } = DateTime.UtcNow;
    public PaymentProofStatus Status { get; set; } = PaymentProofStatus.Pending;
    [MaxLength(450)] public string? ReviewedByUserId { get; set; }
    public DateTime? ReviewedUtc { get; set; }
    [MaxLength(500)] public string? RejectionReason { get; set; }
}
