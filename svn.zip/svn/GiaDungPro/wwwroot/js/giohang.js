/* =========================================================
   GIỎ HÀNG — AJAX cập nhật số lượng realtime
   ========================================================= */
(function () {
    "use strict";

    function layToken() {
        var input = document.querySelector('input[name="__RequestVerificationToken"]');
        return input ? input.value : "";
    }

    function capNhatGio(sanPhamId, delta) {
        var token = layToken();
        if (!token) return;

        var formData = new FormData();
        formData.append("sanPhamId", sanPhamId);
        formData.append("delta", delta);
        formData.append("__RequestVerificationToken", token);

        fetch("/gio-hang/cap-nhat", {
            method: "POST",
            body: formData,
            credentials: "same-origin"
        })
        .then(function (r) { return r.json(); })
        .then(function (data) {
            if (!data.ok) {
                console.warn(data.thongBao);
                return;
            }

            if (data.daXoa) {
                var dong = document.querySelector('[data-san-pham-id="' + sanPhamId + '"]');
                if (dong) {
                    dong.style.transition = "all .3s";
                    dong.style.opacity = "0";
                    dong.style.transform = "translateX(-20px)";
                    setTimeout(function () {
                        dong.remove();
                        capNhatTongTien();
                        if (document.querySelectorAll(".dong-gio").length === 0) {
                            location.reload();
                        }
                    }, 300);
                }
                return;
            }

            var oNhap = document.querySelector('.so-luong-gio[data-id="' + sanPhamId + '"]');
            if (oNhap) oNhap.value = data.soLuong;

            var thanhTienEl = document.querySelector('[data-san-pham-id="' + sanPhamId + '"] [data-thanh-tien]');
            if (thanhTienEl) thanhTienEl.textContent = data.thanhTienFormat;

            document.querySelectorAll("[data-tong-tien]").forEach(function (el) {
                el.textContent = data.tongTienFormat;
            });

            var badge = document.querySelector(".cart-badge");
            if (badge) badge.textContent = data.tongSoLuong;
        })
        .catch(function (err) {
            console.error("Lỗi cập nhật giỏ:", err);
        });
    }

    function capNhatTongTien() {
        var tong = 0;
        document.querySelectorAll(".dong-gio").forEach(function (dong) {
            var gia = parseFloat(dong.dataset.gia || "0");
            var soLuongEl = dong.querySelector(".so-luong-gio");
            if (!soLuongEl) return;
            var soLuong = parseInt(soLuongEl.value || "0", 10);
            tong += gia * soLuong;
        });
        var dinhDang = tong.toLocaleString("vi-VN") + "đ";
        document.querySelectorAll("[data-tong-tien]").forEach(function (el) {
            el.textContent = dinhDang;
        });
    }

    document.querySelectorAll(".bo-dem-gio button[data-hanh-dong]").forEach(function (nut) {
        nut.addEventListener("click", function () {
            var sanPhamId = parseInt(nut.dataset.id, 10);
            var delta = nut.dataset.hanhDong === "tang" ? 1 : -1;
            capNhatGio(sanPhamId, delta);
        });
    });
})();
