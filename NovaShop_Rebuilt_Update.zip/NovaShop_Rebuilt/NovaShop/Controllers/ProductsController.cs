using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using NovaShop.Data;
using NovaShop.Models;
using NovaShop.Services;

namespace NovaShop.Controllers;

public class ProductsController : Controller
{
    private readonly ProductService _products;
    private readonly WishlistService _wishlist;
    private readonly ReviewService _reviews;
    private readonly RecentlyViewedService _recent;
    private readonly AuthService _auth;
    private readonly AppDbContext _db;

    public ProductsController(ProductService products, WishlistService wishlist, ReviewService reviews,
        RecentlyViewedService recent, AuthService auth, AppDbContext db)
    { _products = products; _wishlist = wishlist; _reviews = reviews; _recent = recent; _auth = auth; _db = db; }

    [Route("san-pham")]
    public async Task<IActionResult> Index(string? q, string? cat, string? brand,
        decimal? minPrice, decimal? maxPrice, bool inStockOnly = false, string sort = "newest", int page = 1) =>
        View(await _products.SearchAsync(q, cat, brand, minPrice, maxPrice, inStockOnly, sort, page));

    [Route("san-pham/{slug}")]
    public async Task<IActionResult> Detail(string slug)
    {
        var product = await _products.GetBySlugAsync(slug, incrementView: true);
        if (product == null) return NotFound();

        var uid = _auth.GetCurrentId();
        var myReview = uid.HasValue ? product.Reviews.FirstOrDefault(r => r.UserId == uid.Value) : null;

        bool canReview = false;
        if (uid.HasValue && myReview == null)
        {
            canReview = await _db.Orders
                .Where(o => o.UserId == uid.Value && (o.Status == OrderStatus.Delivered || o.Status == OrderStatus.Confirmed))
                .SelectMany(o => o.Items).AnyAsync(i => i.ProductId == product.Id);
        }

        _recent.Record(product.Id);
        var ratings = product.Reviews.Where(r => r.Status == ReviewStatus.Approved).ToList();

        var vm = new ProductDetailVM
        {
            Product = product,
            Related = await _products.GetRelatedAsync(product.Id, product.CategoryId),
            IsWishlisted = await _wishlist.IsWishlistedAsync(product.Id),
            CanReview = canReview,
            HasReviewed = myReview != null,
            AverageRating = ratings.Any() ? ratings.Average(r => r.Rating) : 0,
            ReviewCount = ratings.Count
        };
        for (int i = 1; i <= 5; i++) vm.RatingDistribution[i - 1] = ratings.Count(r => r.Rating == i);
        return View(vm);
    }

    [HttpPost, Route("danh-gia")]
    public async Task<IActionResult> AddReview(ReviewVM vm)
    {
        if (!ModelState.IsValid)
        {
            TempData["Error"] = "Thông tin không hợp lệ";
            var slug = (await _db.Products.FindAsync(vm.ProductId))?.Slug;
            return slug == null ? RedirectToAction("Index") : RedirectToAction("Detail", new { slug });
        }
        var (ok, msg) = await _reviews.CreateAsync(vm);
        TempData[ok ? "Success" : "Error"] = msg;
        var s = (await _db.Products.FindAsync(vm.ProductId))?.Slug;
        return s == null ? RedirectToAction("Index") : RedirectToAction("Detail", new { slug = s });
    }
}
