using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using HomeAppliances.Web.Data;
using HomeAppliances.Web.Infrastructure;
using HomeAppliances.Web.Models.Entities;
using HomeAppliances.Web.Models.ViewModels;

namespace HomeAppliances.Web.Controllers;

/// <summary>The signed-in user's own profile, password and address book. Every query is scoped to the current user id.</summary>
[Authorize]
[Route("tai-khoan")]
public class ProfileController : Controller
{
    private const int MaxAddresses = 10;
    private readonly UserManager<ApplicationUser> _users;
    private readonly SignInManager<ApplicationUser> _signIn;
    private readonly ApplicationDbContext _db;

    public ProfileController(UserManager<ApplicationUser> users, SignInManager<ApplicationUser> signIn, ApplicationDbContext db) { _users = users; _signIn = signIn; _db = db; }

    private string Uid => User.GetUserId()!;

    [HttpGet("")]
    public async Task<IActionResult> Index()
    {
        var u = await _users.GetUserAsync(User);
        return u == null ? Challenge() : View(new ProfileViewModel { Email = u.Email ?? "", FullName = u.FullName, PhoneNumber = u.PhoneNumber ?? "" });
    }

    [HttpPost("")]
    public async Task<IActionResult> UpdateProfile(ProfileViewModel vm)
    {
        var u = await _users.GetUserAsync(User);
        if (u == null) return Challenge();
        vm.Email = u.Email ?? "";
        if (!ModelState.IsValid) return View("Index", vm);
        u.FullName = vm.FullName.Trim(); u.PhoneNumber = vm.PhoneNumber.Trim();
        await _users.UpdateAsync(u);
        TempData["Success"] = "Đã cập nhật thông tin cá nhân.";
        return RedirectToAction(nameof(Index));
    }

    [HttpGet("doi-mat-khau")]
    public IActionResult ChangePassword() => View(new ChangePasswordViewModel());

    [HttpPost("doi-mat-khau")]
    public async Task<IActionResult> ChangePassword(ChangePasswordViewModel vm)
    {
        if (!ModelState.IsValid) return View(vm);
        var u = await _users.GetUserAsync(User);
        if (u == null) return Challenge();
        var result = await _users.ChangePasswordAsync(u, vm.CurrentPassword, vm.NewPassword);
        if (!result.Succeeded)
        {
            foreach (var e in result.Errors) ModelState.AddModelError(e.Code == "PasswordMismatch" ? nameof(vm.CurrentPassword) : nameof(vm.NewPassword), IdentityErrors.Translate(e));
            return View(vm);
        }
        await _signIn.RefreshSignInAsync(u);
        TempData["Success"] = "Đã đổi mật khẩu.";
        return RedirectToAction(nameof(Index));
    }

    // ---- address book -------------------------------------------------------

    [HttpGet("dia-chi")]
    public async Task<IActionResult> Addresses() =>
        View(await _db.ShippingAddresses.AsNoTracking().Where(a => a.UserId == Uid).OrderByDescending(a => a.IsDefault).ThenBy(a => a.Id).ToListAsync());

    [HttpGet("dia-chi/moi")]
    public IActionResult NewAddress() => View("AddressForm", new AddressViewModel());

    [HttpPost("dia-chi/moi")]
    public async Task<IActionResult> NewAddress(AddressViewModel vm)
    {
        if (!ModelState.IsValid) return View("AddressForm", vm);
        if (await _db.ShippingAddresses.CountAsync(a => a.UserId == Uid) >= MaxAddresses)
        {
            ModelState.AddModelError("", $"Bạn chỉ có thể lưu tối đa {MaxAddresses} địa chỉ.");
            return View("AddressForm", vm);
        }
        var hasAny = await _db.ShippingAddresses.AnyAsync(a => a.UserId == Uid);
        var a = new ShippingAddress { UserId = Uid, ReceiverName = vm.ReceiverName.Trim(), Phone = vm.Phone.Trim(), Address = vm.Address.Trim(), IsDefault = vm.IsDefault || !hasAny };
        if (a.IsDefault) await ClearDefaultAsync();
        _db.ShippingAddresses.Add(a);
        await _db.SaveChangesAsync();
        TempData["Success"] = "Đã thêm địa chỉ.";
        return RedirectToAction(nameof(Addresses));
    }

    [HttpGet("dia-chi/{id:int}/sua")]
    public async Task<IActionResult> EditAddress(int id)
    {
        var a = await _db.ShippingAddresses.AsNoTracking().FirstOrDefaultAsync(x => x.Id == id && x.UserId == Uid);
        return a == null ? NotFound() : View("AddressForm", new AddressViewModel { Id = a.Id, ReceiverName = a.ReceiverName, Phone = a.Phone, Address = a.Address, IsDefault = a.IsDefault });
    }

    [HttpPost("dia-chi/{id:int}/sua")]
    public async Task<IActionResult> EditAddress(int id, AddressViewModel vm)
    {
        var a = await _db.ShippingAddresses.FirstOrDefaultAsync(x => x.Id == id && x.UserId == Uid);   // other users' addresses are invisible
        if (a == null) return NotFound();
        vm.Id = id;
        if (!ModelState.IsValid) return View("AddressForm", vm);
        if (vm.IsDefault && !a.IsDefault) await ClearDefaultAsync();
        a.ReceiverName = vm.ReceiverName.Trim(); a.Phone = vm.Phone.Trim(); a.Address = vm.Address.Trim(); a.IsDefault = vm.IsDefault || a.IsDefault;
        await _db.SaveChangesAsync();
        TempData["Success"] = "Đã cập nhật địa chỉ.";
        return RedirectToAction(nameof(Addresses));
    }

    [HttpPost("dia-chi/{id:int}/mac-dinh")]
    public async Task<IActionResult> MakeDefault(int id)
    {
        var a = await _db.ShippingAddresses.FirstOrDefaultAsync(x => x.Id == id && x.UserId == Uid);
        if (a == null) return NotFound();
        await ClearDefaultAsync();
        a.IsDefault = true;
        await _db.SaveChangesAsync();
        return RedirectToAction(nameof(Addresses));
    }

    [HttpPost("dia-chi/{id:int}/xoa")]
    public async Task<IActionResult> DeleteAddress(int id)
    {
        var a = await _db.ShippingAddresses.FirstOrDefaultAsync(x => x.Id == id && x.UserId == Uid);
        if (a == null) return NotFound();
        _db.ShippingAddresses.Remove(a);
        await _db.SaveChangesAsync();
        TempData["Success"] = "Đã xóa địa chỉ.";
        return RedirectToAction(nameof(Addresses));
    }

    private async Task ClearDefaultAsync()
    {
        foreach (var d in await _db.ShippingAddresses.Where(x => x.UserId == Uid && x.IsDefault).ToListAsync()) d.IsDefault = false;
    }
}
