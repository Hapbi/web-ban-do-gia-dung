using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using HomeAppliances.Web.Infrastructure;
using HomeAppliances.Web.Services;

namespace HomeAppliances.Web.Areas.Admin.Controllers;

[Area("Admin"), Authorize(Policy = AppPolicies.AdminOnly)]
public class DashboardController : Controller
{
    private readonly IReportService _reports;
    public DashboardController(IReportService reports) => _reports = reports;
    public async Task<IActionResult> Index() => View(await _reports.GetDashboardAsync());
}
