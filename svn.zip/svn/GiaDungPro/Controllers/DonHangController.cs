using CuaHangGiaDungPro.Data;
using CuaHangGiaDungPro.Helpers;
using CuaHangGiaDungPro.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace CuaHangGiaDungPro.Controllers;

[Authorize]
public class DonHangController : Controller
{
    private readonly AppDb _db;
    public DonHangController(AppDb db) => _db = db;

    [Route("thanh-toan")]
    public IActionResult ThanhToan()
    {
        var list = GioHangHelper.DanhSach(HttpContext.Session, _db);
        if (list.Count == 0)
        {
            TempData["Loi"] = "Giỏ hàng trống";
            return RedirectToAction("Index", "GioHang");
        }
        var uid = TienIch.LayIdNguoiDung(User);
        var user = uid.HasValue ? _db.NguoiDungs.Find(uid.Value) : null;
        ViewBag.HoTen = user?.HoTen ?? "";
        ViewBag.DienThoai = user?.DienThoai ?? "";
        ViewBag.CauHinh = _db.CauHinhs.FirstOrDefault();
        return View(list);
    }

    [HttpPost, Route("thanh-toan")]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> ThanhToan(string hoTen, string dienThoai, string diaChi, string? ghiChu, string phuongThuc)
    {
        var uid = TienIch.LayIdNguoiDung(User);
        if (uid == null) return RedirectToAction("DangNhap", "TaiKhoan");
        if (string.IsNullOrWhiteSpace(hoTen) || string.IsNullOrWhiteSpace(dienThoai) || string.IsNullOrWhiteSpace(diaChi))
        {
            TempData["Loi"] = "Vui lòng nhập đầy đủ thông tin giao hàng";
            return RedirectToAction(nameof(ThanhToan));
        }

        var gio = GioHangHelper.Lay(HttpContext.Session);
        gio = gio.Where(x => x.Key > 0 && x.Value > 0).ToDictionary(x => x.Key, x => x.Value);
        if (gio.Count == 0)
        {
            TempData["Loi"] = "Giỏ hàng trống";
            return RedirectToAction("Index", "GioHang");
        }

        // Re-read stock and prices inside a serializable transaction to reduce overselling.
        await using var transaction = await _db.Database.BeginTransactionAsync(System.Data.IsolationLevel.Serializable);
        var ids = gio.Keys.ToList();
        var sanPhams = await _db.SanPhams
            .Where(x => ids.Contains(x.Id) && x.DangBan)
            .ToDictionaryAsync(x => x.Id);

        foreach (var item in gio)
        {
            if (!sanPhams.TryGetValue(item.Key, out var sp))
            {
                await transaction.RollbackAsync();
                TempData["Loi"] = "Một sản phẩm trong giỏ không còn kinh doanh. Vui lòng kiểm tra lại giỏ hàng.";
                return RedirectToAction("Index", "GioHang");
            }
            if (sp.TonKho < item.Value)
            {
                await transaction.RollbackAsync();
                TempData["Loi"] = $"'{sp.Ten}' hiện chỉ còn {sp.TonKho} sản phẩm. Vui lòng cập nhật giỏ hàng.";
                return RedirectToAction("Index", "GioHang");
            }
        }

        string maDon;
        do { maDon = "DH" + DateTime.Now.ToString("yyMMdd") + Guid.NewGuid().ToString("N")[..4].ToUpperInvariant(); }
        while (await _db.DonHangs.AnyAsync(x => x.MaDon == maDon));

        var don = new DonHang
        {
            MaDon = maDon, NguoiDungId = uid.Value,
            HoTen = hoTen.Trim(), DienThoai = dienThoai.Trim(), DiaChi = diaChi.Trim(),
            GhiChu = ghiChu?.Trim(),
            PhuongThucThanhToan = phuongThuc == global::CuaHangGiaDungPro.Models.PhuongThucThanhToan.ChuyenKhoan
                ? global::CuaHangGiaDungPro.Models.PhuongThucThanhToan.ChuyenKhoan : global::CuaHangGiaDungPro.Models.PhuongThucThanhToan.COD,
            TrangThai = global::CuaHangGiaDungPro.Models.TrangThaiDon.ChoXacNhan,
            ThanhToan = global::CuaHangGiaDungPro.Models.ThanhToan.ChuaThanhToan
        };

        foreach (var item in gio)
        {
            var sp = sanPhams[item.Key];
            sp.TonKho -= item.Value;
            sp.DaBan += item.Value;
            var donGia = sp.GiaHienTai;
            don.ChiTiet.Add(new ChiTietDonHang
            {
                SanPhamId = sp.Id, TenSanPham = sp.Ten, AnhSanPham = sp.AnhChinh,
                DonGia = donGia, SoLuong = item.Value
            });
            don.TongTien += donGia * item.Value;
        }

        _db.DonHangs.Add(don);
        await _db.SaveChangesAsync();
        await transaction.CommitAsync();
        GioHangHelper.XoaHet(HttpContext.Session);

        TempData["ThanhCong"] = "Đặt hàng thành công!";
        return RedirectToAction(nameof(ChiTiet), new { maDon });
    }

    [Route("don-hang-cua-toi")]
    public async Task<IActionResult> CuaToi()
    {
        var uid = TienIch.LayIdNguoiDung(User);
        if (uid == null) return RedirectToAction("DangNhap", "TaiKhoan");
        var list = await _db.DonHangs.Include(x => x.ChiTiet)
            .Where(x => x.NguoiDungId == uid)
            .OrderByDescending(x => x.NgayTao).ToListAsync();
        return View(list);
    }

    [Route("don-hang/{maDon}")]
    public async Task<IActionResult> ChiTiet(string maDon)
    {
        var uid = TienIch.LayIdNguoiDung(User);
        var don = await _db.DonHangs.Include(x => x.ChiTiet).FirstOrDefaultAsync(x => x.MaDon == maDon);
        if (don == null) return NotFound();
        if (don.NguoiDungId != uid && !TienIch.LaQuanTri(User)) return NotFound();
        ViewBag.CauHinh = _db.CauHinhs.FirstOrDefault();
        return View(don);
    }
}
