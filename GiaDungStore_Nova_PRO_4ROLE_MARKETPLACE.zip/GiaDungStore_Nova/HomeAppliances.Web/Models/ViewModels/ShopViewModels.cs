using System.ComponentModel.DataAnnotations;
using HomeAppliances.Web.Domain;
using HomeAppliances.Web.Models.Entities;

namespace HomeAppliances.Web.Models.ViewModels;

public class CartLineViewModel
{
    public int ProductId { get; set; }
    public string Slug { get; set; } = "";
    public string Name { get; set; } = "";
    public string Brand { get; set; } = "";
    public string CategorySlug { get; set; } = "";
    public string? ImageUrl { get; set; }
    public decimal OriginalPrice { get; set; }
    public decimal UnitPrice { get; set; }
    public int Quantity { get; set; }
    public int StockQuantity { get; set; }
    public decimal LineTotal => UnitPrice * Quantity;
    public bool HasProblem => Quantity > StockQuantity;
}

public class CartViewModel
{
    public List<CartLineViewModel> Lines { get; set; } = new();
    public decimal Subtotal { get; set; }
    public decimal DiscountTotal { get; set; }
    public decimal ShippingFee { get; set; }
    public decimal Total { get; set; }
    public decimal FreeShippingThreshold { get; set; }
    public int ItemCount => Lines.Sum(l => l.Quantity);
    public bool IsEmpty => Lines.Count == 0;
    public bool HasProblems => Lines.Any(l => l.HasProblem);
}

public class CheckoutViewModel
{
    [Required(ErrorMessage = "Vui lòng nhập họ tên người nhận.")]
    [StringLength(100, ErrorMessage = "Họ tên tối đa 100 ký tự.")]
    [Display(Name = "Họ và tên người nhận")]
    public string ReceiverName { get; set; } = "";

    [Required(ErrorMessage = "Vui lòng nhập số điện thoại.")]
    [RegularExpression(@"^(\+84|0)\d{9,10}$", ErrorMessage = "Số điện thoại không hợp lệ (ví dụ 0912345678).")]
    [Display(Name = "Số điện thoại")]
    public string Phone { get; set; } = "";

    [Required(ErrorMessage = "Vui lòng nhập địa chỉ giao hàng.")]
    [StringLength(300, MinimumLength = 10, ErrorMessage = "Địa chỉ từ 10 đến 300 ký tự.")]
    [Display(Name = "Địa chỉ giao hàng")]
    public string Address { get; set; } = "";

    [StringLength(500, ErrorMessage = "Ghi chú tối đa 500 ký tự.")]
    [Display(Name = "Ghi chú giao hàng")]
    public string? Notes { get; set; }

    [Display(Name = "Lưu địa chỉ này vào sổ địa chỉ")]
    public bool SaveAddress { get; set; }

    public CartViewModel Cart { get; set; } = new();
    public List<ShippingAddress> SavedAddresses { get; set; } = new();
}

public class OrderListItem
{
    public int Id { get; set; }
    public string OrderNumber { get; set; } = "";
    public string ReceiverName { get; set; } = "";
    public string Phone { get; set; } = "";
    public decimal Total { get; set; }
    public OrderStatus Status { get; set; }
    public DateTime CreatedUtc { get; set; }
    public int ItemCount { get; set; }
}

public class OrderSearch
{
    public string? Q { get; set; }
    public OrderStatus? Status { get; set; }
    public DateTime? From { get; set; }
    public DateTime? To { get; set; }
    public int Page { get; set; } = 1;
}

public class TrackOrderViewModel
{
    [Required(ErrorMessage = "Vui lòng nhập mã đơn hàng.")]
    [Display(Name = "Mã đơn hàng")]
    public string OrderNumber { get; set; } = "";

    [Required(ErrorMessage = "Vui lòng nhập số điện thoại đặt hàng.")]
    [Display(Name = "Số điện thoại đặt hàng")]
    public string Phone { get; set; } = "";

    public TrackResult? Result { get; set; }
    public bool Searched { get; set; }
}

public class TrackResult
{
    public string OrderNumber { get; set; } = "";
    public OrderStatus Status { get; set; }
    public DateTime CreatedUtc { get; set; }
    public decimal Total { get; set; }
    public List<(OrderStatus Status, DateTime AtUtc)> Timeline { get; set; } = new();
}

/// <summary>Everything the order detail pages need (customer and staff).</summary>
public class OrderDetailViewModel
{
    public Order Order { get; set; } = null!;
    public BankTransferSettings? Bank { get; set; }
    public string TransferReference { get; set; } = "";
    public bool CanCustomerCancel { get; set; }
    public bool CanStaffCancel { get; set; }
    public bool CanUploadProof { get; set; }
    public PaymentProof? LatestProof { get; set; }
    public ActorRole Actor { get; set; }
    public bool CanVerifyPayments { get; set; }
    public List<OrderStatus> NextStatuses { get; set; } = new();
}

public class StaffOrderListViewModel
{
    public OrderSearch Search { get; set; } = new();
    public Services.PagedResult<OrderListItem> Result { get; set; } = new();
}


public class SellerListingCreateViewModel
{
    [Required, StringLength(200, MinimumLength = 3, ErrorMessage = "Tên sản phẩm từ 3 đến 200 ký tự.")]
    [Display(Name = "Tên sản phẩm")] public string Name { get; set; } = "";
    [Required, StringLength(100)] [Display(Name = "Thương hiệu")] public string Brand { get; set; } = "";
    [Required, Range(1, 100000000000, ErrorMessage = "Giá bán phải lớn hơn 0.")] [Display(Name = "Giá bán (₫)")] public decimal Price { get; set; }
    [Required, Range(1, 1000000, ErrorMessage = "Số lượng phải lớn hơn 0.")] [Display(Name = "Số lượng")] public int StockQuantity { get; set; }
    [Required, Range(1, int.MaxValue, ErrorMessage = "Vui lòng chọn danh mục.")] [Display(Name = "Danh mục")] public int CategoryId { get; set; }
    [Required, StringLength(4000, MinimumLength = 20, ErrorMessage = "Mô tả từ 20 đến 4000 ký tự.")] [Display(Name = "Mô tả")] public string Description { get; set; } = "";
    [Url(ErrorMessage = "Ảnh không hợp lệ.")] [StringLength(500)] [Display(Name = "URL ảnh sản phẩm")] public string? ImageUrl { get; set; }
    public List<Microsoft.AspNetCore.Mvc.Rendering.SelectListItem> Categories { get; set; } = new();
}

public class SellerListingRow
{
    public int Id { get; set; }
    public string Name { get; set; } = "";
    public decimal Price { get; set; }
    public int StockQuantity { get; set; }
    public bool IsActive { get; set; }
    public int ListingStatus { get; set; }
    public DateTime CreatedUtc { get; set; }
}

public class SellerDashboardViewModel
{
    public List<SellerListingRow> Listings { get; set; } = new();
    public int PendingCount { get; set; }
    public int ApprovedCount { get; set; }
    public decimal PlatformFeeRate { get; set; } = 0.07m;
}
