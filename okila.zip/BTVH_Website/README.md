# BTVH — Website bán đồ điện gia dụng

Dự án ASP.NET Core MVC + Entity Framework Core SQLite, được dựng lại từ mã nguồn anh cung cấp.

## Chạy trên Windows
Cách nhanh: cài .NET 8 SDK rồi nhấp đúp `Chay_BTVH.bat`.

Cách thủ công:
1. Cài .NET 8 SDK.
2. Giải nén thư mục dự án.
3. Mở terminal trong thư mục `BTVH_Website/NovaShop` (nơi có `NovaShop.csproj`).
4. Chạy `dotnet restore` rồi `dotnet run`.
5. Mở http://localhost:5080

Lần chạy đầu tiên sẽ tạo `btvh.db` và dữ liệu demo.

## Tài khoản demo
- Admin: `admin@nova.vn` / `admin123`
- Staff: `staff@nova.vn` / `staff123`
- Customer: `customer@nova.vn` / `customer123`

Đổi mật khẩu demo trước khi đưa website lên Internet. Dữ liệu demo và ảnh sản phẩm là dữ liệu minh họa; cần xác minh lại thông tin sản phẩm trước khi kinh doanh thật. Chức năng khôi phục mật khẩu hiện chưa tích hợp nhà cung cấp email và đã hiển thị thông báo đúng trạng thái demo.

## Ghi chú kiểm thử
Mã nguồn được tách thành cấu trúc dự án và bổ sung các tệp khởi chạy còn thiếu (`.csproj`, `Program.cs`, `appsettings.json`, launch settings). Môi trường đóng gói không có .NET SDK, vì vậy chưa thể chạy `dotnet build` hoặc kiểm thử tích hợp tại đây. Hãy chạy `dotnet build` trên máy có .NET 8 SDK để xác nhận trước khi triển khai.
