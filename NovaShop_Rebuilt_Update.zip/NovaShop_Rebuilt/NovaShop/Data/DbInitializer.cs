using System.Security.Cryptography;
using System.Text;
using Microsoft.EntityFrameworkCore;
using NovaShop.Helpers;
using NovaShop.Models;

namespace NovaShop.Data;

public static class DbInitializer
{
    public static string Hash(string pwd)
    {
        using var sha = SHA256.Create();
        return Convert.ToBase64String(sha.ComputeHash(Encoding.UTF8.GetBytes("NOVA_SHOP_2024_" + pwd)));
    }

    public static async Task InitializeAsync(AppDbContext db)
    {
        await db.Database.EnsureCreatedAsync();

        if (!await db.SiteSettings.AnyAsync())
            db.SiteSettings.Add(new SiteSettings());
        if (!await db.BankSettings.AnyAsync())
            db.BankSettings.Add(new BankSettings
            {
                BankName = "Vietcombank",
                AccountNumber = "0123456789",
                AccountHolder = "NGUYEN VAN A",
                QrImageUrl = "https://img.vietqr.io/image/VCB-0123456789-compact.png"
            });
        await db.SaveChangesAsync();

        if (await db.Users.AnyAsync()) return;

        // ---- USERS ----
        db.Users.AddRange(
            new User { Email = "admin@nova.vn", PasswordHash = Hash("admin123"), FullName = "Quản Trị Viên", Role = "Admin", Phone = "0900000001", Avatar = "A" },
            new User { Email = "staff@nova.vn", PasswordHash = Hash("staff123"), FullName = "Nhân Viên Bán Hàng", Role = "Staff", Phone = "0900000002", Avatar = "S", CanVerifyPayments = true },
            new User { Email = "customer@nova.vn", PasswordHash = Hash("customer123"), FullName = "Nguyễn Văn Khách", Role = "Customer", Phone = "0901234567", Avatar = "K" }
        );
        await db.SaveChangesAsync();

        // ---- CATEGORIES ----
        var cats = new[]
        {
            new Category { Name = "Tủ lạnh", Slug = "tu-lanh", Icon = "❄️", DisplayOrder = 1 },
            new Category { Name = "Máy giặt", Slug = "may-giat", Icon = "🌀", DisplayOrder = 2 },
            new Category { Name = "Điều hòa", Slug = "dieu-hoa", Icon = "🌡️", DisplayOrder = 3 },
            new Category { Name = "Nồi cơm", Slug = "noi-com", Icon = "🍚", DisplayOrder = 4 },
            new Category { Name = "Lò vi sóng", Slug = "lo-vi-song", Icon = "📻", DisplayOrder = 5 },
            new Category { Name = "Máy hút bụi", Slug = "may-hut-bui", Icon = "🧹", DisplayOrder = 6 },
            new Category { Name = "Quạt", Slug = "quat", Icon = "💨", DisplayOrder = 7 },
            new Category { Name = "Máy lọc KK", Slug = "may-loc-khong-khi", Icon = "🌿", DisplayOrder = 8 },
            new Category { Name = "Bếp", Slug = "bep", Icon = "🔥", DisplayOrder = 9 },
            new Category { Name = "Đồ gia dụng", Slug = "do-gia-dung", Icon = "🏠", DisplayOrder = 10 }
        };
        db.Categories.AddRange(cats);
        await db.SaveChangesAsync();

        // ---- BRANDS ----
        var brands = new[] { "Samsung", "LG", "Panasonic", "Sharp", "Toshiba", "Electrolux", "Philips", "Xiaomi", "Midea", "Bosch" };
        foreach (var bn in brands)
            db.Brands.Add(new Brand { Name = bn, Slug = Ext.Slugify(bn) });
        await db.SaveChangesAsync();

        // ---- TAGS ----
        foreach (var tn in new[] { "inverter", "bestseller", "cao-cấp", "tiết-kiệm", "khuyến-mãi" })
            db.Tags.Add(new Tag { Name = tn, Slug = Ext.Slugify(tn) });
        await db.SaveChangesAsync();

        // ---- PRODUCTS - 50 sản phẩm với ẢNH KHÁC NHAU ----
        var allCats = await db.Categories.ToListAsync();
        var allBrands = await db.Brands.ToListAsync();
        var products = new List<Product>();
        var rng = new Random(42);
        var idxByCat = new Dictionary<int, int>();

        void AddP(string name, int catIdx, int brandIdx, decimal price, decimal? sale, int stock, int sold, bool featured, string customImg = null)
        {
            var cat = allCats[catIdx];
            idxByCat.TryGetValue(cat.Id, out var idx);
            idxByCat[cat.Id] = idx + 1;
            var img = customImg ?? Images.For(cat.Slug, idx);

            var p = new Product
            {
                Name = name,
                Slug = Ext.Slugify(name) + "-" + Guid.NewGuid().ToString("N")[..4],
                BrandId = allBrands[brandIdx].Id,
                CategoryId = cat.Id,
                OriginalPrice = price,
                SalePrice = sale,
                Stock = stock,
                SoldCount = sold,
                IsFeatured = featured,
                ShortDescription = $"{name} — chính hãng, bảo hành dài hạn.",
                Description = $"{name} là lựa chọn tuyệt vời cho gia đình bạn. Thiết kế hiện đại, tiết kiệm điện, bền bỉ theo thời gian. Bảo hành chính hãng 24 tháng.",
                ViewCount = sold * 3 + rng.Next(20, 400)
            };
            p.Images.Add(new ProductImage { Url = img, IsPrimary = true, SortOrder = 0 });
            p.Specs.Add(new ProductSpec { Name = "Thương hiệu", Value = allBrands[brandIdx].Name, SortOrder = 0 });
            p.Specs.Add(new ProductSpec { Name = "Bảo hành", Value = "24 tháng chính hãng", SortOrder = 1 });
            p.Specs.Add(new ProductSpec { Name = "Xuất xứ", Value = "Chính hãng", SortOrder = 2 });
            products.Add(p);
        }

        // Tủ lạnh (5)
        AddP("Tủ Lạnh Inverter Samsung 488L", 0, 0, 18990000, 15490000, 14, 320, true);
        AddP("Tủ Lạnh Side-by-Side LG 617L", 0, 1, 34900000, 29900000, 6, 145, true);
        AddP("Tủ Lạnh Mini Toshiba 90L", 0, 4, 3590000, 2990000, 30, 540, false);
        AddP("Tủ Lạnh Sharp 323L", 0, 3, 9290000, 8290000, 18, 210, false);
        AddP("Tủ Lạnh Panasonic 322L", 0, 2, 12900000, 10900000, 10, 180, false);

        // Máy giặt (5)
        AddP("Máy Giặt LG 9kg AI DD", 1, 1, 9990000, 8490000, 22, 410, true);
        AddP("Máy Giặt Samsung 10kg", 1, 0, 8490000, 7290000, 15, 320, false);
        AddP("Máy Giặt Sấy Electrolux 10/6kg", 1, 5, 18990000, 16490000, 8, 95, true);
        AddP("Máy Giặt Toshiba 8kg", 1, 4, 5290000, 4790000, 25, 380, false);
        AddP("Máy Giặt Bosch 8kg", 1, 9, 13990000, 11990000, 10, 130, false);

        // Điều hòa (5)
        AddP("Điều Hòa Samsung 9.000 BTU", 2, 0, 8490000, 6990000, 30, 520, true);
        AddP("Điều Hòa LG 2 Chiều 12.000 BTU", 2, 1, 12990000, 10990000, 20, 340, true);
        AddP("Điều Hòa Panasonic 9.000 BTU", 2, 2, 9990000, 8490000, 18, 290, false);
        AddP("Điều Hòa Sharp 12.000 BTU", 2, 3, 8490000, 7290000, 22, 410, false);
        AddP("Điều Hòa Tủ Đứng Midea 24.000 BTU", 2, 8, 24900000, 21900000, 5, 45, false);

        // Nồi cơm (5)
        AddP("Nồi Cơm Sharp 1.8L", 3, 3, 1890000, 1490000, 60, 900, true);
        AddP("Nồi Cơm Cao Tần Toshiba 1L", 3, 4, 4990000, 3990000, 15, 260, false);
        AddP("Nồi Cơm Panasonic 1.8L", 3, 2, 1290000, 1090000, 40, 620, false);
        AddP("Nồi Cơm Điện Tử Samsung 1.8L", 3, 0, 2190000, 1890000, 25, 350, false);
        AddP("Nồi Cơm LG 1.8L", 3, 1, 1790000, 1490000, 30, 420, false);

        // Lò vi sóng (4)
        AddP("Lò Vi Sóng Samsung 23L", 4, 0, 2490000, 1890000, 28, 330, true);
        AddP("Lò Nướng Sharp 32L", 4, 3, 2990000, 2490000, 12, 180, false);
        AddP("Lò Vi Sóng Toshiba 20L", 4, 4, 1490000, 1090000, 35, 450, false);
        AddP("Lò Vi Sóng LG 25L", 4, 1, 2890000, 2490000, 15, 220, false);

        // Máy hút bụi (5)
        AddP("Máy Hút Bụi Xiaomi Không Dây", 5, 7, 3990000, 2990000, 20, 280, true);
        AddP("Robot Hút Bụi Xiaomi", 5, 7, 8990000, 6990000, 12, 180, true);
        AddP("Máy Hút Bụi Samsung 1800W", 5, 0, 2990000, 2290000, 18, 340, false);
        AddP("Máy Hút Bụi Philips Cầm Tay", 5, 6, 2490000, 1890000, 25, 220, false);
        AddP("Máy Hút Bụi LG 2000W", 5, 1, 3490000, 2890000, 15, 190, false);

        // Quạt (5)
        AddP("Quạt Đứng Xiaomi Remote", 6, 7, 1290000, 990000, 70, 800, true);
        AddP("Quạt Điều Hòa Sharp", 6, 3, 3990000, 3290000, 16, 140, false);
        AddP("Quạt Trần Panasonic 5 Cánh", 6, 2, 3290000, 2790000, 22, 175, false);
        AddP("Quạt Hộp Toshiba", 6, 4, 590000, 450000, 120, 1500, false);
        AddP("Quạt Cây Mitsubishi 5 Cánh", 6, 8, 2190000, 1890000, 30, 260, false);

        // Máy lọc KK (4)
        AddP("Máy Lọc KK Xiaomi 4 Pro", 7, 7, 5990000, 4990000, 11, 175, true);
        AddP("Máy Lọc KK Sharp 40m²", 7, 3, 4990000, 3990000, 15, 220, false);
        AddP("Máy Lọc KK Philips", 7, 6, 6990000, 5490000, 9, 130, false);
        AddP("Máy Lọc KK Panasonic", 7, 2, 8990000, 7490000, 8, 95, false);

        // Bếp (5)
        AddP("Bếp Điện Đôi Xiaomi", 8, 7, 3990000, 2990000, 18, 195, true);
        AddP("Bếp Gas Âm Bosch 2 Bếp", 8, 9, 6990000, 5990000, 10, 95, false);
        AddP("Bếp Từ Đơn Sharp", 8, 3, 1990000, 1490000, 25, 280, false);
        AddP("Máy Hút Mùi Electrolux", 8, 5, 4990000, 4290000, 12, 85, false);
        AddP("Bếp Điện Đôi LG", 8, 1, 5990000, 4990000, 14, 120, false);

        // Đồ gia dụng (7)
        AddP("Nồi Chiên Không Dầu Philips 6.2L", 9, 6, 5990000, 4590000, 20, 180, true);
        AddP("Máy Sấy Tóc Philips 1800W", 9, 6, 890000, 690000, 40, 480, false);
        AddP("Bàn Là Hơi Nước Philips", 9, 6, 3290000, 2590000, 25, 280, false);
        AddP("Máy Xay Sinh Tố Panasonic", 9, 2, 1490000, 1090000, 35, 620, false);
        AddP("Ấm Siêu Tốc Toshiba 1.7L", 9, 4, 690000, 490000, 60, 890, false);
        AddP("Nồi Áp Suất Điện Tử Sharp", 9, 3, 2990000, 2490000, 18, 165, false);
        AddP("Máy Rửa Bát Bosch 12 Bộ", 9, 9, 18900000, 15900000, 6, 45, true);

        db.Products.AddRange(products);
        await db.SaveChangesAsync();

        // ---- COUPONS ----
        db.Coupons.AddRange(
            new Coupon { Code = "WELCOME10", Description = "Giảm 10% đơn đầu tiên", Type = DiscountType.Percentage, Value = 10, MinOrderAmount = 500000, MaxDiscount = 500000, UsageLimit = 1000 },
            new Coupon { Code = "NOVA200K", Description = "Giảm 200.000đ cho đơn từ 2 triệu", Type = DiscountType.FixedAmount, Value = 200000, MinOrderAmount = 2000000, UsageLimit = 500 },
            new Coupon { Code = "FREESHIP", Description = "Miễn phí vận chuyển", Type = DiscountType.FixedAmount, Value = 30000, UsageLimit = 2000 },
            new Coupon { Code = "SALE20", Description = "Giảm 20% đơn từ 5 triệu", Type = DiscountType.Percentage, Value = 20, MinOrderAmount = 5000000, MaxDiscount = 2000000, UsageLimit = 200 }
        );

        // ---- BLOGS ----
        db.BlogPosts.AddRange(
            new BlogPost { Title = "5 mẹo chọn mua tủ lạnh tiết kiệm điện", Slug = "meo-chon-tu-lanh", Summary = "Chọn tủ lạnh đúng cách để tiết kiệm điện năng.", Content = "Chọn công suất phù hợp, ưu tiên Inverter, kiểm tra nhãn năng lượng...", CoverImage = "https://images.unsplash.com/photo-1571175443880-49e1d25b2bc5?w=1200&q=80", AuthorName = "Admin", Category = "Hướng dẫn", IsPublished = true, PublishedAt = DateTime.Now.AddDays(-5), ViewCount = 234 },
            new BlogPost { Title = "So sánh máy giặt cửa trước và cửa trên", Slug = "so-sanh-may-giat", Summary = "Đâu là lựa chọn tốt hơn cho gia đình?", Content = "Máy giặt cửa trước giặt sạch hơn, tiết kiệm nước...", CoverImage = "https://images.unsplash.com/photo-1626806787461-102c1bfaaea1?w=1200&q=80", AuthorName = "Admin", Category = "So sánh", IsPublished = true, PublishedAt = DateTime.Now.AddDays(-3), ViewCount = 189 }
        );

        // ---- BANNERS ----
        db.Banners.Add(new Banner
        {
            Title = "Khuyến mãi tháng 10",
            ImageUrl = "https://images.unsplash.com/photo-1607082348824-0a96f2a4b9da?w=1600&q=80&auto=format&fit=crop",
            LinkUrl = "/san-pham",
            Position = "home-top",
            SortOrder = 1
        });

        // ---- CONTACTS ----
        db.ContactMessages.AddRange(
            new ContactMessage { Type = ContactType.Contact, FullName = "Trần Văn A", Email = "a@test.com", Phone = "0901111111", Subject = "Hỏi về tủ lạnh", Message = "Tôi muốn hỏi về tủ lạnh Samsung 488L.", Status = ContactStatus.New },
            new ContactMessage { Type = ContactType.Feedback, FullName = "Lê Thị B", Email = "b@test.com", Phone = "0902222222", Subject = "Phản ánh dịch vụ", Message = "Nhân viên giao hàng thân thiện, cảm ơn shop.", Status = ContactStatus.Processing }
        );
        await db.SaveChangesAsync();

        // ---- SAMPLE ORDERS ----
        var customer = await db.Users.FirstAsync(u => u.Email == "customer@nova.vn");
        var now = DateTime.Now;
        var orders = new List<Order>();

        for (int i = 0; i < 8; i++)
        {
            var orderProducts = products.OrderBy(x => rng.Next()).Take(rng.Next(1, 4)).ToList();
            var subtotal = orderProducts.Sum(p => p.OriginalPrice);
            var totalDiscount = orderProducts.Sum(p => p.OriginalPrice - p.CurrentPrice);
            var shipping = 30000m;
            var total = subtotal - totalDiscount + shipping;
            var daysAgo = rng.Next(0, 30);

            OrderStatus status = daysAgo switch
            {
                < 2 => OrderStatus.Pending,
                < 5 => OrderStatus.Confirmed,
                < 10 => OrderStatus.Shipping,
                _ => OrderStatus.Delivered
            };

            var payment = status == OrderStatus.Delivered ? PaymentStatus.Paid : (status == OrderStatus.Pending ? PaymentStatus.Unpaid : PaymentStatus.Paid);
            var pm = i % 2 == 0 ? PaymentMethod.COD : PaymentMethod.BankTransfer;

            var order = new Order
            {
                Code = "DH" + now.AddDays(-daysAgo).ToString("yyMMdd") + Guid.NewGuid().ToString("N")[..4].ToUpper(),
                UserId = customer.Id,
                CustomerName = "Khách Hàng Demo",
                Phone = "0901234567",
                Email = "customer@nova.vn",
                Address = "123 Lê Lợi, Q.1, TP.HCM",
                Subtotal = subtotal,
                Discount = totalDiscount,
                Shipping = shipping,
                Total = total,
                Status = status,
                Payment = payment,
                PaymentMethod = pm,
                CreatedAt = now.AddDays(-daysAgo),
                ConfirmedAt = status >= OrderStatus.Confirmed ? now.AddDays(-daysAgo + 1) : null,
                ShippedAt = status >= OrderStatus.Shipping ? now.AddDays(-daysAgo + 2) : null,
                DeliveredAt = status == OrderStatus.Delivered ? now.AddDays(-daysAgo + 3) : null
            };

            foreach (var p in orderProducts)
            {
                order.Items.Add(new OrderItem
                {
                    ProductId = p.Id, ProductName = p.Name, ProductImage = p.PrimaryImage, ProductSlug = p.Slug,
                    UnitPrice = p.CurrentPrice, OriginalUnitPrice = p.OriginalPrice, Quantity = 1
                });
            }
            order.History.Add(new OrderStatusHistory { Status = OrderStatus.Pending, Note = "Đơn được tạo", ChangedBy = "Customer", CreatedAt = order.CreatedAt });
            orders.Add(order);
        }
        db.Orders.AddRange(orders);

        // ---- SAMPLE REVIEWS ----
        db.Reviews.AddRange(
            new Review { ProductId = products[0].Id, UserId = customer.Id, Rating = 5, Title = "Tuyệt vời", Content = "Rất hài lòng với sản phẩm này!", IsVerifiedPurchase = true, Status = ReviewStatus.Approved, CreatedAt = now.AddDays(-10) },
            new Review { ProductId = products[5].Id, UserId = customer.Id, Rating = 4, Title = "Tốt", Content = "Chất lượng tốt, giá hợp lý.", IsVerifiedPurchase = true, Status = ReviewStatus.Approved, CreatedAt = now.AddDays(-7) }
        );

        await db.SaveChangesAsync();
    }
}
