using CuaHangGiaDungPro.Helpers;
using CuaHangGiaDungPro.Models;
using Microsoft.EntityFrameworkCore;

namespace CuaHangGiaDungPro.Data;

public static class KhoiTaoDuLieu
{
    public static async Task KhoiTaoAsync(AppDb db)
    {
        await db.Database.EnsureCreatedAsync();

        if (!await db.CauHinhs.AnyAsync())
        {
            db.CauHinhs.Add(new CauHinh
            {
                TenShop     = "Gia Dụng Pro",
                Slogan      = "Đồ gia dụng chính hãng cho mọi nhà",
                DiaChi      = "123 Đường Nguyễn Trãi, Thanh Xuân, Hà Nội",
                DienThoai   = "0855 081 828",
                Email       = "lienhe@giadungpro.vn",
                GioMoCua    = "8:00 - 21:00 hằng ngày",
                NganHang    = "Vietcombank",
                SoTaiKhoan  = "0855081828",
                ChuTaiKhoan = "NGUYEN VAN A"
            });
            await db.SaveChangesAsync();
        }

        if (!await db.NguoiDungs.AnyAsync())
        {
            db.NguoiDungs.AddRange(
                new NguoiDung { Email = "admin@shop.vn", HoTen = "Quản Trị Viên", DienThoai = "0900000001",
                                VaiTro = VaiTro.Admin, MatKhauHash = MatKhauHelper.Hash("Admin@123") },
                new NguoiDung { Email = "staff@shop.vn", HoTen = "Nhân Viên", DienThoai = "0900000002",
                                VaiTro = VaiTro.NhanVien, Quyen = "sanpham,donhang,baocao",
                                MatKhauHash = MatKhauHelper.Hash("Staff@123") },
                new NguoiDung { Email = "khach@shop.vn", HoTen = "Khách Hàng", DienThoai = "0901234567",
                                VaiTro = VaiTro.KhachHang, MatKhauHash = MatKhauHelper.Hash("Khach@123") }
            );
            await db.SaveChangesAsync();
        }

        if (!await db.DanhMucs.AnyAsync())
        {
            db.DanhMucs.AddRange(
                new DanhMuc { Ten = "Nhà bếp",         Icon = "🍳" },
                new DanhMuc { Ten = "Điện gia dụng",   Icon = "🔌" },
                new DanhMuc { Ten = "Vệ sinh nhà cửa", Icon = "🧹" },
                new DanhMuc { Ten = "Phòng ngủ",       Icon = "🛏️" },
                new DanhMuc { Ten = "Điện cầm tay",    Icon = "🔧" },
                new DanhMuc { Ten = "Đồ dùng khác",    Icon = "📦" }
            );
            await db.SaveChangesAsync();
        }

        if (!await db.SanPhams.AnyAsync())
        {
            var dm = await db.DanhMucs.OrderBy(x => x.Id).ToListAsync();
            var homNay = DateTime.Now;

            var dsSanPham = new List<SanPham>
            {
                new() { Ten = "Nồi cơm điện tử 1.8L", DanhMucId = dm[0].Id, GiaGoc = 1290000, GiaKhuyenMai = 1090000, TonKho = 25, NoiBat = true,
                        MoTa = "Nồi cơm điện tử dung tích 1.8L, phù hợp gia đình 3-5 người.",
                        ThongSo = "Dung tích: 1.8L\nCông suất: 700W\nBảo hành: 24 tháng",
                        AnhChinh = "https://images.unsplash.com/photo-1584269600519-112d071b35e6?w=700",
                        NgayTao = homNay.AddDays(-30) },
                new() { Ten = "Ấm siêu tốc inox 1.7L", DanhMucId = dm[0].Id, GiaGoc = 450000, TonKho = 32,
                        MoTa = "Ấm siêu tốc inox 304, tự ngắt khi sôi.",
                        ThongSo = "Dung tích: 1.7L\nChất liệu: Inox 304",
                        AnhChinh = "https://images.unsplash.com/photo-1585232004423-244e0e6904e3?w=700",
                        NgayTao = homNay.AddDays(-28) },
                new() { Ten = "Máy xay sinh tố đa năng", DanhMucId = dm[0].Id, GiaGoc = 890000, GiaKhuyenMai = 790000, TonKho = 14, NoiBat = true,
                        MoTa = "Máy xay sinh tố 3 cối, xay đá và trái cây.",
                        ThongSo = "Công suất: 600W\nSố cối: 3",
                        AnhChinh = "https://images.unsplash.com/photo-1570222094114-d054a817e56b?w=700",
                        NgayTao = homNay.AddDays(-25) },
                new() { Ten = "Chảo chống dính 26cm", DanhMucId = dm[0].Id, GiaGoc = 320000, TonKho = 40,
                        MoTa = "Chảo chống dính đường kính 26cm.",
                        ThongSo = "Đường kính: 26cm\nBề mặt: Chống dính",
                        AnhChinh = "https://images.unsplash.com/photo-1585515320310-259814833e62?w=700",
                        NgayTao = homNay.AddDays(-22) },
                new() { Ten = "Quạt đứng 5 cánh", DanhMucId = dm[1].Id, GiaGoc = 1250000, GiaKhuyenMai = 1090000, TonKho = 18,
                        MoTa = "Quạt đứng 5 cánh, 3 tốc độ gió.",
                        ThongSo = "Số cánh: 5\nCông suất: 55W",
                        AnhChinh = "https://images.unsplash.com/photo-1595371685289-84b288247e2f?w=700",
                        NgayTao = homNay.AddDays(-20) },
                new() { Ten = "Nồi chiên không dầu 5L", DanhMucId = dm[1].Id, GiaGoc = 2490000, GiaKhuyenMai = 2190000, TonKho = 9, NoiBat = true,
                        MoTa = "Nồi chiên không dầu 5L, công nghệ Rapid Air.",
                        ThongSo = "Dung tích: 5L\nCông suất: 1500W",
                        AnhChinh = "https://images.unsplash.com/photo-1626200419199-391ae4be7a41?w=700",
                        NgayTao = homNay.AddDays(-18) },
                new() { Ten = "Máy lọc không khí", DanhMucId = dm[1].Id, GiaGoc = 2190000, TonKho = 7,
                        MoTa = "Máy lọc không khí cho phòng 30-40m².",
                        ThongSo = "Diện tích: 30-40m²\nMàng lọc: HEPA",
                        AnhChinh = "https://images.unsplash.com/photo-1585771724684-38269d6639fd?w=700",
                        NgayTao = homNay.AddDays(-15) },
                new() { Ten = "Bàn ủi hơi nước", DanhMucId = dm[1].Id, GiaGoc = 650000, TonKho = 20,
                        MoTa = "Bàn ủi hơi nước cầm tay.",
                        ThongSo = "Công suất: 1800W\nBình nước: 300ml",
                        AnhChinh = "https://images.unsplash.com/photo-1585846416120-3a7354ed7d39?w=700",
                        NgayTao = homNay.AddDays(-12) },
                new() { Ten = "Máy hút bụi cầm tay", DanhMucId = dm[2].Id, GiaGoc = 1590000, GiaKhuyenMai = 1390000, TonKho = 11, NoiBat = true,
                        MoTa = "Máy hút bụi cầm tay gọn nhẹ.",
                        ThongSo = "Công suất: 120W\nPin: 2500mAh",
                        AnhChinh = "https://images.unsplash.com/photo-1558317374-067fb5f30001?w=700",
                        NgayTao = homNay.AddDays(-10) },
                new() { Ten = "Robot hút bụi lau nhà", DanhMucId = dm[2].Id, GiaGoc = 4990000, GiaKhuyenMai = 4290000, TonKho = 5, NoiBat = true,
                        MoTa = "Robot hút bụi và lau nhà tự động.",
                        ThongSo = "Pin: 5200mAh\nDiện tích: 250m²",
                        AnhChinh = "https://images.unsplash.com/photo-1589834390005-5d4fb9bf3d32?w=700",
                        NgayTao = homNay.AddDays(-8) },
                new() { Ten = "Bộ cây lau nhà 2 ngăn", DanhMucId = dm[2].Id, GiaGoc = 390000, TonKho = 28,
                        MoTa = "Bộ cây lau nhà có thùng vắt 2 ngăn.",
                        ThongSo = "Chất liệu: Nhựa ABS + inox",
                        AnhChinh = "https://images.unsplash.com/photo-1585421514738-01798e348b17?w=700",
                        NgayTao = homNay.AddDays(-6) },
                new() { Ten = "Đèn bàn LED chống cận", DanhMucId = dm[3].Id, GiaGoc = 280000, TonKho = 35,
                        MoTa = "Đèn bàn LED chống cận, 3 chế độ ánh sáng.",
                        ThongSo = "Công suất: 8W\nÁnh sáng: 3 chế độ",
                        AnhChinh = "https://images.unsplash.com/photo-1507473885765-e6ed057f782c?w=700",
                        NgayTao = homNay.AddDays(-4) },
                new() { Ten = "Máy sấy tóc 1800W", DanhMucId = dm[3].Id, GiaGoc = 520000, GiaKhuyenMai = 450000, TonKho = 16,
                        MoTa = "Máy sấy tóc 1800W, 2 chế độ nhiệt.",
                        ThongSo = "Công suất: 1800W\nChế độ: 2 nhiệt + 2 gió",
                        AnhChinh = "https://images.unsplash.com/photo-1522338140262-f46f5913618a?w=700",
                        NgayTao = homNay.AddDays(-3) },
                new() { Ten = "Máy khoan cầm tay 750W", DanhMucId = dm[4].Id, GiaGoc = 1290000, TonKho = 12,
                        MoTa = "Máy khoan cầm tay đa năng 750W.",
                        ThongSo = "Công suất: 750W\nTốc độ: 0-3000 rpm",
                        AnhChinh = "https://images.unsplash.com/photo-1504148455328-c376907d081c?w=700",
                        NgayTao = homNay.AddDays(-2) },
                new() { Ten = "Bộ tua vít 32 món", DanhMucId = dm[4].Id, GiaGoc = 350000, TonKho = 50,
                        MoTa = "Bộ tua vít 32 món đa năng.",
                        ThongSo = "Số món: 32\nChất liệu: Thép CR-V",
                        AnhChinh = "https://images.unsplash.com/photo-1530124566582-a618bc2615dc?w=700",
                        NgayTao = homNay.AddDays(-1) },
                new() { Ten = "Hộp đựng thực phẩm 5 chiếc", DanhMucId = dm[5].Id, GiaGoc = 180000, TonKho = 60, NoiBat = true,
                        MoTa = "Hộp đựng thực phẩm 5 chiếc, nhựa PP an toàn.",
                        ThongSo = "Số chiếc: 5\nChất liệu: Nhựa PP",
                        AnhChinh = "https://images.unsplash.com/photo-1584464491033-06628f3a6b7b?w=700",
                        NgayTao = homNay }
            };

            db.SanPhams.AddRange(dsSanPham);
            await db.SaveChangesAsync();
        }

        if (!await db.DanhGias.AnyAsync())
        {
            var khach = await db.NguoiDungs.FirstOrDefaultAsync(x => x.Email == "khach@shop.vn");
            var sps   = await db.SanPhams.Take(5).ToListAsync();
            if (khach != null && sps.Any())
            {
                db.DanhGias.AddRange(
                    new DanhGia { SanPhamId = sps[0].Id, NguoiDungId = khach.Id, SoSao = 5, TieuDe = "Rất tốt", NoiDung = "Nồi cơm nấu ngon, giữ nóng tốt." },
                    new DanhGia { SanPhamId = sps[1].Id, NguoiDungId = khach.Id, SoSao = 4, TieuDe = "Ổn", NoiDung = "Chất lượng ổn trong tầm giá." },
                    new DanhGia { SanPhamId = sps[2].Id, NguoiDungId = khach.Id, SoSao = 5, TieuDe = "Đáng tiền", NoiDung = "Máy xay mạnh, xay đá tốt." }
                );
                await db.SaveChangesAsync();
            }
        }

        if (!await db.Banners.AnyAsync())
        {
            db.Banners.AddRange(
                new Banner { TieuDe = "Ưu đãi mùa hè — giảm đến 30%", AnhUrl = "https://images.unsplash.com/photo-1556909114-f6e7ad7d3136?w=1600", ThuTu = 1, LienKet = "/san-pham" },
                new Banner { TieuDe = "Bộ sưu tập nhà bếp mới",       AnhUrl = "https://images.unsplash.com/photo-1556909212-d5b604d0c90d?w=1600", ThuTu = 2, LienKet = "/san-pham" }
            );
            await db.SaveChangesAsync();
        }
    }
}
