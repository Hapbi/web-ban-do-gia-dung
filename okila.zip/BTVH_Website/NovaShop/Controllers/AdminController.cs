using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using NovaShop.Data;
using NovaShop.Models;
using NovaShop.Services;

namespace NovaShop.Controllers;

[Authorize(Roles = "Admin")]
public class AdminController : Controller
{
    private readonly AppDbContext _db;
    private readonly ReportService _reports;
    public AdminController(AppDbContext db, ReportService reports) { _db = db; _reports = reports; }

    [Route("admin")]
    public async Task<IActionResult> Index() => View(await _reports.GetDashboardAsync());

    // ---- PRODUCTS ----
    [Route("admin/san-pham")]
    public async Task<IActionResult> Products(string? q, int? catId, bool? active, bool lowStockOnly = false, int page = 1)
    {
        var query = _db.Products.Include(p => p.Category).Include(p => p.Brand).Include(p => p.Images).AsQueryable();
        if (!string.IsNullOrWhiteSpace(q)) query = query.Where(p => p.Name.Contains(q));
        if (catId.HasValue) query = query.Where(p => p.CategoryId == catId.Value);
        if (active.HasValue) query = query.Where(p => p.IsActive == active.Value);
        if (lowStockOnly) query = query.Where(p => p.Stock <= 5);

        var total = await query.CountAsync();
        var products = await query.OrderByDescending(p => p.Id).Skip((page - 1) * 20).Take(20).ToListAsync();
        return View(new AdminProductListVM
        {
            Products = products, Search = q, CategoryId = catId, IsActive = active, LowStockOnly = lowStockOnly,
            Categories = await _db.Categories.ToListAsync(), Page = page, Total = total
        });
    }

    [HttpGet, Route("admin/san-pham/them")]
    [HttpGet, Route("admin/san-pham/{id}/sua")]
    public async Task<IActionResult> ProductEdit(int? id)
    {
        ProductEditVM vm;
        if (id == null)
        {
            vm = new ProductEditVM { IsActive = true };
        }
        else
        {
            var p = await _db.Products.Include(x => x.Images).Include(x => x.Specs).FirstOrDefaultAsync(x => x.Id == id);
            if (p == null) return NotFound();
            vm = new ProductEditVM
            {
                Id = p.Id, Name = p.Name, Slug = p.Slug, ShortDescription = p.ShortDescription,
                Description = p.Description, CategoryId = p.CategoryId, BrandId = p.BrandId,
                OriginalPrice = p.OriginalPrice, SalePrice = p.SalePrice, Stock = p.Stock,
                IsActive = p.IsActive, IsFeatured = p.IsFeatured, Tags = p.Tags,
                ImageUrls = p.Images.OrderBy(i => i.SortOrder).Select(i => i.Url).ToList(),
                Specs = p.Specs.OrderBy(s => s.SortOrder).Select(s => (s.Name, s.Value)).ToList()
            };
        }
        vm.Categories = await _db.Categories.ToListAsync();
        vm.Brands = await _db.Brands.ToListAsync();
        return View(vm);
    }

    [HttpPost, Route("admin/san-pham/luu")]
    public async Task<IActionResult> ProductSave(ProductEditVM vm, string? imageUrls, string? specsText)
    {
        if (string.IsNullOrWhiteSpace(vm.Name) || vm.OriginalPrice <= 0)
        {
            TempData["Error"] = "Vui lòng nhập đầy đủ thông tin";
            vm.Categories = await _db.Categories.ToListAsync();
            vm.Brands = await _db.Brands.ToListAsync();
            return View("ProductEdit", vm);
        }

        Product p;
        if (vm.Id == 0)
        {
            p = new Product();
            p.Slug = Slugify(vm.Name);
            _db.Products.Add(p);
        }
        else
        {
            p = (await _db.Products.Include(x => x.Images).Include(x => x.Specs).FirstOrDefaultAsync(x => x.Id == vm.Id))!;
            if (p == null) return NotFound();
            _db.ProductImages.RemoveRange(p.Images);
            _db.ProductSpecs.RemoveRange(p.Specs);
        }

        p.Name = vm.Name.Trim();
        p.ShortDescription = vm.ShortDescription?.Trim() ?? "";
        p.Description = vm.Description?.Trim() ?? "";
        p.CategoryId = vm.CategoryId;
        p.BrandId = vm.BrandId;
        p.OriginalPrice = vm.OriginalPrice;
        p.SalePrice = vm.SalePrice;
        p.Stock = vm.Stock;
        p.IsActive = vm.IsActive;
        p.IsFeatured = vm.IsFeatured;
        p.Tags = vm.Tags ?? "";
        p.UpdatedAt = DateTime.Now;

        // Images
        if (!string.IsNullOrWhiteSpace(imageUrls))
        {
            var urls = imageUrls.Split('\n', StringSplitOptions.RemoveEmptyEntries);
            for (int i = 0; i < urls.Length; i++)
                p.Images.Add(new ProductImage { Url = urls[i].Trim(), IsPrimary = i == 0, SortOrder = i });
        }
        // Specs
        if (!string.IsNullOrWhiteSpace(specsText))
        {
            var lines = specsText.Split('\n', StringSplitOptions.RemoveEmptyEntries);
            for (int i = 0; i < lines.Length; i++)
            {
                var idx = lines[i].IndexOf(':');
                if (idx > 0)
                    p.Specs.Add(new ProductSpec { Name = lines[i][..idx].Trim(), Value = lines[i][(idx + 1)..].Trim(), SortOrder = i });
            }
        }

        await _db.SaveChangesAsync();
        TempData["Success"] = "Đã lưu sản phẩm";
        return RedirectToAction(nameof(Products));
    }

    [HttpPost, Route("admin/san-pham/{id}/xoa")]
    public async Task<IActionResult> ProductDelete(int id)
    {
        var p = await _db.Products.FindAsync(id);
        if (p != null) { _db.Products.Remove(p); await _db.SaveChangesAsync(); TempData["Success"] = "Đã xóa"; }
        return RedirectToAction(nameof(Products));
    }

    [HttpPost, Route("admin/san-pham/{id}/an")]
    public async Task<IActionResult> ProductToggle(int id)
    {
        var p = await _db.Products.FindAsync(id);
        if (p != null) { p.IsActive = !p.IsActive; await _db.SaveChangesAsync(); }
        return RedirectToAction(nameof(Products));
    }

    // ---- ORDERS ----
    [Route("admin/don-hang")]
    public async Task<IActionResult> Orders(OrderStatus? status, string? q, int page = 1)
    {
        var query = _db.Orders.Include(o => o.Items).AsQueryable();
        if (status.HasValue) query = query.Where(o => o.Status == status.Value);
        if (!string.IsNullOrWhiteSpace(q)) query = query.Where(o => o.Code.Contains(q) || o.CustomerName.Contains(q) || o.Phone.Contains(q));

        var total = await query.CountAsync();
        var orders = await query.OrderByDescending(o => o.CreatedAt).Skip((page - 1) * 20).Take(20).ToListAsync();

        return View(new AdminOrderListVM
        {
            Orders = orders, Status = status, Search = q, Page = page, Total = total,
            StatusCounts = await _db.Orders.GroupBy(o => o.Status).ToDictionaryAsync(g => g.Key, g => g.Count())
        });
    }

    [HttpGet, Route("admin/don-hang/{id}")]
    public async Task<IActionResult> OrderDetail(int id)
    {
        var o = await _db.Orders.Include(x => x.Items).Include(x => x.History).Include(x => x.User).FirstOrDefaultAsync(x => x.Id == id);
        if (o == null) return NotFound();
        return View(o);
    }

    // ---- USERS ----
    [Route("admin/nguoi-dung")]
    public async Task<IActionResult> Users(string? role, string? q)
    {
        var query = _db.Users.AsQueryable();
        if (!string.IsNullOrWhiteSpace(role)) query = query.Where(u => u.Role == role);
        if (!string.IsNullOrWhiteSpace(q)) query = query.Where(u => u.Email.Contains(q) || u.FullName.Contains(q));
        ViewBag.RoleFilter = role;
        ViewBag.Search = q;
        return View(await query.OrderByDescending(u => u.CreatedAt).ToListAsync());
    }

    [HttpPost, Route("admin/nguoi-dung/{id}/role")]
    public async Task<IActionResult> SetRole(int id, string role)
    {
        var u = await _db.Users.FindAsync(id);
        if (u != null && new[] { "Admin", "Staff", "Customer" }.Contains(role))
        {
            u.Role = role;
            await _db.SaveChangesAsync();
            TempData["Success"] = "Đã cập nhật vai trò";
        }
        return RedirectToAction(nameof(Users));
    }

    [HttpPost, Route("admin/nguoi-dung/{id}/khoa")]
    public async Task<IActionResult> ToggleLock(int id)
    {
        var u = await _db.Users.FindAsync(id);
        if (u != null) { u.IsActive = !u.IsActive; await _db.SaveChangesAsync(); TempData["Success"] = "Đã cập nhật"; }
        return RedirectToAction(nameof(Users));
    }

    // ---- BLOG ----
    [Route("admin/blog")]
    public async Task<IActionResult> Blog() => View(await _db.BlogPosts.OrderByDescending(b => b.CreatedAt).ToListAsync());

    [HttpGet, Route("admin/blog/them")]
    [HttpGet, Route("admin/blog/{id}/sua")]
    public async Task<IActionResult> BlogEdit(int? id)
    {
        if (id == null) return View(new BlogPost());
        var p = await _db.BlogPosts.FindAsync(id);
        return p == null ? NotFound() : View(p);
    }

    [HttpPost, Route("admin/blog/luu")]
    public async Task<IActionResult> BlogSave(BlogPost input)
    {
        if (string.IsNullOrWhiteSpace(input.Title)) { TempData["Error"] = "Vui lòng nhập tiêu đề"; return RedirectToAction(nameof(Blog)); }
        BlogPost p;
        if (input.Id == 0) { p = new BlogPost { Slug = Slugify(input.Title) }; _db.BlogPosts.Add(p); }
        else { p = (await _db.BlogPosts.FindAsync(input.Id))!; if (p == null) return NotFound(); }

        p.Title = input.Title.Trim();
        p.Summary = input.Summary?.Trim() ?? "";
        p.Content = input.Content ?? "";
        p.CoverImage = input.CoverImage ?? "";
        p.AuthorName = input.AuthorName ?? "Admin";
        p.Category = input.Category ?? "";
        p.Tags = input.Tags ?? "";
        p.IsPublished = input.IsPublished;
        if (input.IsPublished && p.PublishedAt == null) p.PublishedAt = DateTime.Now;
        await _db.SaveChangesAsync();
        TempData["Success"] = "Đã lưu bài viết";
        return RedirectToAction(nameof(Blog));
    }

    [HttpPost, Route("admin/blog/{id}/xoa")]
    public async Task<IActionResult> BlogDelete(int id)
    {
        var p = await _db.BlogPosts.FindAsync(id);
        if (p != null) { _db.BlogPosts.Remove(p); await _db.SaveChangesAsync(); TempData["Success"] = "Đã xóa"; }
        return RedirectToAction(nameof(Blog));
    }

    // ---- COUPONS ----
    [Route("admin/ma-giam-gia")]
    public async Task<IActionResult> Coupons() => View(await _db.Coupons.OrderByDescending(c => c.Id).ToListAsync());

    [HttpPost, Route("admin/ma-giam-gia/them")]
    public async Task<IActionResult> AddCoupon(Coupon c)
    {
        if (!string.IsNullOrWhiteSpace(c.Code))
        {
            c.Code = c.Code.Trim().ToUpper();
            if (!await _db.Coupons.AnyAsync(x => x.Code == c.Code))
            {
                _db.Coupons.Add(c);
                await _db.SaveChangesAsync();
                TempData["Success"] = "Đã thêm mã giảm giá";
            }
            else TempData["Error"] = "Mã đã tồn tại";
        }
        return RedirectToAction(nameof(Coupons));
    }

    [HttpPost, Route("admin/ma-giam-gia/{id}/xoa")]
    public async Task<IActionResult> DeleteCoupon(int id)
    {
        var c = await _db.Coupons.FindAsync(id);
        if (c != null) { _db.Coupons.Remove(c); await _db.SaveChangesAsync(); TempData["Success"] = "Đã xóa"; }
        return RedirectToAction(nameof(Coupons));
    }

    // ---- MESSAGES ----
    [Route("admin/tin-nhan")]
    public async Task<IActionResult> Messages() =>
        View(await _db.ContactMessages.OrderByDescending(m => m.CreatedAt).ToListAsync());

    [HttpPost, Route("admin/tin-nhan/{id}/doc")]
    public async Task<IActionResult> MarkMessageRead(int id)
    {
        var m = await _db.ContactMessages.FindAsync(id);
        if (m != null) { m.IsRead = true; await _db.SaveChangesAsync(); }
        return RedirectToAction(nameof(Messages));
    }

    // ---- REVIEWS ----
    [Route("admin/danh-gia")]
    public async Task<IActionResult> Reviews() =>
        View(await _db.Reviews.Include(r => r.User).Include(r => r.Product).OrderByDescending(r => r.CreatedAt).ToListAsync());

    private static string Slugify(string text)
    {
        if (string.IsNullOrWhiteSpace(text)) return Guid.NewGuid().ToString("N")[..8];
        var s = text.ToLower().Normalize(System.Text.NormalizationForm.FormD);
        var sb = new System.Text.StringBuilder();
        foreach (var c in s)
        {
            if (System.Globalization.CharUnicodeInfo.GetUnicodeCategory(c) == System.Globalization.UnicodeCategory.NonSpacingMark) continue;
            sb.Append(char.IsLetterOrDigit(c) ? c : '-');
        }
        var slug = System.Text.RegularExpressions.Regex.Replace(sb.ToString(), "-+", "-").Trim('-');
        return slug + "-" + Guid.NewGuid().ToString("N")[..4];
    }
}


####################################################################################################
