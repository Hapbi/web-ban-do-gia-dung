using System.Security.Claims;
using CuaHangGiaDungPro.Data;
using CuaHangGiaDungPro.Helpers;
using CuaHangGiaDungPro.Models;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.EntityFrameworkCore;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddControllersWithViews();
builder.Services.AddDbContext<AppDb>(options =>
    options.UseSqlite(builder.Configuration.GetConnectionString("DefaultConnection") ?? "Data Source=giadung.db"));

builder.Services.AddAuthentication(CookieAuthenticationDefaults.AuthenticationScheme)
    .AddCookie(options =>
    {
        options.Cookie.Name = "GiaDungPro.Auth";
        options.Cookie.HttpOnly = true;
        options.Cookie.SameSite = SameSiteMode.Lax;
        options.Cookie.SecurePolicy = CookieSecurePolicy.SameAsRequest;
        options.LoginPath = "/tai-khoan/dang-nhap";
        options.AccessDeniedPath = "/tai-khoan/tu-choi";
        options.ExpireTimeSpan = TimeSpan.FromHours(12);
        options.SlidingExpiration = true;
        options.Events = new CookieAuthenticationEvents
        {
            // Keep account lock and role changes effective even while an old cookie exists.
            OnValidatePrincipal = async context =>
            {
                var principal = context.Principal;
                var idValue = principal?.FindFirstValue(ClaimTypes.NameIdentifier);
                if (!int.TryParse(idValue, out var userId))
                {
                    context.RejectPrincipal();
                    await context.HttpContext.SignOutAsync(CookieAuthenticationDefaults.AuthenticationScheme);
                    return;
                }

                var db = context.HttpContext.RequestServices.GetRequiredService<AppDb>();
                var account = await db.NguoiDungs.AsNoTracking()
                    .FirstOrDefaultAsync(x => x.Id == userId);
                if (account == null || account.BiKhoa)
                {
                    context.RejectPrincipal();
                    await context.HttpContext.SignOutAsync(CookieAuthenticationDefaults.AuthenticationScheme);
                    return;
                }

                var permissions = QuyenHelper.HieuLuc(account.VaiTro, account.Quyen);
                var oldPermissions = principal!.FindAll("Quyen").Select(x => x.Value).OrderBy(x => x).ToArray();
                var newPermissions = permissions.OrderBy(x => x).ToArray();
                var needsRefresh = principal.FindFirstValue(ClaimTypes.Role) != account.VaiTro
                    || principal.FindFirstValue(ClaimTypes.Name) != account.HoTen
                    || principal.FindFirstValue(ClaimTypes.Email) != account.Email
                    || !oldPermissions.SequenceEqual(newPermissions);

                if (needsRefresh)
                {
                    var claims = new List<Claim>
                    {
                        new(ClaimTypes.NameIdentifier, account.Id.ToString()),
                        new(ClaimTypes.Name, account.HoTen),
                        new(ClaimTypes.Email, account.Email),
                        new(ClaimTypes.Role, account.VaiTro)
                    };
                    claims.AddRange(permissions.Select(permission => new Claim("Quyen", permission)));
                    var identity = new ClaimsIdentity(claims, CookieAuthenticationDefaults.AuthenticationScheme);
                    context.ReplacePrincipal(new ClaimsPrincipal(identity));
                    context.ShouldRenew = true;
                }
            }
        };
    });

builder.Services.AddAuthorization();
builder.Services.AddDistributedMemoryCache();
builder.Services.AddSession(options =>
{
    options.Cookie.Name = "GiaDungPro.Session";
    options.Cookie.HttpOnly = true;
    options.Cookie.IsEssential = true;
    options.Cookie.SameSite = SameSiteMode.Lax;
    options.Cookie.SecurePolicy = CookieSecurePolicy.SameAsRequest;
    options.IdleTimeout = TimeSpan.FromHours(4);
});

var app = builder.Build();

using (var scope = app.Services.CreateScope())
{
    var db = scope.ServiceProvider.GetRequiredService<AppDb>();
    await KhoiTaoDuLieu.KhoiTaoAsync(db);
}

if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/loi");
    app.UseHsts();
}

app.UseHttpsRedirection();
app.UseStaticFiles();
app.UseRouting();
app.UseSession();
app.UseAuthentication();
app.UseAuthorization();

app.MapControllerRoute("default", "{controller=TrangChu}/{action=Index}/{id?}");
app.Run();
