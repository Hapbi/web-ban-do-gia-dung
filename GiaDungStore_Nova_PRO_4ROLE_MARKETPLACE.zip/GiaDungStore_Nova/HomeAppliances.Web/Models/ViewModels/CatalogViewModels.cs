namespace HomeAppliances.Web.Models.ViewModels;

public class CategoryLinkViewModel
{
    public string Slug { get; set; } = "";
    public string Name { get; set; } = "";
    public int ProductCount { get; set; }
}

public class ProductCardViewModel
{
    public int Id { get; set; }
    public string Slug { get; set; } = "";
    public string Name { get; set; } = "";
    public string Brand { get; set; } = "";
    public string CategorySlug { get; set; } = "";
    public string CategoryName { get; set; } = "";
    public decimal OriginalPrice { get; set; }
    public decimal? DiscountPrice { get; set; }
    public int StockQuantity { get; set; }
    public string? ImageUrl { get; set; }
    public DateTime CreatedUtc { get; set; }
    public int SoldCount { get; set; }

    public decimal CurrentPrice => DiscountPrice is > 0 && DiscountPrice < OriginalPrice ? DiscountPrice.Value : OriginalPrice;
    public bool HasDiscount => CurrentPrice < OriginalPrice;
    public int DiscountPercent => HasDiscount ? (int)Math.Round((1 - CurrentPrice / OriginalPrice) * 100) : 0;
    public bool InStock => StockQuantity > 0;
    public bool LowStock => StockQuantity is > 0 and <= 5;
}

public class ProductDetailViewModel : ProductCardViewModel
{
    public string Description { get; set; } = "";
    public List<KeyValuePair<string, string>> Specifications { get; set; } = new();
    public List<string> Images { get; set; } = new();
    public List<ProductCardViewModel> Related { get; set; } = new();
}

public class HomePageViewModel
{
    public List<CategoryLinkViewModel> Categories { get; set; } = new();
    public List<ProductCardViewModel> Featured { get; set; } = new();
    public List<ProductCardViewModel> NewArrivals { get; set; } = new();
    public List<ProductCardViewModel> BestSellers { get; set; } = new();
    public List<BannerViewModel> Banners { get; set; } = new();
}

public class BannerViewModel
{
    public string Title { get; set; } = "";
    public string? Subtitle { get; set; }
    public string ImageUrl { get; set; } = "";
    public string? LinkUrl { get; set; }
}

/// <summary>Query-string parameters for the product list. Bound from GET.</summary>
public class ProductListQuery
{
    public string? Q { get; set; }
    public string? Category { get; set; }
    public string? Brand { get; set; }
    public decimal? MinPrice { get; set; }
    public decimal? MaxPrice { get; set; }
    public bool InStockOnly { get; set; }
    /// <summary>newest | price-asc | price-desc | popular</summary>
    public string Sort { get; set; } = "newest";
    public int Page { get; set; } = 1;
}

public class PagerViewModel
{
    public int Page { get; set; }
    public int TotalPages { get; set; }
    public int TotalItems { get; set; }
    public int PageSize { get; set; }
    public bool HasPrevious => Page > 1;
    public bool HasNext => Page < TotalPages;
}

public class ProductListViewModel
{
    public ProductListQuery Query { get; set; } = new();
    public string Heading { get; set; } = "Tất cả sản phẩm";
    public List<ProductCardViewModel> Products { get; set; } = new();
    public List<CategoryLinkViewModel> Categories { get; set; } = new();
    public List<string> Brands { get; set; } = new();
    public PagerViewModel Pager { get; set; } = new();
}
