using Microsoft.EntityFrameworkCore;
using HomeAppliances.Web.Data;
using HomeAppliances.Web.Domain;

namespace HomeAppliances.Web.Services;

public record DailySales(DateTime Date, int Orders, decimal Revenue);
public record TopProduct(string Name, int Quantity, decimal Revenue);

public class SalesReport
{
    public DateTime From { get; set; }
    public DateTime To { get; set; }
    public int OrdersCreated { get; set; }
    public int PaidOrders { get; set; }
    public decimal Revenue { get; set; }
    public decimal PlatformFees { get; set; }
    public decimal AverageOrderValue => PaidOrders == 0 ? 0 : Math.Round(Revenue / PaidOrders);
    public List<DailySales> Daily { get; set; } = new();
    public List<TopProduct> TopProducts { get; set; } = new();
    public Dictionary<OrderStatus, int> ByStatus { get; set; } = new();
}

public class DashboardStats
{
    public int TotalOrders { get; set; }
    public decimal VerifiedRevenue { get; set; }
    public int PendingPayments { get; set; }
    public int ToProcess { get; set; }
    public int LowStockProducts { get; set; }
    public int UnreadMessages { get; set; }
    public List<Models.ViewModels.OrderListItem> RecentOrders { get; set; } = new();
}

public interface IReportService
{
    Task<SalesReport> GetSalesReportAsync(DateTime from, DateTime to);
    Task<DashboardStats> GetDashboardAsync();
}

/// <summary>Revenue only ever counts orders whose payment was verified (Paid..Delivered), never unpaid, cancelled or rejected ones.</summary>
public class ReportService : IReportService
{
    private static readonly OrderStatus[] PaidStatuses = { OrderStatus.Paid, OrderStatus.Processing, OrderStatus.Shipped, OrderStatus.Delivered };
    private readonly ApplicationDbContext _db;

    public ReportService(ApplicationDbContext db) => _db = db;

    public async Task<SalesReport> GetSalesReportAsync(DateTime from, DateTime to)
    {
        var start = from.Date; var end = to.Date.AddDays(1);
        var report = new SalesReport { From = start, To = to.Date };

        report.OrdersCreated = await _db.Orders.CountAsync(o => o.CreatedUtc >= start && o.CreatedUtc < end);
        var statusRows = await _db.Orders.AsNoTracking().Where(o => o.CreatedUtc >= start && o.CreatedUtc < end).Select(o => o.Status).ToListAsync();
        report.ByStatus = statusRows.GroupBy(s => s).ToDictionary(g => g.Key, g => g.Count());

        var paid = await _db.Orders.AsNoTracking()
            .Where(o => o.PaidUtc != null && o.PaidUtc >= start && o.PaidUtc < end && PaidStatuses.Contains(o.Status))
            .Select(o => new { PaidUtc = o.PaidUtc!.Value, o.Total }).ToListAsync();
        report.PaidOrders = paid.Count;
        report.Revenue = paid.Sum(p => p.Total);
        report.PlatformFees = await _db.OrderItems.AsNoTracking()
            .Where(i => PaidStatuses.Contains(i.Order!.Status) && i.Order.PaidUtc >= start && i.Order.PaidUtc < end)
            .SumAsync(i => (decimal?)i.PlatformFee) ?? 0;
        report.Daily = paid.GroupBy(p => p.PaidUtc.Date).OrderBy(g => g.Key).Select(g => new DailySales(g.Key, g.Count(), g.Sum(x => x.Total))).ToList();

        var lines = await _db.OrderItems.AsNoTracking()
            .Where(i => PaidStatuses.Contains(i.Order!.Status) && i.Order.PaidUtc >= start && i.Order.PaidUtc < end)
            .Select(i => new { i.ProductName, i.Quantity, i.LineTotal }).ToListAsync();
        report.TopProducts = lines.GroupBy(l => l.ProductName).Select(g => new TopProduct(g.Key, g.Sum(x => x.Quantity), g.Sum(x => x.LineTotal)))
            .OrderByDescending(t => t.Quantity).Take(10).ToList();
        return report;
    }

    public async Task<DashboardStats> GetDashboardAsync() => new()
    {
        TotalOrders = await _db.Orders.CountAsync(),
        VerifiedRevenue = await _db.Orders.Where(o => PaidStatuses.Contains(o.Status)).SumAsync(o => o.Total),
        PendingPayments = await _db.Orders.CountAsync(o => o.Status == OrderStatus.PendingVerification),
        ToProcess = await _db.Orders.CountAsync(o => o.Status == OrderStatus.Paid || o.Status == OrderStatus.Processing),
        LowStockProducts = await _db.Products.CountAsync(p => p.IsActive && p.StockQuantity <= ProductAdminService.LowStockThreshold),
        UnreadMessages = await _db.ContactMessages.CountAsync(m => !m.IsRead),
        RecentOrders = await _db.Orders.AsNoTracking().OrderByDescending(o => o.CreatedUtc).Take(8)
            .Select(o => new Models.ViewModels.OrderListItem { Id = o.Id, OrderNumber = o.OrderNumber, ReceiverName = o.ReceiverName, Phone = o.Phone, Total = o.Total, Status = o.Status, CreatedUtc = o.CreatedUtc, ItemCount = o.Items.Count }).ToListAsync()
    };
}
