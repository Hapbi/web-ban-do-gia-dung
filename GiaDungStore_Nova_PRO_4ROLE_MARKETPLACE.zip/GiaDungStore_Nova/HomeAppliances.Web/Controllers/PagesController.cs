using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.RateLimiting;
using HomeAppliances.Web.Data;
using HomeAppliances.Web.Models.Entities;
using HomeAppliances.Web.Models.ViewModels;

namespace HomeAppliances.Web.Controllers;

/// <summary>Static information pages: about, contact, FAQ and policies.</summary>
public class PagesController : Controller
{
    private readonly ApplicationDbContext _db;

    public PagesController(ApplicationDbContext db) => _db = db;

    [HttpGet("gioi-thieu")] public IActionResult About() => View();
    [HttpGet("hoi-dap")] public IActionResult Faq() => View();
    [HttpGet("chinh-sach-bao-mat")] public IActionResult Privacy() => View();
    [HttpGet("dieu-khoan-su-dung")] public IActionResult Terms() => View();
    [HttpGet("van-chuyen-doi-tra")] public IActionResult ShippingReturns() => View();

    [HttpGet("lien-he")]
    public IActionResult Contact() => View(new ContactFormViewModel());

    [HttpPost("lien-he")]
    [EnableRateLimiting("auth")]
    public async Task<IActionResult> Contact(ContactFormViewModel model)
    {
        if (!ModelState.IsValid) return View(model);

        _db.ContactMessages.Add(new ContactMessage
        {
            FullName = model.FullName.Trim(), Email = model.Email.Trim(), Phone = model.Phone?.Trim(), Message = model.Message.Trim()
        });
        await _db.SaveChangesAsync();
        TempData["Success"] = "Cảm ơn bạn. Chúng tôi đã nhận được tin nhắn và sẽ phản hồi sớm.";
        return RedirectToAction(nameof(Contact));
    }
}
