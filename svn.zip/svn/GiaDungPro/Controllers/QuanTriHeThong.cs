using System.Text;
using CuaHangGiaDungPro.Helpers;
using CuaHangGiaDungPro.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace CuaHangGiaDungPro.Controllers;

public partial class QuanTriController
{
    [Route("quan-tri/thong-ke")]
    public async Task<IActionResult> ThongKe(DateTime? tuNgay, DateTime? denNgay)
    {
        if (!QuyenHelper.CoQuyen(User, "baocao")) return Forbid();
        var den = (denNgay ?? DateTime.Today).Date;
        var tu  = (tuNgay ?? den.AddDays(-29)).Date;
        if (tu > den) (tu, den) = (den, tu);
        ViewBag.TuNgay = tu; ViewBag.DenNgay = den;

        var donHangs = await _db.DonHangs.Include(x => x.ChiTiet).ToListAsync();
        var trongKhoang = donHangs.Where(x => x.NgayTao.Date >= tu && x.NgayTao.Date <= den).ToList();
        var daThanhToan = trongKhoang.Where(x =>
            x.ThanhToan == ThanhToan.DaThanhToan ||
            (x.TrangThai == TrangThaiDon.HoanThanh && x.PhuongThucThanhToan == PhuongThucThanhToan.COD)).ToList();

        ViewBag.DoanhThu = daThanhToan.Sum(x => x.TongTien);
        ViewBag.SoDon = daThanhToan.Count;
        ViewBag.DonHuy = trongKhoang.Count(x => x.TrangThai == TrangThaiDon.DaHuy);

        var bieuDo = new List<(string Ngay, decimal Doanh)>();
        for (var d = den.AddDays(-6); d <= den; d = d.AddDays(1))
        {
            var cuaNgay = daThanhToan.Where(x => x.NgayTao.Date == d).Sum(x => x.TongTien);
            bieuDo.Add((d.ToString("dd/MM"), cuaNgay));
        }
        ViewBag.BieuDo = bieuDo;
        ViewBag.BieuDoMax = Math.Max(1, bieuDo.Any() ? bieuDo.Max(x => x.Doanh) : 0);

        ViewBag.TopSanPham = daThanhToan.SelectMany(x => x.ChiTiet)
            .GroupBy(x => x.SanPhamId)
            .Select(g => new { Ten = g.First().TenSanPham, SoLuong = g.Sum(x => x.SoLuong), DoanhThu = g.Sum(x => x.ThanhTien) })
            .OrderByDescending(x => x.SoLuong).Take(10).ToList();

        var sps = await _db.SanPhams.ToListAsync();
        ViewBag.ConHang = sps.Count(x => x.TonKho > 5);
        ViewBag.SapHet = sps.Count(x => x.TonKho > 0 && x.TonKho <= 5);
        ViewBag.HetHang = sps.Count(x => x.TonKho <= 0);
        ViewBag.SanPhamSapHet = sps.Where(x => x.TonKho <= 5).OrderBy(x => x.TonKho).Take(10).ToList();

        return View();
    }

    [Route("quan-tri/thong-ke/xuat-csv")]
    public async Task<IActionResult> XuatCsv(DateTime? tuNgay, DateTime? denNgay)
    {
        if (!QuyenHelper.CoQuyen(User, "baocao")) return Forbid();
        var den = (denNgay ?? DateTime.Today).Date;
        var tu  = (tuNgay ?? den.AddDays(-29)).Date;

        var donHangs = await _db.DonHangs
            .Where(x => x.NgayTao.Date >= tu && x.NgayTao.Date <= den
                && (x.ThanhToan == ThanhToan.DaThanhToan
                    || (x.TrangThai == TrangThaiDon.HoanThanh && x.PhuongThucThanhToan == PhuongThucThanhToan.COD)))
            .ToListAsync();

        var sb = new StringBuilder("Ngay,SoDon,DoanhThu\n");
        for (var d = tu; d <= den; d = d.AddDays(1))
        {
            var cuaNgay = donHangs.Where(x => x.NgayTao.Date == d).ToList();
            sb.Append($"{d:dd/MM/yyyy},{cuaNgay.Count},{(long)cuaNgay.Sum(x => x.TongTien)}\n");
        }
        sb.Append($"TONG,{donHangs.Count},{(long)donHangs.Sum(x => x.TongTien)}\n");
        return File(new UTF8Encoding(true).GetBytes(sb.ToString()), "text/csv",
            $"doanh-thu_{tu:yyyyMMdd}_{den:yyyyMMdd}.csv");
    }

    [Authorize(Roles = "Admin"), Route("quan-tri/cau-hinh")]
    public async Task<IActionResult> CauHinh()
    {
        var ch = await _db.CauHinhs.FirstOrDefaultAsync() ?? new CauHinh();
        return View(ch);
    }

    [HttpPost, Authorize(Roles = "Admin"), Route("quan-tri/cau-hinh")]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> CauHinh(CauHinh input)
    {
        var ch = await _db.CauHinhs.FirstOrDefaultAsync();
        if (ch == null) { ch = new CauHinh(); _db.CauHinhs.Add(ch); }
        ch.TenShop     = input.TenShop?.Trim() ?? "Gia Dụng Pro";
        ch.Slogan      = input.Slogan?.Trim() ?? "";
        ch.DiaChi      = input.DiaChi?.Trim() ?? "";
        ch.DienThoai   = input.DienThoai?.Trim() ?? "";
        ch.Email       = input.Email?.Trim() ?? "";
        ch.GioMoCua    = input.GioMoCua?.Trim() ?? "";
        ch.NganHang    = input.NganHang?.Trim() ?? "";
        ch.SoTaiKhoan  = input.SoTaiKhoan?.Trim() ?? "";
        ch.ChuTaiKhoan = input.ChuTaiKhoan?.Trim() ?? "";
        ch.MaQr        = input.MaQr?.Trim() ?? "";
        await _db.SaveChangesAsync();
        TempData["ThanhCong"] = "Đã lưu cấu hình";
        return RedirectToAction(nameof(CauHinh));
    }

    [Authorize(Roles = "Admin"), Route("quan-tri/nhat-ky")]
    public async Task<IActionResult> NhatKy(string? q)
    {
        var query = _db.NhatKys.AsQueryable();
        if (!string.IsNullOrWhiteSpace(q))
            query = query.Where(x => x.NguoiDung.Contains(q) || x.HanhDong.Contains(q) || x.ChiTiet.Contains(q));
        ViewBag.Q = q;
        return View(await query.OrderByDescending(x => x.ThoiGian).Take(500).ToListAsync());
    }
}
