using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using HomeAppliances.Web.Infrastructure;
using HomeAppliances.Web.Services;

namespace HomeAppliances.Web.Areas.Employee.Controllers;

[Area("Employee"), Authorize(Policy = AppPolicies.StaffOnly)]
public class ReportsController : Controller
{
    private readonly IReportService _reports;
    public ReportsController(IReportService reports)=>_reports=reports;
    public async Task<IActionResult> Index(DateTime? from, DateTime? to)
    {
        var end=(to??DateTime.Today).Date; var start=(from??end.AddDays(-29)).Date;
        if(start>end)(start,end)=(end,start);
        return View(await _reports.GetSalesReportAsync(start,end));
    }
}
