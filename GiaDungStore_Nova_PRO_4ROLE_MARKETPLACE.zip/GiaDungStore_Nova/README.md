# GIA DỤNG NOVA | Website quản lý và bán đồ gia dụng

Dự án mới, xây dựng trên ASP.NET Core MVC + Entity Framework Core + SQL Server. Cấu trúc backend được chia Controller / Service / Domain / Data / ViewModel; có ASP.NET Identity, phân quyền Admin/Employee/Customer, chống CSRF, giới hạn thử đăng nhập, nhật ký quản trị, kiểm tra upload ảnh và quản lý đơn hàng.

## Chạy trên Windows

### Điều kiện
- Windows 10/11
- .NET 8 SDK
- SQL Server (MSSQLSERVER) đang chạy
- Visual Studio 2022 (hoặc VS Code) nếu muốn sửa code

### Cách chạy nhanh
1. Giải nén toàn bộ thư mục.
2. Đảm bảo dịch vụ SQL Server đang chạy. Mặc định dự án dùng `Server=localhost` và Windows Authentication.
3. Nhấp đúp `run-windows.bat`.
4. Trình duyệt mở `http://localhost:5080`. Nếu không tự mở, tự nhập địa chỉ đó.

Ứng dụng tự tạo database `GiaDungStoreNova`, các bảng và dữ liệu sản phẩm mẫu lần đầu chạy. Nếu SQL Server của anh dùng tên instance khác, sửa `ConnectionStrings:DefaultConnection` trong `HomeAppliances.Web/appsettings.json`.

## Tài khoản ban đầu

- **Admin:** tên đăng nhập `admin`, mật khẩu `admin1234`
- **Nhân viên mẫu:** email/tên đăng nhập `staff@giadung.local`, mật khẩu `Staff1234`
- **Khách hàng mẫu:** email/tên đăng nhập `customer@giadung.local`, mật khẩu `Customer1234`

Đăng nhập Admin rồi vào **Quản trị → Người dùng** để tạo tài khoản nhân viên, đặt mật khẩu riêng, đổi vai trò hoặc khóa tài khoản. Khu quản trị có URL `/Admin`; nhân viên có khu làm việc riêng `/Employee`. Khách không thể tự đăng ký thành Admin.

**Lưu ý bảo mật:** mật khẩu Admin trên là thông tin khởi tạo theo yêu cầu để chạy local. Đổi mật khẩu ngay sau lần đăng nhập đầu tiên trước khi đưa website lên mạng. Không dùng cấu hình Development hay mật khẩu mẫu cho môi trường công khai.

## Có gì trong web
- Trang bán hàng responsive, tìm kiếm/lọc sản phẩm, danh mục, chi tiết sản phẩm, giỏ hàng, checkout, tài khoản khách hàng và theo dõi đơn.
- Trang Admin riêng: thống kê, sản phẩm, danh mục, banner, đơn hàng, người dùng/nhân viên, báo cáo, thiết lập website, nhật ký hoạt động.
- Khu Employee riêng cho xử lý đơn và sản phẩm theo quyền được cấp.
- Seed nhiều sản phẩm và 8 danh mục mẫu; sản phẩm có thể được sửa/thay ảnh trong quản trị.
- SQL Server là cơ sở dữ liệu thật; mật khẩu lưu dạng hash bởi ASP.NET Identity, không lưu dạng chữ thường.
- Các ảnh sản phẩm mẫu và nội dung minh họa cần được thay bằng ảnh, giá và thông tin kinh doanh thật trước khi public.

## Cấu trúc chính
- `HomeAppliances.Web/Controllers`: trang khách, đăng nhập, giỏ hàng, đơn hàng.
- `HomeAppliances.Web/Areas/Admin`: giao diện và nghiệp vụ quản trị.
- `HomeAppliances.Web/Areas/Employee`: khu vực nhân viên.
- `HomeAppliances.Web/Services`: nghiệp vụ sản phẩm, giỏ, đơn, báo cáo, lưu file, audit.
- `HomeAppliances.Web/Domain`: quy tắc nghiệp vụ và kiểm tra dữ liệu.
- `HomeAppliances.Web/Data`: EF Core DbContext và khởi tạo database/dữ liệu mẫu.
- `HomeAppliances.Tests`: unit/integration tests.
- `run-windows.bat`: khởi chạy local trên Windows.

## Xử lý lỗi thường gặp
- `dotnet` không nhận diện: cài .NET 8 SDK rồi mở lại CMD.
- Không kết nối SQL Server: mở SQL Server Configuration Manager/Services, chạy `SQL Server (MSSQLSERVER)`; kiểm tra connection string.
- Cổng 5080 đang bận: đổi cổng trong `Properties/launchSettings.json`.
- Lần chạy đầu cần mạng để NuGet tải các package nếu máy chưa có cache.


## Bản nâng cấp Marketplace 4 vai trò

Bản Nova nâng cấp có 4 trải nghiệm:
- **Khách vãng lai:** xem danh mục, tìm kiếm, chi tiết sản phẩm; không được thêm giỏ/mua/đăng bán nếu chưa đăng nhập.
- **Khách hàng:** mua hàng, giỏ hàng, lịch sử đơn, tài khoản và **Kênh bán hàng** để đăng sản phẩm marketplace.
- **Staff:** khu vực `/Employee` để xử lý đơn, sản phẩm/tồn kho, báo cáo và duyệt sản phẩm do khách đăng.
- **Admin:** khu vực `/Admin` với quyền cao nhất: quản lý người dùng/staff, danh mục, website, sản phẩm, đơn, báo cáo và nhật ký.

### Marketplace
- Bài bán của khách mặc định **chờ duyệt**.
- Staff/Admin duyệt trước khi sản phẩm xuất hiện công khai.
- Phí nền tảng mặc định **7%** trên giá trị sản phẩm marketplace trong đơn đã thanh toán; phí được lưu ngay tại `OrderItem.PlatformFee` để lịch sử giao dịch không bị thay đổi khi cấu hình sau này đổi.
- Người bán không thể tự mua sản phẩm do chính mình đăng.

### Tài khoản demo phát triển
- Admin username: `admin`
- Admin password: `17092007`
- Staff: `staff@giadung.local` / `Staff1234`
- Customer: `customer@giadung.local` / `Customer1234`

**Lưu ý:** thông tin trên chỉ dành cho môi trường demo/development. Khi triển khai thật, đổi toàn bộ mật khẩu seed và đưa secret ra User Secrets / biến môi trường; không dùng mật khẩu demo ngoài môi trường kiểm thử.

### Hỗ trợ
Zalo/Hotline: **0855081828** — nút Zalo nổi được hiển thị trên storefront.
