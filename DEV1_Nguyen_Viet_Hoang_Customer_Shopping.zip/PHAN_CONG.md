PHAN CODE THEO THANH VIEN
Nguyễn Việt Hoàng – DEV 1: Customer / Shopping

Phạm vi phụ trách:
Trang chủ, sản phẩm, giỏ hàng, checkout, đơn hàng khách, tài khoản khách, wishlist/blog/contact và ảnh sản phẩm.

Lưu ý:
- Đây là gói phân chia file từ project gốc, không phải 4 website độc lập.
- Giữ nguyên đường dẫn thư mục BTVH_Website/NovaShop/... khi chép/ghép code.
- Khi tích hợp, chỉ đưa các file trong gói này vào project chung; không ghi đè file của thành viên khác nếu chưa thống nhất.
- Các file dùng chung/ảnh có thể cần được thành viên phụ trách hoặc Leader cung cấp khi chạy project hoàn chỉnh.
- Leader nên nhận code qua Git branch/Pull Request, build và test sau mỗi lần merge.
