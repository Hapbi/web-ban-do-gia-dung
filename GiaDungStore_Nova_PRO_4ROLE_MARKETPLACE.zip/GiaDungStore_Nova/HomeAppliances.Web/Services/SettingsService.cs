using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Caching.Memory;
using HomeAppliances.Web.Data;
using HomeAppliances.Web.Models.Entities;
using HomeAppliances.Web.Options;

namespace HomeAppliances.Web.Services;

public interface ISettingsService
{
    Task<WebsiteSettings> GetWebsiteAsync();
    Task SaveWebsiteAsync(WebsiteSettings updated);
    Task<BankTransferSettings> GetBankAsync();
    Task SaveBankAsync(BankTransferSettings updated);
}

/// <summary>Reads/writes the single-row settings tables, cached for 5 minutes and invalidated on save.</summary>
public class SettingsService : ISettingsService
{
    private const string SiteKey = "settings:site";
    private const string BankKey = "settings:bank";
    private readonly ApplicationDbContext _db;
    private readonly IMemoryCache _cache;

    public SettingsService(ApplicationDbContext db, IMemoryCache cache) { _db = db; _cache = cache; }

    public static WebsiteSettings DefaultWebsite()
{
    var d = new SiteInfoOptions
    {
        Name = "Gia Dụng Nova",
        Tagline = "Tiện nghi cho mọi nhà",
        Introduction = "Mua bán đồ gia dụng và marketplace cộng đồng, minh bạch phí nền tảng 7%.",
        Address = "Hà Nội, Việt Nam",
        Phone = "0855081828",
        Email = "hotro@giadungnova.local",
        OpeningHours = "8:00 - 21:00 hằng ngày",
        ZaloUrl = "https://zalo.me/0855081828"
    };
    return new WebsiteSettings { SiteName=d.Name, Tagline=d.Tagline, Introduction=d.Introduction, Address=d.Address, Phone=d.Phone, Email=d.Email, OpeningHours=d.OpeningHours, ZaloUrl=d.ZaloUrl };
}

    public async Task<WebsiteSettings> GetWebsiteAsync() =>
        (await _cache.GetOrCreateAsync(SiteKey, async e =>
        {
            e.AbsoluteExpirationRelativeToNow = TimeSpan.FromMinutes(5);
            return await _db.WebsiteSettings.AsNoTracking().FirstOrDefaultAsync() ?? DefaultWebsite();
        }))!;

    public async Task<BankTransferSettings> GetBankAsync() =>
        (await _cache.GetOrCreateAsync(BankKey, async e =>
        {
            e.AbsoluteExpirationRelativeToNow = TimeSpan.FromMinutes(5);
            return await _db.BankTransferSettings.AsNoTracking().FirstOrDefaultAsync() ?? new BankTransferSettings();
        }))!;

    public async Task SaveWebsiteAsync(WebsiteSettings u)
    {
        var s = await _db.WebsiteSettings.FirstOrDefaultAsync();
        if (s == null) { s = new WebsiteSettings(); _db.WebsiteSettings.Add(s); }
        s.SiteName = u.SiteName; s.Tagline = u.Tagline; s.Introduction = u.Introduction; s.Address = u.Address;
        s.Phone = u.Phone; s.Email = u.Email; s.OpeningHours = u.OpeningHours;
        s.FacebookUrl = u.FacebookUrl; s.YoutubeUrl = u.YoutubeUrl; s.ZaloUrl = u.ZaloUrl; s.TiktokUrl = u.TiktokUrl;
        s.ShippingFee = u.ShippingFee; s.FreeShippingThreshold = u.FreeShippingThreshold; s.UnpaidOrderExpiryHours = u.UnpaidOrderExpiryHours;
        s.UpdatedUtc = DateTime.UtcNow;
        await _db.SaveChangesAsync();
        _cache.Remove(SiteKey);
    }

    public async Task SaveBankAsync(BankTransferSettings u)
    {
        var s = await _db.BankTransferSettings.FirstOrDefaultAsync();
        if (s == null) { s = new BankTransferSettings(); _db.BankTransferSettings.Add(s); }
        s.BankName = u.BankName; s.AccountHolder = u.AccountHolder; s.AccountNumber = u.AccountNumber; s.Branch = u.Branch;
        s.Instructions = u.Instructions; s.ReferenceFormat = string.IsNullOrWhiteSpace(u.ReferenceFormat) ? "{OrderNumber}" : u.ReferenceFormat;
        s.QrImagePath = u.QrImagePath;
        s.UpdatedUtc = DateTime.UtcNow;
        await _db.SaveChangesAsync();
        _cache.Remove(BankKey);
    }

    public static SiteInfoOptions ToSiteInfo(WebsiteSettings s) => new()
    {
        Name = s.SiteName, Tagline = s.Tagline, Introduction = s.Introduction, Address = s.Address, Phone = s.Phone,
        Email = s.Email, OpeningHours = s.OpeningHours, FacebookUrl = s.FacebookUrl ?? "", YoutubeUrl = s.YoutubeUrl ?? "",
        ZaloUrl = s.ZaloUrl ?? "", TiktokUrl = s.TiktokUrl ?? ""
    };
}
