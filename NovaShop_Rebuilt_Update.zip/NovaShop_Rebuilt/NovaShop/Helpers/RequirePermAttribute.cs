using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;

namespace NovaShop.Helpers;

[AttributeUsage(AttributeTargets.Method | AttributeTargets.Class)]
public class RequirePermAttribute(string perm) : Attribute, IAuthorizationFilter
{
    public void OnAuthorization(AuthorizationFilterContext ctx)
    {
        var u = ctx.HttpContext.User;
        if (u.Identity?.IsAuthenticated != true) { ctx.Result = new ChallengeResult(); return; }
        if (!u.Can(perm)) ctx.Result = new ForbidResult();
    }
}
