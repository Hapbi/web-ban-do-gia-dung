using Microsoft.EntityFrameworkCore;
using NovaShop.Data;
using NovaShop.Models;

namespace NovaShop.Services;

public class ReportService
{
    private readonly AppDbContext _db;
    public ReportService(AppDbContext db) => _db = db;

    public async Task<DashboardVM> GetDashboardAsync()
    {
        var now = DateTime.Now;
        var today = now.Date;
        var yesterday = today.AddDays(-1);
        var monthStart = new DateTime(now.Year, now.Month, 1);

        var orders = await _db.Orders.Include(o => o.Items).ToListAsync();
        var paid = orders.Where(o => o.Payment == PaymentStatus.Paid).ToList();

        var vm = new DashboardVM
        {
            RevenueToday = paid.Where(o => o.CreatedAt >= today).Sum(o => o.Total),
            RevenueYesterday = paid.Where(o => o.CreatedAt >= yesterday && o.CreatedAt < today).Sum(o => o.Total),
            RevenueMonth = paid.Where(o => o.CreatedAt >= monthStart).Sum(o => o.Total),
            RevenueTotal = paid.Sum(o => o.Total),
            PaidOrders = paid.Count,
            PendingOrders = orders.Count(o => o.Status == OrderStatus.Pending),
            TotalOrders = orders.Count,
            TotalUsers = await _db.Users.CountAsync(u => u.Role == "Customer"),
            TotalProducts = await _db.Products.CountAsync(),
            RecentOrders = orders.OrderByDescending(o => o.CreatedAt).Take(10).ToList(),
            StatusCounts = orders.GroupBy(o => o.Status).ToDictionary(g => g.Key, g => g.Count())
        };

        // Chart 7 ngày
        for (int i = 6; i >= 0; i--)
        {
            var day = today.AddDays(-i);
            var next = day.AddDays(1);
            var dayOrders = paid.Where(o => o.CreatedAt >= day && o.CreatedAt < next).ToList();
            vm.Chart7Days.Add((day.ToString("dd/MM"), dayOrders.Sum(o => o.Total), dayOrders.Count));
        }
        vm.ChartMax = Math.Max(vm.Chart7Days.Max(c => c.Amount), 1);

        // Chart 12 tháng
        for (int i = 11; i >= 0; i--)
        {
            var m = now.AddMonths(-i);
            var start = new DateTime(m.Year, m.Month, 1);
            var end = start.AddMonths(1);
            var mOrders = paid.Where(o => o.CreatedAt >= start && o.CreatedAt < end).ToList();
            vm.Chart12Months.Add((start.ToString("MM/yy"), mOrders.Sum(o => o.Total), mOrders.Count));
        }

        // Tồn kho
        var products = await _db.Products.ToListAsync();
        vm.InStock = products.Count(p => p.Stock > 5);
        vm.LowStock = products.Count(p => p.Stock > 0 && p.Stock <= 5);
        vm.OutStock = products.Count(p => p.Stock <= 0);
        vm.LowStockProducts = products.Where(p => p.Stock > 0 && p.Stock <= 5).OrderBy(p => p.Stock).Take(5).ToList();

        // Top products
        vm.TopProducts = paid.SelectMany(o => o.Items)
            .GroupBy(i => i.ProductId)
            .Select(g => new { ProductId = g.Key, Qty = g.Sum(i => i.Quantity), Revenue = g.Sum(i => i.UnitPrice * i.Quantity) })
            .OrderByDescending(x => x.Revenue).Take(5)
            .Select(x => (products.FirstOrDefault(p => p.Id == x.ProductId) ?? new Product { Name = "N/A" }, x.Qty, x.Revenue))
            .ToList();

        // Top customers
        vm.TopCustomers = paid.GroupBy(o => o.UserId)
            .Select(g => new { UserId = g.Key, Count = g.Count(), Spent = g.Sum(o => o.Total) })
            .OrderByDescending(x => x.Spent).Take(5)
            .Select(x => (_db.Users.FirstOrDefault(u => u.Id == x.UserId) ?? new User { FullName = "N/A" }, x.Count, x.Spent))
            .ToList();

        vm.RecentReviews = await _db.Reviews.Include(r => r.User).Include(r => r.Product)
            .OrderByDescending(r => r.CreatedAt).Take(5).ToListAsync();

        return vm;
    }
}


####################################################################################################
