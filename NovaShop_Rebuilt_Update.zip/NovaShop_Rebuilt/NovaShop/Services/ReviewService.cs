using Microsoft.EntityFrameworkCore;
using NovaShop.Data;
using NovaShop.Models;

namespace NovaShop.Services;

public class ReviewService
{
    private readonly AppDbContext _db;
    private readonly AuthService _auth;
    public ReviewService(AppDbContext db, AuthService auth) { _db = db; _auth = auth; }

    public async Task<(bool ok, string msg)> CreateAsync(ReviewVM vm)
    {
        var uid = _auth.GetCurrentId();
        if (uid == null) return (false, "Vui lòng đăng nhập");

        var hasPurchased = await _db.Orders
            .Where(o => o.UserId == uid.Value && (o.Status == OrderStatus.Delivered || o.Status == OrderStatus.Confirmed))
            .SelectMany(o => o.Items).AnyAsync(i => i.ProductId == vm.ProductId);

        if (await _db.Reviews.AnyAsync(r => r.ProductId == vm.ProductId && r.UserId == uid.Value))
            return (false, "Bạn đã đánh giá sản phẩm này");

        _db.Reviews.Add(new Review
        {
            ProductId = vm.ProductId, UserId = uid.Value,
            Rating = Math.Clamp(vm.Rating, 1, 5), Title = vm.Title.Trim(), Content = vm.Content.Trim(),
            IsVerifiedPurchase = hasPurchased, Status = ReviewStatus.Approved
        });
        await _db.SaveChangesAsync();
        return (true, "Cảm ơn bạn đã đánh giá!");
    }
}
