# BTVH — Website bán đồ điện gia dụng

Dự án ASP.NET Core MVC + Entity Framework Core SQLite, được dựng lại từ mã nguồn anh cung cấp.

## Chạy trên Windows
Cách nhanh: cài .NET 8 SDK rồi nhấp đúp `Chay_BTVH.bat`.

Cách thủ công:
1. Cài .NET 8 SDK.
2. Giải nén thư mục dự án.
3. Mở terminal trong thư mục `BTVH_Website/NovaShop` (nơi có `NovaShop.csproj`).
4. Chạy `dotnet restore` rồi `dotnet run`.
5. Mở http://localhost:5080

Lần chạy đầu tiên sẽ tạo `btvh.db` và dữ liệu demo.

## Tài khoản demo
- Admin: `admin@nova.vn` / `admin123`
- Staff: `staff@nova.vn` / `staff123`
- Customer: `customer@nova.vn` / `customer123`

Đổi mật khẩu demo trước khi đưa website lên Internet. Mật khẩu tài khoản mới được băm bằng PBKDF2; tài khoản demo cũ được nâng cấp hash sau lần đăng nhập hợp lệ đầu tiên. Quyền/khóa tài khoản được làm mới khi phiên được kiểm tra lại. Dữ liệu demo và ảnh sản phẩm là dữ liệu minh họa; cần xác minh lại thông tin sản phẩm trước khi kinh doanh thật. Chức năng khôi phục mật khẩu hiện chưa tích hợp nhà cung cấp email và đã hiển thị thông báo đúng trạng thái demo.

## Ghi chú kiểm thử
Mã nguồn được tách thành cấu trúc dự án và bổ sung các tệp khởi chạy còn thiếu (`.csproj`, `Program.cs`, `appsettings.json`, launch settings). Các ảnh sản phẩm và ảnh bài viết demo được đóng gói sẵn trong thư mục web. Môi trường đóng gói không có .NET SDK, vì vậy chưa thể chạy `dotnet build` hoặc kiểm thử tích hợp tại đây. Hãy chạy `dotnet build` trên máy có .NET 8 SDK để xác nhận trước khi triển khai.

## Dữ liệu và hình ảnh sản phẩm
Catalog gồm 42 sản phẩm mẫu thuộc 10 danh mục. Mỗi sản phẩm có ảnh minh họa chính, ảnh góc nghiêng và ảnh chi tiết được lưu trực tiếp trong `wwwroot/images/products`, nên không phụ thuộc Unsplash hay dịch vụ ảnh bên ngoài. Ảnh trong bản demo là hình minh họa do dự án tạo ra, không phải ảnh chụp xác thực của từng mẫu máy; tên, giá, thông số, lượt bán và đánh giá cũng là dữ liệu giả lập để thử nghiệm giao diện và luồng đặt hàng. Hãy thay bằng ảnh và thông tin đã xác minh trước khi bán hàng thật.


## Chức năng quản trị và nhân viên

**Admin** (`/admin`) có dashboard doanh thu và trạng thái đơn; quản lý/thêm/sửa/ẩn sản phẩm; điều chỉnh tồn kho có nhật ký; danh mục, thương hiệu, thẻ sản phẩm, banner, mã giảm giá và bài viết; quản lý người dùng, khóa/mở khóa và phân quyền xác minh chuyển khoản; duyệt đánh giá; xử lý liên hệ; quản lý đơn hàng và vận đơn; xác minh/hoàn tiền chuyển khoản; duyệt Marketplace; cấu hình cửa hàng, phí giao hàng, ngưỡng miễn phí ship và thông tin chuyển khoản; báo cáo vận hành/doanh thu; xem nhật ký thao tác; xuất đơn hàng CSV để mở bằng Excel.

**Staff** (`/staff`) có bảng Kanban theo trạng thái, tìm kiếm đơn hàng, trang chi tiết khách/địa chỉ/lịch sử, cập nhật mã vận đơn, xử lý đơn theo luồng hợp lệ và xem tồn kho; xuất CSV đơn hàng và được ghi nhật ký mã vận đơn. Khách hàng có kênh Marketplace để đăng sản phẩm kèm ảnh tải lên, sửa/gửi lại tin bị từ chối và rút tin chờ duyệt. Đơn hàng gửi thông báo trong website khi trạng thái thay đổi; mã FREESHIP miễn phí vận chuyển theo điều kiện mã. Chỉ nhân viên được Admin cấp quyền `Có thể xác minh thanh toán` mới thấy và sử dụng hàng đợi chuyển khoản. Admin luôn có quyền xử lý thanh toán.

### Đường dẫn chính
- Admin: `/admin`
- Nhân viên: `/staff`
- Xác minh thanh toán: `/admin/thanh-toan` và `/staff/thanh-toan`
- Marketplace người bán: `/kenh-ban-hang`; Admin duyệt Marketplace: `/admin/marketplace`
- Quản lý thẻ sản phẩm: `/admin/the-san-pham`
- Báo cáo: `/admin/bao-cao/van-hanh`, `/admin/bao-cao/doanh-thu`
- Cấu hình cửa hàng/ngân hàng: `/admin/cau-hinh`
- Nhật ký thao tác: `/admin/nhat-ky`

Các tài khoản và dữ liệu là demo. Tài khoản nhân viên mẫu được cấp quyền xác minh thanh toán để có thể thử ngay trên cơ sở dữ liệu mới. Khi cơ sở dữ liệu đã tồn tại, quyền nhân viên được quản lý từ trang **Người dùng & quyền**. Cấu hình ngân hàng mẫu được để trống số tài khoản/chủ tài khoản nhằm tránh vô tình hướng khách chuyển tiền đến thông tin giả.
