using NovaShop.Data;
using NovaShop.Models;

namespace NovaShop.Services;

public class AuditService
{
    private readonly AppDbContext _db;
    private readonly IHttpContextAccessor _http;
    public AuditService(AppDbContext db, IHttpContextAccessor http) { _db = db; _http = http; }

    public async Task LogAsync(string userEmail, string action, string entity, string entityId, string details = "")
    {
        var ip = _http.HttpContext?.Connection.RemoteIpAddress?.ToString() ?? "";
        _db.AuditLogs.Add(new AuditLog
        {
            UserEmail = userEmail ?? "system",
            Action = action, Entity = entity, EntityId = entityId, Details = details, IpAddress = ip
        });
        await _db.SaveChangesAsync();
    }
}
