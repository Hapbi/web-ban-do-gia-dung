using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.RateLimiting;
using Microsoft.EntityFrameworkCore;
using HomeAppliances.Web.Data;
using HomeAppliances.Web.Domain;
using HomeAppliances.Web.Infrastructure;
using HomeAppliances.Web.Models.Entities;
using HomeAppliances.Web.Models.ViewModels;
using HomeAppliances.Web.Services;

namespace HomeAppliances.Web.Controllers;

/// <summary>Customer order history, payment instructions + proof upload, cancellation, and public order tracking.</summary>
[Authorize]
public class OrdersController : Controller
{
    private readonly IOrderService _orders;
    private readonly ISettingsService _settings;
    private readonly IFileStorage _files;
    private readonly IAuthorizationService _auth;
    private readonly ApplicationDbContext _db;

    public OrdersController(IOrderService orders, ISettingsService settings, IFileStorage files, IAuthorizationService auth, ApplicationDbContext db)
    { _orders = orders; _settings = settings; _files = files; _auth = auth; _db = db; }

    private string Uid => User.GetUserId()!;

    [HttpGet("don-hang")]
    public async Task<IActionResult> Index(int page = 1) => View(await _orders.GetCustomerOrdersAsync(Uid, page));

    [HttpGet("don-hang/{orderNumber}")]
    public async Task<IActionResult> Details(string orderNumber)
    {
        var order = await _orders.GetCustomerOrderAsync(Uid, orderNumber);   // null for orders owned by anyone else
        if (order == null) return NotFound();

        var bank = await _settings.GetBankAsync();
        return View(new OrderDetailViewModel
        {
            Order = order, Bank = bank, Actor = ActorRole.Customer,
            TransferReference = OrderNumberGenerator.BuildTransferReference(bank.ReferenceFormat, order.OrderNumber),
            CanCustomerCancel = OrderStateMachine.CanTransition(order.Status, OrderStatus.Cancelled, ActorRole.Customer),
            CanUploadProof = OrderStateMachine.CanUploadProof(order.Status),
            LatestProof = order.Proofs.OrderByDescending(p => p.UploadedUtc).FirstOrDefault()
        });
    }

    [HttpPost("don-hang/{orderNumber}/huy")]
    public async Task<IActionResult> Cancel(string orderNumber, string? reason)
    {
        var id = await _db.Orders.AsNoTracking().Where(o => o.OrderNumber == orderNumber && o.UserId == Uid).Select(o => (int?)o.Id).FirstOrDefaultAsync();
        if (id == null) return NotFound();
        var r = await _orders.CancelAsync(id.Value, ActorRole.Customer, Uid, User.GetEmail(), reason, mustOwnUserId: Uid);
        if (r.Succeeded) TempData["Success"] = "Đã hủy đơn hàng."; else TempData["Error"] = r.Error;
        return RedirectToAction(nameof(Details), new { orderNumber });
    }

    [HttpPost("don-hang/{orderNumber}/bien-lai")]
    [RequestSizeLimit(7 * 1024 * 1024)]
    public async Task<IActionResult> UploadProof(string orderNumber, IFormFile? proof)
    {
        if (proof == null || proof.Length == 0) { TempData["Error"] = "Vui lòng chọn ảnh biên lai."; return RedirectToAction(nameof(Details), new { orderNumber }); }
        var r = await _orders.UploadProofAsync(Uid, orderNumber, proof);
        if (r.Succeeded) TempData["Success"] = "Đã tải biên lai. Chúng tôi sẽ kiểm tra và xác nhận thanh toán sớm nhất."; else TempData["Error"] = r.Error;
        return RedirectToAction(nameof(Details), new { orderNumber });
    }

    /// <summary>Payment proofs are private: only the order's owner and staff allowed to verify payments can open them.</summary>
    [HttpGet("don-hang/bien-lai/{proofId:int}")]
    public async Task<IActionResult> Proof(int proofId)
    {
        var proof = await _db.PaymentProofs.AsNoTracking().Include(p => p.Order).FirstOrDefaultAsync(p => p.Id == proofId);
        if (proof == null) return NotFound();
        var isOwner = proof.Order!.UserId == Uid;
        var isReviewer = (await _auth.AuthorizeAsync(User, AppPolicies.CanVerifyPayments)).Succeeded;
        if (!isOwner && !isReviewer) return NotFound();   // 404 rather than 403: do not confirm the file exists

        var file = _files.OpenPrivate(proof.StoredPath);
        if (file == null) return NotFound();
        Response.Headers["Cache-Control"] = "private, no-store";
        Response.Headers["X-Content-Type-Options"] = "nosniff";
        return File(file.Value.Stream, file.Value.ContentType);
    }

    // ---- public tracking ----------------------------------------------------

    [AllowAnonymous, HttpGet("theo-doi-don-hang")]
    public IActionResult Track(string? orderNumber = null) => View(new TrackOrderViewModel { OrderNumber = orderNumber ?? "" });

    [AllowAnonymous, HttpPost("theo-doi-don-hang"), EnableRateLimiting("auth")]
    public async Task<IActionResult> Track(TrackOrderViewModel vm)
    {
        if (!ModelState.IsValid) return View(vm);
        vm.Searched = true;
        vm.Result = await _orders.TrackAsync(vm.OrderNumber, vm.Phone);
        return View(vm);
    }
}
