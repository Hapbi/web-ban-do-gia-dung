using System.ComponentModel.DataAnnotations;
using Microsoft.AspNetCore.Mvc.Rendering;
using HomeAppliances.Web.Models.Entities;

namespace HomeAppliances.Web.Models.ViewModels;

public class ProductEditViewModel
{
    public int Id { get; set; }

    [Required(ErrorMessage = "Vui lòng nhập tên sản phẩm."), StringLength(200)]
    [Display(Name = "Tên sản phẩm")] public string Name { get; set; } = "";

    [StringLength(220)][Display(Name = "Đường dẫn (slug)")] public string? Slug { get; set; }
    [Display(Name = "Mô tả")] public string? Description { get; set; }

    [Required(ErrorMessage = "Vui lòng nhập thương hiệu."), StringLength(100)]
    [Display(Name = "Thương hiệu")] public string Brand { get; set; } = "";

    [Range(1, int.MaxValue, ErrorMessage = "Vui lòng chọn danh mục.")]
    [Display(Name = "Danh mục")] public int CategoryId { get; set; }

    [Range(1, 100000000000, ErrorMessage = "Giá gốc phải lớn hơn 0.")]
    [Display(Name = "Giá gốc (₫)")] public decimal OriginalPrice { get; set; }

    [Range(0, 100000000000, ErrorMessage = "Giá khuyến mãi không hợp lệ.")]
    [Display(Name = "Giá khuyến mãi (₫)")] public decimal? DiscountPrice { get; set; }

    [Range(0, 1000000, ErrorMessage = "Tồn kho phải từ 0 trở lên.")]
    [Display(Name = "Số lượng tồn kho")] public int StockQuantity { get; set; }

    [Display(Name = "Sản phẩm nổi bật")] public bool IsFeatured { get; set; }
    [Display(Name = "Đang bán")] public bool IsActive { get; set; } = true;
    [Display(Name = "Thông số kỹ thuật (mỗi dòng: Tên: Giá trị)")] public string? SpecificationsText { get; set; }

    public List<SelectListItem> Categories { get; set; } = new();
    public List<ProductImage> Images { get; set; } = new();
}

public class CategoryEditViewModel
{
    public int Id { get; set; }
    [Required(ErrorMessage = "Vui lòng nhập tên danh mục."), StringLength(100)][Display(Name = "Tên danh mục")] public string Name { get; set; } = "";
    [StringLength(500)][Display(Name = "Mô tả")] public string? Description { get; set; }
    [Range(0, 1000)][Display(Name = "Thứ tự hiển thị")] public int DisplayOrder { get; set; }
    [Display(Name = "Hiển thị")] public bool IsActive { get; set; } = true;
}

public class BannerEditViewModel
{
    public int Id { get; set; }
    [Required(ErrorMessage = "Vui lòng nhập tiêu đề."), StringLength(150)][Display(Name = "Tiêu đề")] public string Title { get; set; } = "";
    [StringLength(300)][Display(Name = "Phụ đề")] public string? Subtitle { get; set; }
    [StringLength(300)][Display(Name = "Liên kết (đường dẫn nội bộ, ví dụ /san-pham)")] public string? LinkUrl { get; set; }
    [Display(Name = "Hiển thị")] public bool IsActive { get; set; } = true;
    [Range(0, 1000)][Display(Name = "Thứ tự")] public int SortOrder { get; set; }
    public string? ExistingImage { get; set; }
}

public class BankSettingsViewModel
{
    [Required(ErrorMessage = "Vui lòng nhập tên ngân hàng."), StringLength(100)][Display(Name = "Tên ngân hàng")] public string BankName { get; set; } = "";
    [Required(ErrorMessage = "Vui lòng nhập chủ tài khoản."), StringLength(150)][Display(Name = "Chủ tài khoản")] public string AccountHolder { get; set; } = "";
    [Required(ErrorMessage = "Vui lòng nhập số tài khoản."), StringLength(50)][Display(Name = "Số tài khoản")] public string AccountNumber { get; set; } = "";
    [StringLength(150)][Display(Name = "Chi nhánh (không bắt buộc)")] public string? Branch { get; set; }
    [Required(ErrorMessage = "Vui lòng nhập hướng dẫn chuyển khoản."), StringLength(1000)][Display(Name = "Hướng dẫn chuyển khoản")] public string Instructions { get; set; } = "";
    [Required, StringLength(100)][Display(Name = "Mẫu nội dung chuyển khoản (dùng {OrderNumber})")] public string ReferenceFormat { get; set; } = "{OrderNumber}";
    public string? QrImagePath { get; set; }
}

public class WebsiteSettingsViewModel
{
    [Required(ErrorMessage = "Vui lòng nhập tên cửa hàng."), StringLength(150)][Display(Name = "Tên cửa hàng")] public string SiteName { get; set; } = "";
    [StringLength(200)][Display(Name = "Khẩu hiệu")] public string Tagline { get; set; } = "";
    [StringLength(1000)][Display(Name = "Giới thiệu ngắn")] public string Introduction { get; set; } = "";
    [StringLength(300)][Display(Name = "Địa chỉ")] public string Address { get; set; } = "";
    [StringLength(50)][Display(Name = "Số điện thoại")] public string Phone { get; set; } = "";
    [StringLength(200)][Display(Name = "Email chăm sóc khách hàng")] public string Email { get; set; } = "";
    [StringLength(200)][Display(Name = "Giờ làm việc")] public string OpeningHours { get; set; } = "";
    [Url(ErrorMessage = "Địa chỉ không hợp lệ."), StringLength(300)][Display(Name = "Facebook")] public string? FacebookUrl { get; set; }
    [Url(ErrorMessage = "Địa chỉ không hợp lệ."), StringLength(300)][Display(Name = "YouTube")] public string? YoutubeUrl { get; set; }
    [Url(ErrorMessage = "Địa chỉ không hợp lệ."), StringLength(300)][Display(Name = "Zalo")] public string? ZaloUrl { get; set; }
    [Url(ErrorMessage = "Địa chỉ không hợp lệ."), StringLength(300)][Display(Name = "TikTok")] public string? TiktokUrl { get; set; }
    [Range(0, 10000000, ErrorMessage = "Phí vận chuyển không hợp lệ.")][Display(Name = "Phí vận chuyển (₫)")] public decimal ShippingFee { get; set; }
    [Range(0, 1000000000, ErrorMessage = "Giá trị không hợp lệ.")][Display(Name = "Miễn phí vận chuyển từ (₫, 0 = tắt)")] public decimal FreeShippingThreshold { get; set; }
    [Range(0, 720, ErrorMessage = "Từ 0 đến 720 giờ.")][Display(Name = "Tự hủy đơn chưa thanh toán sau (giờ, 0 = tắt)")] public int UnpaidOrderExpiryHours { get; set; }
}

public class UserListItem
{
    public string Id { get; set; } = "";
    public string Email { get; set; } = "";
    public string FullName { get; set; } = "";
    public string? Phone { get; set; }
    public string Role { get; set; } = "";
    public bool IsActive { get; set; }
    public bool CanVerifyPayments { get; set; }
    public DateTime CreatedUtc { get; set; }
}

public class CreateStaffViewModel
{
    [Required(ErrorMessage = "Vui lòng nhập họ và tên."), StringLength(100)][Display(Name = "Họ và tên")] public string FullName { get; set; } = "";
    [Required(ErrorMessage = "Vui lòng nhập email."), EmailAddress(ErrorMessage = "Email không hợp lệ.")][Display(Name = "Email")] public string Email { get; set; } = "";
    [RegularExpression(Msg.PhonePattern, ErrorMessage = Msg.PhoneError)][Display(Name = "Số điện thoại")] public string? PhoneNumber { get; set; }
    [Required(ErrorMessage = "Vui lòng nhập mật khẩu ban đầu."), StringLength(100, MinimumLength = 8, ErrorMessage = "Mật khẩu từ 8 đến 100 ký tự.")]
    [DataType(DataType.Password)][Display(Name = "Mật khẩu ban đầu")] public string Password { get; set; } = "";
    [Required][Display(Name = "Vai trò")] public string Role { get; set; } = "Employee";
}

public class UserEditViewModel
{
    public string Id { get; set; } = "";
    public string Email { get; set; } = "";
    [Required(ErrorMessage = "Vui lòng nhập họ và tên."), StringLength(100)][Display(Name = "Họ và tên")] public string FullName { get; set; } = "";
    [Required][Display(Name = "Vai trò")] public string Role { get; set; } = "";
    [Display(Name = "Được xác minh thanh toán (chỉ áp dụng cho nhân viên)")] public bool CanVerifyPayments { get; set; }
    [Display(Name = "Tài khoản đang hoạt động")] public bool IsActive { get; set; }
    public bool IsSelf { get; set; }
}
