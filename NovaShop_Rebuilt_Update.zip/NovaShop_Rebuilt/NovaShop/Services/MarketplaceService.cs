using Microsoft.EntityFrameworkCore;
using NovaShop.Data;
using NovaShop.Models;

namespace NovaShop.Services;

public class MarketplaceService
{
    private readonly AppDbContext _db;
    public MarketplaceService(AppDbContext db) => _db = db;

    public async Task<List<Product>> GetPendingAsync() =>
        await _db.Products.Include(p => p.Owner).Include(p => p.Category).Include(p => p.Images)
            .Where(p => p.IsMarketplaceListing && p.ListingStatus == ListingStatus.Pending)
            .OrderBy(p => p.CreatedAt).ToListAsync();

    public async Task<List<Product>> GetAllListingsAsync() =>
        await _db.Products.Include(p => p.Owner).Include(p => p.Category).Include(p => p.Images)
            .Where(p => p.IsMarketplaceListing)
            .OrderByDescending(p => p.CreatedAt).ToListAsync();

    public async Task<(bool ok, string msg)> ApproveAsync(int productId)
    {
        var p = await _db.Products.FindAsync(productId);
        if (p == null || !p.IsMarketplaceListing) return (false, "Không tìm thấy");
        p.ListingStatus = ListingStatus.Approved;
        p.IsActive = true;
        p.RejectReason = null;
        await _db.SaveChangesAsync();
        return (true, "Đã duyệt sản phẩm");
    }

    public async Task<(bool ok, string msg)> RejectAsync(int productId, string reason)
    {
        var p = await _db.Products.FindAsync(productId);
        if (p == null || !p.IsMarketplaceListing) return (false, "Không tìm thấy");
        p.ListingStatus = ListingStatus.Rejected;
        p.IsActive = false;
        p.RejectReason = reason?.Trim();
        await _db.SaveChangesAsync();
        return (true, "Đã từ chối");
    }
}
