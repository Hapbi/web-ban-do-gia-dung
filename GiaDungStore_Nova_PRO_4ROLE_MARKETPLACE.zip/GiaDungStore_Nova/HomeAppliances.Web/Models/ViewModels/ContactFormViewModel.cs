using System.ComponentModel.DataAnnotations;

namespace HomeAppliances.Web.Models.ViewModels;

public class ContactFormViewModel
{
    [Required(ErrorMessage = "Vui lòng nhập họ và tên.")]
    [StringLength(100, ErrorMessage = "Họ và tên tối đa 100 ký tự.")]
    [Display(Name = "Họ và tên")]
    public string FullName { get; set; } = "";

    [Required(ErrorMessage = "Vui lòng nhập email.")]
    [EmailAddress(ErrorMessage = "Email không hợp lệ.")]
    [StringLength(200)]
    [Display(Name = "Email")]
    public string Email { get; set; } = "";

    [Phone(ErrorMessage = "Số điện thoại không hợp lệ.")]
    [StringLength(20)]
    [Display(Name = "Số điện thoại")]
    public string? Phone { get; set; }

    [Required(ErrorMessage = "Vui lòng nhập nội dung.")]
    [StringLength(2000, MinimumLength = 10, ErrorMessage = "Nội dung từ 10 đến 2000 ký tự.")]
    [Display(Name = "Nội dung")]
    public string Message { get; set; } = "";
}
