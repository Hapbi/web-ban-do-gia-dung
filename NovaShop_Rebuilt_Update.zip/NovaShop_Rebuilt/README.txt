NOVASHOP — WEBSITE ASP.NET CORE MVC (.NET 8)
================================================

Đây là bản dựng lại từ mã nguồn trong file anh gửi, kèm bổ sung trang quản trị cho Admin/Nhân viên.

YÊU CẦU
- Windows 10/11
- .NET 8 SDK: https://dotnet.microsoft.com/download/dotnet/8.0
- Có Internet lần đầu để tải các gói NuGet và font/ảnh ngoài.

CÁCH CHẠY
1. Giải nén toàn bộ thư mục.
2. Mở thư mục NovaShop.
3. Nhấp đúp run.bat, hoặc mở CMD/PowerShell tại thư mục NovaShop và chạy:
   dotnet restore
   dotnet run --urls http://localhost:5080
4. Mở http://localhost:5080

TÀI KHOẢN DEMO (được tạo lần đầu trong cơ sở dữ liệu)
- Admin: admin@nova.vn / admin123
- Nhân viên: staff@nova.vn / staff123
- Khách hàng: customer@nova.vn / customer123

CHỨC NĂNG TRONG BẢN NÀY
- Trang chủ, danh mục, tìm kiếm/lọc sản phẩm, chi tiết và đánh giá.
- Đăng ký/đăng nhập, giỏ hàng, mã giảm giá, đặt hàng COD/chuyển khoản, xem đơn hàng.
- Dashboard quản trị, quản lý sản phẩm (thêm/sửa/ẩn-hiện/xóa có kiểm tra), quản lý đơn hàng và trạng thái thanh toán.
- Admin quản lý vai trò và khóa/mở tài khoản; cấu hình thông tin cửa hàng; nhật ký thao tác.
- Phân quyền Admin/Staff theo quyền có trong mã nguồn. Các trang quản trị kiểm tra quyền ở phía máy chủ.
- Cơ sở dữ liệu SQLite tạo tại NovaShop/novashop.db khi chạy lần đầu.

LƯU Ý QUAN TRỌNG
- Đây là bản demo để chạy và phát triển tiếp, chưa phải hệ thống sẵn sàng đưa lên Internet/nhận tiền thật.
- Tài khoản/mật khẩu demo cần đổi trước khi triển khai thực tế. Mã nguồn gốc dùng SHA-256 có salt tĩnh; nên chuyển sang ASP.NET Core Identity/password hasher trước khi dùng thật.
- Tính năng thanh toán chỉ ghi nhận trạng thái trong ứng dụng, không kết nối ngân hàng/cổng thanh toán.
- Một số chức năng được khai báo trong các service/model nguồn nhưng chưa có giao diện đầy đủ trong file gốc (ví dụ blog, marketplace và báo cáo chuyên sâu); bản dựng này ưu tiên luồng mua hàng và quản trị sản phẩm/đơn hàng/tài khoản.
- Ảnh sản phẩm dùng URL ngoài; cần Internet để tải ảnh. Kiểm tra quyền sử dụng ảnh trước khi kinh doanh thật.


CAP NHAT TU FILE NGUON MOI (2026-10-23)
- Da ap dung 33 file tu ban nguon moi: ManageController, Cart/Notification/Blog/Contact/Wishlist controllers,
  cac view quan tri va view Blog/Lien he/Yeu thich/Thong bao, layout, trang chi tiet san pham, CSS va JS.
- Them/bo sung cac man hinh quan tri: dashboard, san pham, don hang, nguoi dung, phan quyen,
  danh muc/thuong hieu/tag, banner, bai viet, lien he, marketplace, bao cao, cau hinh va nhat ky.
- Da dong goi theo cau truc project hien co. Chua the build/xac nhan chay vi moi truong tao file khong co .NET SDK.
  Can chay dotnet build va kiem thu trong may co .NET 8 SDK truoc khi dua len hosting.
