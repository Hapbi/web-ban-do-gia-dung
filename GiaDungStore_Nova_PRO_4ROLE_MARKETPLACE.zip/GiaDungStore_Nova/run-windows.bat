@echo off
setlocal
cd /d "%~dp0"
title Gia Dung Nova - Local Web

echo ==========================================
echo       GIA DUNG NOVA - KHOI DONG WEBSITE
echo ==========================================
where dotnet >nul 2>nul
if errorlevel 1 (
  echo [LOI] Chua tim thay dotnet. Hay cai .NET 8 SDK:
  echo https://dotnet.microsoft.com/download/dotnet/8.0
  pause
  exit /b 1
)
set ASPNETCORE_ENVIRONMENT=Development
echo.
echo .NET SDK:
dotnet --list-sdks
echo.
echo SQL Server can dang chay. Database GiaDungStoreNova va du lieu mau
echo se duoc tao tu dong trong lan chay dau tien.
echo Dang khoi dong tai http://localhost:5080
echo Nhan Ctrl+C trong cua so nay de dung website.
echo.
cd HomeAppliances.Web
dotnet restore
if errorlevel 1 (
  echo [LOI] Khong tai duoc package. Kiem tra mang va thu lai.
  pause
  exit /b 1
)
start "" http://localhost:5080
dotnet run --no-launch-profile --urls http://localhost:5080
echo.
echo Website da dung.
pause
