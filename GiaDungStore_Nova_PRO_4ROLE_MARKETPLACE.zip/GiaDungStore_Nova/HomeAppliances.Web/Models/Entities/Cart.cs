using Microsoft.EntityFrameworkCore;

namespace HomeAppliances.Web.Models.Entities;

[Index(nameof(UserId), IsUnique = true)]
public class Cart
{
    public int Id { get; set; }
    public string UserId { get; set; } = "";
    public ApplicationUser? User { get; set; }
    public DateTime UpdatedUtc { get; set; } = DateTime.UtcNow;
    public List<CartItem> Items { get; set; } = new();
}

[Index(nameof(CartId), nameof(ProductId), IsUnique = true)]
public class CartItem
{
    public int Id { get; set; }
    public int CartId { get; set; }
    public Cart? Cart { get; set; }
    public int ProductId { get; set; }
    public Product? Product { get; set; }
    public int Quantity { get; set; }
}
