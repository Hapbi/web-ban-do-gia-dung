using HomeAppliances.Web.Options;
using HomeAppliances.Web.Services;

namespace HomeAppliances.Web.Infrastructure;

public interface ISiteInfoAccessor { SiteInfoOptions Value { get; } }

/// <summary>Gives views synchronous access to the company details loaded (cached) once per request.</summary>
public class SiteInfoAccessor : ISiteInfoAccessor
{
    public const string ItemKey = "SiteInfo";
    private readonly IHttpContextAccessor _http;
    public SiteInfoAccessor(IHttpContextAccessor http) => _http = http;
    public SiteInfoOptions Value => _http.HttpContext?.Items[ItemKey] as SiteInfoOptions ?? new SiteInfoOptions();
}

public class SiteInfoMiddleware
{
    private readonly RequestDelegate _next;
    public SiteInfoMiddleware(RequestDelegate next) => _next = next;

    public async Task InvokeAsync(HttpContext ctx, ISettingsService settings)
    {
        // Static files are served before this middleware, so this only runs for real pages.
        try { ctx.Items[SiteInfoAccessor.ItemKey] = SettingsService.ToSiteInfo(await settings.GetWebsiteAsync()); }
        catch { /* database not reachable yet: views fall back to placeholder values */ }
        await _next(ctx);
    }
}

public class SecurityHeadersMiddleware
{
    private readonly RequestDelegate _next;
    private readonly bool _csp;
    public SecurityHeadersMiddleware(RequestDelegate next, bool enableCsp) { _next = next; _csp = enableCsp; }

    public Task InvokeAsync(HttpContext ctx)
    {
        var h = ctx.Response.Headers;
        h["X-Content-Type-Options"] = "nosniff";
        h["X-Frame-Options"] = "DENY";
        h["Referrer-Policy"] = "strict-origin-when-cross-origin";
        h["Permissions-Policy"] = "camera=(), microphone=(), geolocation=()";
        // CSP is off in Development because Visual Studio's browser-refresh injects inline script.
        if (_csp) h["Content-Security-Policy"] = "default-src 'self'; img-src 'self' data:; style-src 'self' 'unsafe-inline'; script-src 'self'; frame-ancestors 'none'; base-uri 'self'; form-action 'self'";
        return _next(ctx);
    }
}
