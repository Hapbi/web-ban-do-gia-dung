using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using HomeAppliances.Web.Data;
using HomeAppliances.Web.Infrastructure;

namespace HomeAppliances.Web.Areas.Employee.Controllers;

[Area("Employee"), Authorize(Policy = AppPolicies.StaffOnly)]
public class MarketplaceController : Controller
{
    private readonly ApplicationDbContext _db;
    public MarketplaceController(ApplicationDbContext db)=>_db=db;

    public async Task<IActionResult> Index()
    {
        var rows=await _db.Products.AsNoTracking().Include(p=>p.OwnerUser).Include(p=>p.Category)
            .Where(p=>p.IsMarketplaceListing).OrderBy(p=>p.ListingStatus).ThenByDescending(p=>p.CreatedUtc).ToListAsync();
        return View(rows);
    }

    [HttpPost]
    public async Task<IActionResult> Approve(int id)
    {
        var p=await _db.Products.FirstOrDefaultAsync(x=>x.Id==id && x.IsMarketplaceListing);
        if(p==null)return NotFound();
        p.ListingStatus=1;p.IsActive=true;p.UpdatedUtc=DateTime.UtcNow;
        await _db.SaveChangesAsync();
        TempData["Success"]="Đã duyệt sản phẩm marketplace.";
        return RedirectToAction(nameof(Index));
    }

    [HttpPost]
    public async Task<IActionResult> Reject(int id)
    {
        var p=await _db.Products.FirstOrDefaultAsync(x=>x.Id==id && x.IsMarketplaceListing);
        if(p==null)return NotFound();
        p.ListingStatus=2;p.IsActive=false;p.UpdatedUtc=DateTime.UtcNow;
        await _db.SaveChangesAsync();
        TempData["Success"]="Đã từ chối sản phẩm marketplace.";
        return RedirectToAction(nameof(Index));
    }
}
