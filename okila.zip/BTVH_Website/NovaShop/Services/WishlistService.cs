using Microsoft.EntityFrameworkCore;
using NovaShop.Data;

namespace NovaShop.Services;

public class WishlistService
{
    private readonly AppDbContext _db;
    private readonly AuthService _auth;
    public WishlistService(AppDbContext db, AuthService auth) { _db = db; _auth = auth; }

    public async Task<bool> IsWishlistedAsync(int productId)
    {
        var uid = _auth.GetCurrentId();
        if (uid == null) return false;
        return await _db.Wishlists.AnyAsync(w => w.UserId == uid.Value && w.ProductId == productId);
    }

    public async Task<(bool ok, string msg)> ToggleAsync(int productId)
    {
        var uid = _auth.GetCurrentId();
        if (uid == null) return (false, "Vui lòng đăng nhập");

        var existing = await _db.Wishlists.FirstOrDefaultAsync(w => w.UserId == uid.Value && w.ProductId == productId);
        if (existing != null)
        {
            _db.Wishlists.Remove(existing);
            await _db.SaveChangesAsync();
            return (true, "Đã xóa khỏi yêu thích");
        }
        _db.Wishlists.Add(new Models.WishlistItem { UserId = uid.Value, ProductId = productId });
        await _db.SaveChangesAsync();
        return (true, "Đã thêm vào yêu thích");
    }

    public async Task<List<Models.Product>> GetUserWishlistAsync()
    {
        var uid = _auth.GetCurrentId();
        if (uid == null) return new();
        return await _db.Wishlists
            .Where(w => w.UserId == uid.Value)
            .Include(w => w.Product).ThenInclude(p => p!.Images)
            .Include(w => w.Product).ThenInclude(p => p!.Reviews)
            .OrderByDescending(w => w.AddedAt)
            .Select(w => w.Product!)
            .ToListAsync();
    }
}


####################################################################################################
