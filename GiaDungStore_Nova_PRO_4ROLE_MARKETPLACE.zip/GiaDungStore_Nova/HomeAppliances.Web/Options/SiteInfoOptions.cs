namespace HomeAppliances.Web.Options;

/// <summary>
/// Company details shown in the header/footer. Bound from the "Site" section of
/// configuration. Values in square brackets are placeholders. In Phase 8 these
/// move to the WebsiteSettings table so an administrator can edit them.
/// </summary>
public class SiteInfoOptions
{
    public const string SectionName = "Site";

    public string Name { get; set; } = "[Tên cửa hàng]";
    public string Tagline { get; set; } = "Điện máy gia dụng chính hãng";
    public string Introduction { get; set; } =
        "[Giới thiệu ngắn về cửa hàng. Quản trị viên sẽ cập nhật nội dung này.]";
    public string Address { get; set; } = "[Địa chỉ cửa hàng]";
    public string Phone { get; set; } = "[Số điện thoại]";
    public string Email { get; set; } = "[Email chăm sóc khách hàng]";
    public string OpeningHours { get; set; } = "[Giờ làm việc, ví dụ: 8:00 - 21:00 hằng ngày]";
    public string FacebookUrl { get; set; } = "";
    public string YoutubeUrl { get; set; } = "";
    public string ZaloUrl { get; set; } = "";
    public string TiktokUrl { get; set; } = "";

    /// <summary>True when a value is still an unfilled "[...]" placeholder.</summary>
    public static bool IsPlaceholder(string? value) =>
        string.IsNullOrWhiteSpace(value) || value.TrimStart().StartsWith('[');
}
