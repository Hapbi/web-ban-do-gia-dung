using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using NovaShop.Services;

namespace NovaShop.Controllers;

[Authorize]
public class WishlistController : Controller
{
    private readonly WishlistService _wish;
    public WishlistController(WishlistService wish) => _wish = wish;

    [Route("yeu-thich")]
    public async Task<IActionResult> Index() => View(await _wish.GetUserWishlistAsync());

    [HttpPost, Route("yeu-thich/toggle")]
    public async Task<IActionResult> Toggle(int productId, string? returnUrl)
    {
        var (ok, msg) = await _wish.ToggleAsync(productId);
        TempData[ok ? "Success" : "Error"] = msg;
        return !string.IsNullOrEmpty(returnUrl) && Url.IsLocalUrl(returnUrl) ? Redirect(returnUrl) : RedirectToAction(nameof(Index));
    }
}
