/* Storefront behaviour (vanilla JS). No business logic here: prices, stock and
   totals are always recalculated on the server. */
(function () {
  "use strict";

  // ---- Toasts -------------------------------------------------------------
  var toastHost = document.getElementById("toasts");

  function showToast(message, type, timeoutMs) {
    if (!toastHost || !message) return;
    var el = document.createElement("div");
    el.className = "toast" + (type ? " toast--" + type : "");
    el.setAttribute("role", type === "error" ? "alert" : "status");
    var text = document.createElement("span");
    text.textContent = message;               // textContent: no HTML injection
    var close = document.createElement("button");
    close.type = "button";
    close.setAttribute("aria-label", "Đóng thông báo");
    close.textContent = "×";
    close.addEventListener("click", function () { el.remove(); });
    el.appendChild(text);
    el.appendChild(close);
    toastHost.appendChild(el);
    window.setTimeout(function () { el.remove(); }, timeoutMs || 6000);
  }
  window.showToast = showToast;

  // Server-rendered messages (TempData) are emitted as <div data-toast="success">text</div>
  document.querySelectorAll("[data-toast]").forEach(function (n) {
    showToast(n.textContent.trim(), n.getAttribute("data-toast"));
    n.remove();
  });

  // ---- Mobile navigation --------------------------------------------------
  var navToggle = document.querySelector("[data-nav-toggle]");
  var nav = document.getElementById("category-nav");
  if (navToggle && nav) {
    navToggle.addEventListener("click", function () {
      var open = nav.classList.toggle("is-open");
      navToggle.setAttribute("aria-expanded", String(open));
    });
  }

  // ---- Show / hide password ----------------------------------------------
  document.querySelectorAll("[data-toggle-password]").forEach(function (btn) {
    btn.addEventListener("click", function () {
      var input = document.getElementById(btn.getAttribute("data-toggle-password"));
      if (!input) return;
      var show = input.type === "password";
      input.type = show ? "text" : "password";
      btn.textContent = show ? "Ẩn" : "Hiện";
      btn.setAttribute("aria-pressed", String(show));
      btn.setAttribute("aria-label", show ? "Ẩn mật khẩu" : "Hiện mật khẩu");
    });
  });

  // ---- Quantity stepper ---------------------------------------------------
  document.querySelectorAll("[data-qty]").forEach(function (wrap) {
    var input = wrap.querySelector("input");
    var max = parseInt(wrap.getAttribute("data-max") || "99", 10);
    function clamp(v) { v = parseInt(v, 10); if (isNaN(v) || v < 1) v = 1; return Math.min(v, max); }
    wrap.querySelectorAll("button").forEach(function (b) {
      b.addEventListener("click", function () {
        var step = b.getAttribute("data-step") === "up" ? 1 : -1;
        input.value = clamp(parseInt(input.value, 10) + step);
        input.dispatchEvent(new Event("change", { bubbles: true }));
      });
    });
    input.addEventListener("change", function () { input.value = clamp(input.value); });
  });

  // ---- Loading state on submit -------------------------------------------
  document.querySelectorAll("form[data-loading]").forEach(function (form) {
    form.addEventListener("submit", function () {
      if (form.dataset.submitted === "1") return;
      if (typeof form.checkValidity === "function" && !form.checkValidity()) return;
      form.dataset.submitted = "1";
      var btn = form.querySelector("button[type=submit], input[type=submit]");
      if (btn) { btn.classList.add("is-loading"); btn.setAttribute("aria-busy", "true"); }
    });
  });

  // ---- Confirm before destructive actions --------------------------------
  document.addEventListener("submit", function (e) {
    var msg = e.target && e.target.getAttribute && e.target.getAttribute("data-confirm");
    if (msg && !window.confirm(msg)) e.preventDefault();
  });

  // ---- Add to cart without leaving the page (falls back to a normal POST) ----
  document.querySelectorAll("form[data-cart-add]").forEach(function (form) {
    form.addEventListener("submit", function (e) {
      if (!window.fetch || (e.submitter && e.submitter.name === "buyNow")) return;   // "Mua ngay" uses the normal redirect
      e.preventDefault();
      var btn = e.submitter || form.querySelector("button[type=submit]");
      if (btn) btn.disabled = true;
      fetch(form.action, { method: "POST", body: new FormData(form), credentials: "same-origin", headers: { "X-Requested-With": "XMLHttpRequest" } })
        .then(function (r) {
          return r.json().then(function (d) { return { status: r.status, data: d }; });
        })
        .then(function (result) {
          var d = result.data;
          if (d.requiresLogin) {
            var modal = document.getElementById("auth-gate");
            if (modal) {
              var link = modal.querySelector("[data-auth-login]");
              if (link && d.loginUrl) link.href = d.loginUrl;
              modal.hidden = false;
              var close = modal.querySelector("[data-auth-close]");
              if (close) close.focus();
            } else {
              window.location.href = d.loginUrl || "/dang-nhap";
            }
            return;
          }
          showToast(d.message, d.ok ? "success" : "error");
          document.querySelectorAll("[data-cart-count]").forEach(function (n) {
            n.textContent = d.count; n.setAttribute("aria-label", d.count + " sản phẩm trong giỏ");
          });
        })
        .catch(function () { form.submit(); })
        .then(function () { if (btn) btn.disabled = false; });
    });
  });


  // ---- Account gate for guest cart actions --------------------------------
  var authGate = document.getElementById("auth-gate");
  if (authGate) {
    authGate.querySelectorAll("[data-auth-close]").forEach(function (b) {
      b.addEventListener("click", function () { authGate.hidden = true; });
    });
    authGate.addEventListener("click", function (e) {
      if (e.target === authGate) authGate.hidden = true;
    });
  }

  // ---- Product gallery thumbnails ---------------------------------------------
  document.querySelectorAll("[data-gallery-thumb]").forEach(function (t) {
    t.addEventListener("click", function () {
      var main = document.getElementById("gallery-main");
      if (main) main.src = t.getAttribute("data-src");
      document.querySelectorAll("[data-gallery-thumb]").forEach(function (o) { o.classList.toggle("is-active", o === t); });
    });
  });

  // ---- Submit a form when a select changes (sorting) --------------------------
  document.querySelectorAll("[data-autosubmit]").forEach(function (el) {
    el.addEventListener("change", function () { if (el.form) el.form.submit(); });
  });

  // ---- Checkout: fill the form from a saved address ---------------------------
  document.querySelectorAll("[data-fill-address]").forEach(function (b) {
    b.addEventListener("click", function () {
      var set = function (id, v) { var i = document.getElementById(id); if (i) i.value = v; };
      set("ReceiverName", b.getAttribute("data-name")); set("Phone", b.getAttribute("data-phone")); set("Address", b.getAttribute("data-address"));
    });
  });

  // ---- Staff area: collapsible menu on small screens --------------------------
  var staffToggle = document.querySelector("[data-staff-toggle]");
  var staffNav = document.getElementById("staff-nav");
  if (staffToggle && staffNav) {
    staffToggle.addEventListener("click", function () {
      var open = staffNav.classList.toggle("is-open");
      staffToggle.setAttribute("aria-expanded", String(open));
    });
  }

  // ---- Filters panel: collapsed by default on small screens ---------------
  var filters = document.querySelector("details.filters");
  if (filters && window.matchMedia && window.matchMedia("(max-width: 860px)").matches) filters.removeAttribute("open");
})();
