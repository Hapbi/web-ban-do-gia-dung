using Microsoft.EntityFrameworkCore;
using NovaShop.Data;
using NovaShop.Models;

namespace NovaShop.Services;

public class SettingsService
{
    private readonly AppDbContext _db;
    public SettingsService(AppDbContext db) => _db = db;

    public async Task<SiteSettings> GetSiteAsync() => await _db.SiteSettings.FirstAsync();
    public async Task<BankSettings> GetBankAsync() => await _db.BankSettings.FirstAsync();

    public async Task SaveSiteAsync(SiteSettings s)
    {
        var existing = await _db.SiteSettings.FirstAsync();
        s.Id = existing.Id;
        _db.Entry(existing).CurrentValues.SetValues(s);
        existing.UpdatedAt = DateTime.Now;
        await _db.SaveChangesAsync();
    }

    public async Task SaveBankAsync(BankSettings b)
    {
        var existing = await _db.BankSettings.FirstAsync();
        b.Id = existing.Id;
        _db.Entry(existing).CurrentValues.SetValues(b);
        existing.UpdatedAt = DateTime.Now;
        await _db.SaveChangesAsync();
    }
}
