using System.Net;
using Microsoft.EntityFrameworkCore;
using HomeAppliances.Web.Data;
using HomeAppliances.Web.Domain;
using HomeAppliances.Web.Models.Entities;
using HomeAppliances.Web.Models.ViewModels;

namespace HomeAppliances.Web.Services;

public record CheckoutInput(string ReceiverName, string Phone, string Address, string? Notes);

public interface IOrderService
{
    Task<ServiceResult<Order>> PlaceOrderAsync(string userId, string email, CheckoutInput input);
    Task<ServiceResult> CancelAsync(int orderId, ActorRole actor, string? actorUserId, string actorName, string? reason, string? mustOwnUserId = null);
    Task<ServiceResult> UploadProofAsync(string userId, string orderNumber, IFormFile file);
    Task<ServiceResult> ApproveAsync(int orderId, string reviewerId, string reviewerName, ActorRole role);
    Task<ServiceResult> RejectAsync(int orderId, string reviewerId, string reviewerName, ActorRole role, string reason);
    Task<ServiceResult> AdvanceStatusAsync(int orderId, OrderStatus next, ActorRole actor, string actorUserId, string actorName, string? note);

    Task<PagedResult<OrderListItem>> GetCustomerOrdersAsync(string userId, int page);
    Task<Order?> GetCustomerOrderAsync(string userId, string orderNumber);
    Task<PagedResult<OrderListItem>> SearchAsync(OrderSearch search);
    Task<Order?> GetForStaffAsync(int id);
    Task<TrackResult?> TrackAsync(string orderNumber, string phone);
    Task<int> CancelExpiredUnpaidAsync(DateTime createdBeforeUtc);
}

/// <summary>
/// Order workflow. Stock is reserved (decremented) when the order is created and released when it is
/// cancelled. Every status change is a guarded UPDATE ("... WHERE Status = expected") so concurrent
/// requests cannot approve, cancel or ship the same order twice.
/// </summary>
public class OrderService : IOrderService
{
    private const int MaxProofsPerOrder = 10;
    private readonly ApplicationDbContext _db;
    private readonly ISettingsService _settings;
    private readonly IFileStorage _files;
    private readonly IEmailService _email;
    private readonly IAuditService _audit;
    private readonly ILogger<OrderService> _log;

    public OrderService(ApplicationDbContext db, ISettingsService settings, IFileStorage files, IEmailService email, IAuditService audit, ILogger<OrderService> log)
    { _db = db; _settings = settings; _files = files; _email = email; _audit = audit; _log = log; }

    // ---- create -------------------------------------------------------------

    public async Task<ServiceResult<Order>> PlaceOrderAsync(string userId, string email, CheckoutInput input)
    {
        var cart = await _db.Carts.Include(c => c.Items).FirstOrDefaultAsync(c => c.UserId == userId);
        if (cart == null || cart.Items.Count == 0) return ServiceResult<Order>.Fail("Giỏ hàng của bạn đang trống.");

        var ids = cart.Items.Select(i => i.ProductId).ToList();
        var products = await _db.Products.AsNoTracking().Where(p => ids.Contains(p.Id)).ToListAsync();

        // 1) Validate against CURRENT data. Nothing submitted by the browser is trusted.
        foreach (var item in cart.Items)
        {
            var p = products.FirstOrDefault(x => x.Id == item.ProductId);
            if (p == null || !p.IsActive) return ServiceResult<Order>.Fail("Có sản phẩm trong giỏ không còn được bán. Vui lòng kiểm tra lại giỏ hàng.");
            if (p.OwnerUserId == userId) return ServiceResult<Order>.Fail($"Bạn không thể mua chính sản phẩm "{p.Name}" do mình đăng bán.");
            if (item.Quantity > p.StockQuantity) return ServiceResult<Order>.Fail($"Sản phẩm \"{p.Name}\" chỉ còn {p.StockQuantity} sản phẩm.");
        }

        var settings = await _settings.GetWebsiteAsync();
        var pricing = PricingCalculator.Calculate(
            cart.Items.Select(i => { var p = products.First(x => x.Id == i.ProductId); return new PricingLine(p.OriginalPrice, p.CurrentPrice, i.Quantity); }),
            settings.ShippingFee, settings.FreeShippingThreshold);

        // 2) Reserve stock atomically and write the order in one transaction.
        await using var tx = await _db.Database.BeginTransactionAsync();
        try
        {
            foreach (var item in cart.Items)
            {
                var pid = item.ProductId; var qty = item.Quantity;
                var affected = await _db.Products.Where(p => p.Id == pid && p.IsActive && p.StockQuantity >= qty)
                    .ExecuteUpdateAsync(s => s.SetProperty(p => p.StockQuantity, p => p.StockQuantity - qty));
                if (affected == 0)
                {
                    await tx.RollbackAsync();
                    var name = products.First(x => x.Id == pid).Name;
                    return ServiceResult<Order>.Fail($"Sản phẩm \"{name}\" vừa hết hàng hoặc không đủ số lượng. Vui lòng kiểm tra lại giỏ hàng.");
                }
            }

            var now = DateTime.UtcNow;
            var order = new Order
            {
                UserId = userId, CustomerEmail = email, ReceiverName = input.ReceiverName.Trim(), Phone = input.Phone.Trim(),
                Address = input.Address.Trim(), Notes = string.IsNullOrWhiteSpace(input.Notes) ? null : input.Notes.Trim(),
                Subtotal = pricing.Subtotal, DiscountTotal = pricing.DiscountTotal, ShippingFee = pricing.ShippingFee, Total = pricing.Total,
                Status = OrderStatus.PendingPayment, CreatedUtc = now, UpdatedUtc = now
            };
            for (var attempt = 0; attempt < 5; attempt++)
            {
                order.OrderNumber = OrderNumberGenerator.Generate(now);
                var number = order.OrderNumber;
                if (!await _db.Orders.AnyAsync(o => o.OrderNumber == number)) break;
            }
            foreach (var item in cart.Items)
            {
                var p = products.First(x => x.Id == item.ProductId);
                order.Items.Add(new OrderItem
                {
                    ProductId = p.Id, ProductName = p.Name, ProductSlug = p.Slug, OriginalUnitPrice = p.OriginalPrice,
                    UnitPrice = p.CurrentPrice, Quantity = item.Quantity, SellerUserId = p.OwnerUserId,
                    PlatformFee = p.OwnerUserId == null ? 0 : Math.Round(p.CurrentPrice * item.Quantity * (p.PlatformFeeRate <= 0 ? 0.07m : p.PlatformFeeRate), 0),
                    LineTotal = p.CurrentPrice * item.Quantity
                });
            }
            order.History.Add(new OrderStatusHistory { FromStatus = null, ToStatus = OrderStatus.PendingPayment, ChangedByUserId = userId, ChangedByName = input.ReceiverName.Trim(), ChangedByRole = ActorRole.Customer, Note = "Khách hàng đặt hàng", CreatedUtc = now });

            _db.Orders.Add(order);
            await _db.SaveChangesAsync();
            var cartId = cart.Id;
            await _db.CartItems.Where(i => i.CartId == cartId).ExecuteDeleteAsync();
            await tx.CommitAsync();

            await TrySendAsync(email, $"Đã nhận đơn hàng {order.OrderNumber}",
                $"<p>Cảm ơn bạn đã đặt hàng. Mã đơn hàng: <b>{WebUtility.HtmlEncode(order.OrderNumber)}</b>.</p><p>Vui lòng chuyển khoản {order.Total:N0} ₫ và tải biên lai lên trang đơn hàng để chúng tôi xác nhận.</p>");
            return ServiceResult<Order>.Ok(order);
        }
        catch
        {
            await tx.RollbackAsync();
            throw;
        }
    }

    // ---- cancel -------------------------------------------------------------

    public async Task<ServiceResult> CancelAsync(int orderId, ActorRole actor, string? actorUserId, string actorName, string? reason, string? mustOwnUserId = null)
    {
        var order = await _db.Orders.AsNoTracking().Include(o => o.Items).FirstOrDefaultAsync(o => o.Id == orderId);
        if (order == null || (mustOwnUserId != null && order.UserId != mustOwnUserId)) return ServiceResult.Fail("Không tìm thấy đơn hàng.");
        if (!OrderStateMachine.CanTransition(order.Status, OrderStatus.Cancelled, actor))
            return ServiceResult.Fail("Đơn hàng ở trạng thái hiện tại không thể hủy.");
        if (actor != ActorRole.System && string.IsNullOrWhiteSpace(reason)) return ServiceResult.Fail("Vui lòng nhập lý do hủy đơn.");

        var from = order.Status;
        var wasPaid = OrderStateMachine.IsPaid(from);
        var now = DateTime.UtcNow;
        var text = (reason ?? "Quá hạn thanh toán").Trim();
        if (text.Length > 500) text = text[..500];

        await using var tx = await _db.Database.BeginTransactionAsync();
        var affected = await _db.Orders.Where(o => o.Id == orderId && o.Status == from)
            .ExecuteUpdateAsync(s => s.SetProperty(o => o.Status, OrderStatus.Cancelled)
                                      .SetProperty(o => o.CancelledUtc, (DateTime?)now)
                                      .SetProperty(o => o.CancelReason, text)
                                      .SetProperty(o => o.UpdatedUtc, now));
        if (affected == 0)
        {
            await tx.RollbackAsync();
            return ServiceResult.Fail("Đơn hàng vừa được cập nhật bởi người khác. Vui lòng tải lại trang.");
        }

        // Release the reserved stock (and undo the sales count if the order had been paid).
        foreach (var item in order.Items)
        {
            var pid = item.ProductId; var qty = item.Quantity;
            if (wasPaid)
                await _db.Products.Where(p => p.Id == pid).ExecuteUpdateAsync(s => s.SetProperty(p => p.StockQuantity, p => p.StockQuantity + qty).SetProperty(p => p.SoldCount, p => p.SoldCount - qty));
            else
                await _db.Products.Where(p => p.Id == pid).ExecuteUpdateAsync(s => s.SetProperty(p => p.StockQuantity, p => p.StockQuantity + qty));
        }
        _db.OrderStatusHistory.Add(new OrderStatusHistory { OrderId = orderId, FromStatus = from, ToStatus = OrderStatus.Cancelled, ChangedByUserId = actorUserId, ChangedByName = actorName, ChangedByRole = actor, Note = text, CreatedUtc = now });
        await _db.SaveChangesAsync();
        await tx.CommitAsync();

        if (actor != ActorRole.Customer)
        {
            await _audit.LogAsync("Order.Cancel", "Order", order.OrderNumber, text);
            await TrySendAsync(order.CustomerEmail, $"Đơn hàng {order.OrderNumber} đã bị hủy", $"<p>Đơn hàng <b>{WebUtility.HtmlEncode(order.OrderNumber)}</b> đã được hủy. Lý do: {WebUtility.HtmlEncode(text)}</p>");
        }
        return ServiceResult.Ok();
    }

    // ---- payment proof ------------------------------------------------------

    public async Task<ServiceResult> UploadProofAsync(string userId, string orderNumber, IFormFile file)
    {
        var order = await _db.Orders.Include(o => o.Proofs).FirstOrDefaultAsync(o => o.OrderNumber == orderNumber && o.UserId == userId);
        if (order == null) return ServiceResult.Fail("Không tìm thấy đơn hàng.");
        if (!OrderStateMachine.CanUploadProof(order.Status)) return ServiceResult.Fail("Đơn hàng ở trạng thái hiện tại không thể tải biên lai.");
        if (order.Proofs.Count >= MaxProofsPerOrder) return ServiceResult.Fail("Bạn đã tải lên quá nhiều biên lai cho đơn này. Vui lòng liên hệ cửa hàng.");

        var saved = await _files.SavePrivateImageAsync(file, $"payment-proofs/{order.Id}");
        if (!saved.Succeeded) return ServiceResult.Fail(saved.Error!);

        var from = order.Status; var orderId = order.Id; var now = DateTime.UtcNow;
        try
        {
            await using var tx = await _db.Database.BeginTransactionAsync();
            if (from != OrderStatus.PendingVerification)
            {
                var affected = await _db.Orders.Where(o => o.Id == orderId && (o.Status == OrderStatus.PendingPayment || o.Status == OrderStatus.PaymentRejected))
                    .ExecuteUpdateAsync(s => s.SetProperty(o => o.Status, OrderStatus.PendingVerification).SetProperty(o => o.UpdatedUtc, now));
                if (affected == 0) { await tx.RollbackAsync(); _files.DeletePrivate(saved.Value!.RelativePath); return ServiceResult.Fail("Đơn hàng vừa thay đổi trạng thái. Vui lòng tải lại trang."); }
                _db.OrderStatusHistory.Add(new OrderStatusHistory { OrderId = orderId, FromStatus = from, ToStatus = OrderStatus.PendingVerification, ChangedByUserId = userId, ChangedByName = order.ReceiverName, ChangedByRole = ActorRole.Customer, Note = "Khách hàng tải biên lai chuyển khoản", CreatedUtc = now });
            }
            else
            {
                _db.OrderStatusHistory.Add(new OrderStatusHistory { OrderId = orderId, FromStatus = from, ToStatus = from, ChangedByUserId = userId, ChangedByName = order.ReceiverName, ChangedByRole = ActorRole.Customer, Note = "Khách hàng thay biên lai mới", CreatedUtc = now });
            }
            foreach (var old in order.Proofs.Where(p => p.Status == PaymentProofStatus.Pending)) old.Status = PaymentProofStatus.Superseded;
            _db.PaymentProofs.Add(new PaymentProof
            {
                OrderId = orderId, StoredPath = saved.Value!.RelativePath, ContentType = saved.Value.ContentType, SizeBytes = saved.Value.SizeBytes,
                OriginalFileName = Path.GetFileName(file.FileName) is { Length: > 200 } n ? n[..200] : Path.GetFileName(file.FileName),
                UploadedUtc = now, Status = PaymentProofStatus.Pending
            });
            await _db.SaveChangesAsync();
            await tx.CommitAsync();
        }
        catch
        {
            _files.DeletePrivate(saved.Value!.RelativePath);
            throw;
        }
        return ServiceResult.Ok();
    }

    public async Task<ServiceResult> ApproveAsync(int orderId, string reviewerId, string reviewerName, ActorRole role)
    {
        var order = await _db.Orders.AsNoTracking().Include(o => o.Items).Include(o => o.Proofs).FirstOrDefaultAsync(o => o.Id == orderId);
        if (order == null) return ServiceResult.Fail("Không tìm thấy đơn hàng.");
        if (order.Status != OrderStatus.PendingVerification || !OrderStateMachine.CanTransition(order.Status, OrderStatus.Paid, role))
            return ServiceResult.Fail("Đơn hàng không ở trạng thái chờ xác minh. Có thể đã được xử lý trước đó.");
        var proof = order.Proofs.Where(p => p.Status == PaymentProofStatus.Pending).OrderByDescending(p => p.UploadedUtc).FirstOrDefault();
        if (proof == null) return ServiceResult.Fail("Đơn hàng chưa có biên lai chờ xác minh.");

        var now = DateTime.UtcNow; var proofId = proof.Id;
        await using var tx = await _db.Database.BeginTransactionAsync();
        var affected = await _db.Orders.Where(o => o.Id == orderId && o.Status == OrderStatus.PendingVerification)
            .ExecuteUpdateAsync(s => s.SetProperty(o => o.Status, OrderStatus.Paid).SetProperty(o => o.PaidUtc, (DateTime?)now).SetProperty(o => o.UpdatedUtc, now));
        if (affected == 0)
        {
            await tx.RollbackAsync();
            return ServiceResult.Fail("Đơn hàng đã được xử lý bởi người khác (tránh duyệt trùng).");
        }
        await _db.PaymentProofs.Where(p => p.Id == proofId && p.Status == PaymentProofStatus.Pending)
            .ExecuteUpdateAsync(s => s.SetProperty(p => p.Status, PaymentProofStatus.Approved).SetProperty(p => p.ReviewedByUserId, reviewerId).SetProperty(p => p.ReviewedUtc, (DateTime?)now));
        foreach (var item in order.Items)
        {
            var pid = item.ProductId; var qty = item.Quantity;
            await _db.Products.Where(p => p.Id == pid).ExecuteUpdateAsync(s => s.SetProperty(p => p.SoldCount, p => p.SoldCount + qty));
        }
        _db.OrderStatusHistory.Add(new OrderStatusHistory { OrderId = orderId, FromStatus = OrderStatus.PendingVerification, ToStatus = OrderStatus.Paid, ChangedByUserId = reviewerId, ChangedByName = reviewerName, ChangedByRole = role, Note = "Đã xác minh thanh toán", CreatedUtc = now });
        await _db.SaveChangesAsync();
        await tx.CommitAsync();

        await _audit.LogAsync("Payment.Approve", "Order", order.OrderNumber, $"Số tiền {order.Total:N0} ₫");
        await TrySendAsync(order.CustomerEmail, $"Đã xác nhận thanh toán đơn {order.OrderNumber}", $"<p>Chúng tôi đã nhận được thanh toán cho đơn hàng <b>{WebUtility.HtmlEncode(order.OrderNumber)}</b> và sẽ chuẩn bị hàng cho bạn.</p>");
        return ServiceResult.Ok();
    }

    public async Task<ServiceResult> RejectAsync(int orderId, string reviewerId, string reviewerName, ActorRole role, string reason)
    {
        if (string.IsNullOrWhiteSpace(reason)) return ServiceResult.Fail("Vui lòng nhập lý do từ chối.");
        reason = reason.Trim(); if (reason.Length > 500) reason = reason[..500];

        var order = await _db.Orders.AsNoTracking().Include(o => o.Proofs).FirstOrDefaultAsync(o => o.Id == orderId);
        if (order == null) return ServiceResult.Fail("Không tìm thấy đơn hàng.");
        if (order.Status != OrderStatus.PendingVerification || !OrderStateMachine.CanTransition(order.Status, OrderStatus.PaymentRejected, role))
            return ServiceResult.Fail("Đơn hàng không ở trạng thái chờ xác minh. Có thể đã được xử lý trước đó.");
        var proof = order.Proofs.Where(p => p.Status == PaymentProofStatus.Pending).OrderByDescending(p => p.UploadedUtc).FirstOrDefault();
        if (proof == null) return ServiceResult.Fail("Đơn hàng chưa có biên lai chờ xác minh.");

        var now = DateTime.UtcNow; var proofId = proof.Id;
        await using var tx = await _db.Database.BeginTransactionAsync();
        var affected = await _db.Orders.Where(o => o.Id == orderId && o.Status == OrderStatus.PendingVerification)
            .ExecuteUpdateAsync(s => s.SetProperty(o => o.Status, OrderStatus.PaymentRejected).SetProperty(o => o.UpdatedUtc, now));
        if (affected == 0) { await tx.RollbackAsync(); return ServiceResult.Fail("Đơn hàng đã được xử lý bởi người khác."); }
        await _db.PaymentProofs.Where(p => p.Id == proofId && p.Status == PaymentProofStatus.Pending)
            .ExecuteUpdateAsync(s => s.SetProperty(p => p.Status, PaymentProofStatus.Rejected).SetProperty(p => p.ReviewedByUserId, reviewerId)
                                      .SetProperty(p => p.ReviewedUtc, (DateTime?)now).SetProperty(p => p.RejectionReason, reason));
        _db.OrderStatusHistory.Add(new OrderStatusHistory { OrderId = orderId, FromStatus = OrderStatus.PendingVerification, ToStatus = OrderStatus.PaymentRejected, ChangedByUserId = reviewerId, ChangedByName = reviewerName, ChangedByRole = role, Note = reason, CreatedUtc = now });
        await _db.SaveChangesAsync();
        await tx.CommitAsync();

        await _audit.LogAsync("Payment.Reject", "Order", order.OrderNumber, reason);
        await TrySendAsync(order.CustomerEmail, $"Thanh toán đơn {order.OrderNumber} chưa được xác nhận", $"<p>Biên lai của bạn chưa được chấp nhận. Lý do: {WebUtility.HtmlEncode(reason)}</p><p>Vui lòng tải lên biên lai mới tại trang đơn hàng.</p>");
        return ServiceResult.Ok();
    }

    // ---- fulfilment ---------------------------------------------------------

    public async Task<ServiceResult> AdvanceStatusAsync(int orderId, OrderStatus next, ActorRole actor, string actorUserId, string actorName, string? note)
    {
        if (next is not (OrderStatus.Processing or OrderStatus.Shipped or OrderStatus.Delivered))
            return ServiceResult.Fail("Trạng thái không hợp lệ cho thao tác này.");

        var order = await _db.Orders.AsNoTracking().FirstOrDefaultAsync(o => o.Id == orderId);
        if (order == null) return ServiceResult.Fail("Không tìm thấy đơn hàng.");
        if (!OrderStateMachine.CanTransition(order.Status, next, actor)) return ServiceResult.Fail("Không thể chuyển đơn hàng sang trạng thái này.");

        var from = order.Status; var now = DateTime.UtcNow;
        var cleanNote = string.IsNullOrWhiteSpace(note) ? null : (note.Trim().Length > 500 ? note.Trim()[..500] : note.Trim());
        await using var tx = await _db.Database.BeginTransactionAsync();
        var q = _db.Orders.Where(o => o.Id == orderId && o.Status == from);
        var affected = next switch
        {
            OrderStatus.Shipped => await q.ExecuteUpdateAsync(s => s.SetProperty(o => o.Status, next).SetProperty(o => o.ShippedUtc, (DateTime?)now).SetProperty(o => o.UpdatedUtc, now)),
            OrderStatus.Delivered => await q.ExecuteUpdateAsync(s => s.SetProperty(o => o.Status, next).SetProperty(o => o.DeliveredUtc, (DateTime?)now).SetProperty(o => o.UpdatedUtc, now)),
            _ => await q.ExecuteUpdateAsync(s => s.SetProperty(o => o.Status, next).SetProperty(o => o.UpdatedUtc, now)),
        };
        if (affected == 0) { await tx.RollbackAsync(); return ServiceResult.Fail("Đơn hàng vừa được cập nhật bởi người khác. Vui lòng tải lại trang."); }
        _db.OrderStatusHistory.Add(new OrderStatusHistory { OrderId = orderId, FromStatus = from, ToStatus = next, ChangedByUserId = actorUserId, ChangedByName = actorName, ChangedByRole = actor, Note = cleanNote, CreatedUtc = now });
        await _db.SaveChangesAsync();
        await tx.CommitAsync();

        await _audit.LogAsync("Order.Status", "Order", order.OrderNumber, $"{from} -> {next}");
        if (next is OrderStatus.Shipped or OrderStatus.Delivered)
            await TrySendAsync(order.CustomerEmail, $"Đơn hàng {order.OrderNumber}: {OrderStateMachine.DisplayName(next)}", $"<p>Đơn hàng <b>{WebUtility.HtmlEncode(order.OrderNumber)}</b> hiện ở trạng thái: {OrderStateMachine.DisplayName(next)}.</p>");
        return ServiceResult.Ok();
    }

    // ---- queries ------------------------------------------------------------

    private static IQueryable<OrderListItem> ToListItems(IQueryable<Order> q) =>
        q.Select(o => new OrderListItem
        {
            Id = o.Id, OrderNumber = o.OrderNumber, ReceiverName = o.ReceiverName, Phone = o.Phone, Total = o.Total,
            Status = o.Status, CreatedUtc = o.CreatedUtc, ItemCount = o.Items.Count
        });

    public async Task<PagedResult<OrderListItem>> GetCustomerOrdersAsync(string userId, int page)
    {
        const int size = 10;
        var q = _db.Orders.AsNoTracking().Where(o => o.UserId == userId);
        var total = await q.CountAsync();
        page = Math.Clamp(page, 1, Math.Max(1, (int)Math.Ceiling(total / (double)size)));
        var items = await ToListItems(q.OrderByDescending(o => o.CreatedUtc).Skip((page - 1) * size).Take(size)).ToListAsync();
        return new PagedResult<OrderListItem> { Items = items, Page = page, PageSize = size, TotalItems = total };
    }

    // Always filtered by the signed-in user's id: customers can never read someone else's order.
    public Task<Order?> GetCustomerOrderAsync(string userId, string orderNumber) =>
        _db.Orders.AsNoTracking().Include(o => o.Items).Include(o => o.History).Include(o => o.Proofs)
            .FirstOrDefaultAsync(o => o.OrderNumber == orderNumber && o.UserId == userId);

    public async Task<PagedResult<OrderListItem>> SearchAsync(OrderSearch s)
    {
        const int size = 15;
        var q = _db.Orders.AsNoTracking().AsQueryable();
        if (!string.IsNullOrWhiteSpace(s.Q))
        {
            var term = s.Q.Trim();
            q = q.Where(o => o.OrderNumber.Contains(term) || o.ReceiverName.Contains(term) || o.Phone.Contains(term) || o.CustomerEmail.Contains(term));
        }
        if (s.Status.HasValue) { var st = s.Status.Value; q = q.Where(o => o.Status == st); }
        if (s.From.HasValue) { var f = s.From.Value.Date; q = q.Where(o => o.CreatedUtc >= f); }
        if (s.To.HasValue) { var t = s.To.Value.Date.AddDays(1); q = q.Where(o => o.CreatedUtc < t); }

        var total = await q.CountAsync();
        var page = Math.Clamp(s.Page, 1, Math.Max(1, (int)Math.Ceiling(total / (double)size)));
        var items = await ToListItems(q.OrderByDescending(o => o.CreatedUtc).Skip((page - 1) * size).Take(size)).ToListAsync();
        return new PagedResult<OrderListItem> { Items = items, Page = page, PageSize = size, TotalItems = total };
    }

    public Task<Order?> GetForStaffAsync(int id) =>
        _db.Orders.AsNoTracking().Include(o => o.Items).Include(o => o.History).Include(o => o.Proofs).FirstOrDefaultAsync(o => o.Id == id);

    public async Task<TrackResult?> TrackAsync(string orderNumber, string phone)
    {
        var number = orderNumber.Trim().ToUpperInvariant();
        var order = await _db.Orders.AsNoTracking().Include(o => o.History).FirstOrDefaultAsync(o => o.OrderNumber == number);
        // Both values must match; the response never says which one was wrong.
        if (order == null || DigitsOnly(order.Phone) != DigitsOnly(phone) || DigitsOnly(phone).Length < 9) return null;
        return new TrackResult
        {
            OrderNumber = order.OrderNumber, Status = order.Status, CreatedUtc = order.CreatedUtc, Total = order.Total,
            Timeline = order.History.OrderBy(h => h.CreatedUtc).Where(h => h.FromStatus != h.ToStatus).Select(h => (h.ToStatus, h.CreatedUtc)).ToList()
        };
    }

    public static string DigitsOnly(string s)
    {
        var d = new string(s.Where(char.IsDigit).ToArray());
        return d.StartsWith("84") && d.Length > 9 ? "0" + d[2..] : d;   // +84912... == 0912...
    }

    public async Task<int> CancelExpiredUnpaidAsync(DateTime createdBeforeUtc)
    {
        var ids = await _db.Orders.AsNoTracking().Where(o => o.Status == OrderStatus.PendingPayment && o.CreatedUtc < createdBeforeUtc)
            .Select(o => o.Id).ToListAsync();
        var count = 0;
        foreach (var id in ids)
        {
            var r = await CancelAsync(id, ActorRole.System, null, "Hệ thống", "Quá hạn thanh toán");
            if (r.Succeeded) count++;
        }
        return count;
    }

    private async Task TrySendAsync(string to, string subject, string body)
    {
        try { await _email.SendAsync(to, subject, body); }
        catch (Exception ex) { _log.LogError(ex, "Could not send email '{Subject}' to {To}", subject, to); }   // never fail an order because of email
    }
}
