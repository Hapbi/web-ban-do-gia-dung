using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using NovaShop.Data;
using NovaShop.Models;
using NovaShop.Services;

namespace NovaShop.Controllers;

public class AccountController : Controller
{
    private readonly AppDbContext _db;
    private readonly AuthService _auth;
    public AccountController(AppDbContext db, AuthService auth) { _db = db; _auth = auth; }

    [HttpGet, Route("tai-khoan/dang-nhap")]
    public IActionResult Login(string? returnUrl) => View(new LoginVM { ReturnUrl = returnUrl });

    [HttpPost, Route("tai-khoan/dang-nhap")]
    public async Task<IActionResult> Login(LoginVM vm)
    {
        if (!ModelState.IsValid) return View(vm);
        var e = vm.Email.Trim().ToLower();
        var u = await _db.Users.FirstOrDefaultAsync(x => x.Email.ToLower() == e);
        if (u == null || !VerifyPassword(vm.Password, u.PasswordHash))
        {
            ViewBag.Err = "Sai email hoặc mật khẩu";
            return View(vm);
        }
        if (!u.IsActive)
        {
            ViewBag.Err = "Tài khoản đã bị khóa";
            return View(vm);
        }
        u.LastLoginAt = DateTime.Now;
        await _db.SaveChangesAsync();

        await HttpContext.SignInAsync(CookieAuthenticationDefaults.AuthenticationScheme, _auth.BuildPrincipal(u));

        if (u.Role == "Admin" || u.Role == "Staff") return Redirect("/quan-tri");
        return Redirect(Url.IsLocalUrl(vm.ReturnUrl) ? vm.ReturnUrl! : "/");
    }

    [HttpGet, Route("tai-khoan/dang-ky")]
    public IActionResult Register() => View(new RegisterVM());

    [HttpPost, Route("tai-khoan/dang-ky")]
    public async Task<IActionResult> Register(RegisterVM vm)
    {
        if (!ModelState.IsValid) return View(vm);
        var e = vm.Email.Trim().ToLower();
        if (await _db.Users.AnyAsync(x => x.Email.ToLower() == e))
        {
            ViewBag.Err = "Email đã tồn tại";
            return View(vm);
        }
        var u = new User
        {
            Email = e,
            FullName = vm.FullName.Trim(),
            Phone = vm.Phone.Trim(),
            Role = "Customer",
            PasswordHash = HashPassword(vm.Password)
        };
        _db.Users.Add(u);
        await _db.SaveChangesAsync();

        await HttpContext.SignInAsync(CookieAuthenticationDefaults.AuthenticationScheme, _auth.BuildPrincipal(u));
        return Redirect("/");
    }

    [HttpPost, Route("tai-khoan/dang-xuat")]
    public async Task<IActionResult> Logout()
    {
        await HttpContext.SignOutAsync(CookieAuthenticationDefaults.AuthenticationScheme);
        return Redirect("/");
    }

    [Route("tai-khoan/tu-choi")]
    public IActionResult Denied() => View();

    // Dùng cùng hash với DbInitializer để seed và login đồng bộ
    static string HashPassword(string pwd)
    {
        using var sha = System.Security.Cryptography.SHA256.Create();
        var bytes = System.Text.Encoding.UTF8.GetBytes("NOVA_SHOP_2024_" + pwd);
        return Convert.ToBase64String(sha.ComputeHash(bytes));
    }
    static bool VerifyPassword(string pwd, string hash) => HashPassword(pwd) == hash;
}
