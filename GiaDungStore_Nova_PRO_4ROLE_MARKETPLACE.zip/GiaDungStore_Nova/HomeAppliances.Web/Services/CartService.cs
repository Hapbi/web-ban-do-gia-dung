using System.Security.Claims;
using System.Text.Json;
using Microsoft.EntityFrameworkCore;
using HomeAppliances.Web.Data;
using HomeAppliances.Web.Domain;
using HomeAppliances.Web.Models.Entities;
using HomeAppliances.Web.Models.ViewModels;

namespace HomeAppliances.Web.Services;

public interface ICartService
{
    Task<CartViewModel> GetAsync();
    Task<int> CountAsync();
    Task<ServiceResult> AddAsync(int productId, int quantity);
    Task<ServiceResult> SetQuantityAsync(int productId, int quantity);
    Task<ServiceResult> RemoveAsync(int productId);
    Task ClearAsync();
    /// <summary>Moves the anonymous (session) cart into the user's saved cart after login.</summary>
    Task MergeGuestCartAsync(string userId);
}

/// <summary>
/// Signed-in users have a database cart; guests use the session. Prices and stock are always read
/// from the database here, never from anything the browser submits.
/// </summary>
public class CartService : ICartService
{
    private const string GuestKey = "guest_cart";
    private const int MaxPerLine = 20;
    private readonly ApplicationDbContext _db;
    private readonly IHttpContextAccessor _http;
    private readonly ISettingsService _settings;

    public CartService(ApplicationDbContext db, IHttpContextAccessor http, ISettingsService settings) { _db = db; _http = http; _settings = settings; }

    private ISession Session => _http.HttpContext!.Session;
    private string? UserId => _http.HttpContext?.User.Identity?.IsAuthenticated == true ? _http.HttpContext.User.FindFirstValue(ClaimTypes.NameIdentifier) : null;

    // ---- storage ------------------------------------------------------------

    private Dictionary<int, int> LoadGuest()
    {
        var json = Session.GetString(GuestKey);
        if (string.IsNullOrEmpty(json)) return new();
        try { return JsonSerializer.Deserialize<Dictionary<int, int>>(json) ?? new(); } catch { return new(); }
    }

    private void SaveGuest(Dictionary<int, int> d) => Session.SetString(GuestKey, JsonSerializer.Serialize(d));

    private async Task<Cart> GetOrCreateDbCartAsync(string userId)
    {
        var cart = await _db.Carts.Include(c => c.Items).FirstOrDefaultAsync(c => c.UserId == userId);
        if (cart != null) return cart;
        cart = new Cart { UserId = userId };
        _db.Carts.Add(cart);
        try { await _db.SaveChangesAsync(); }
        catch (DbUpdateException)   // concurrent request created it first
        {
            _db.ChangeTracker.Clear();
            cart = await _db.Carts.Include(c => c.Items).FirstAsync(c => c.UserId == userId);
        }
        return cart;
    }

    private async Task<Dictionary<int, int>> LoadQuantitiesAsync()
    {
        var uid = UserId;
        if (uid == null) return LoadGuest();
        var cart = await _db.Carts.AsNoTracking().Include(c => c.Items).FirstOrDefaultAsync(c => c.UserId == uid);
        return cart?.Items.ToDictionary(i => i.ProductId, i => i.Quantity) ?? new();
    }

    private async Task SetQtyAsync(int productId, int qty)
    {
        var uid = UserId;
        if (uid == null)
        {
            var g = LoadGuest();
            if (qty <= 0) g.Remove(productId); else g[productId] = qty;
            SaveGuest(g);
            return;
        }
        var cart = await GetOrCreateDbCartAsync(uid);
        var item = cart.Items.FirstOrDefault(i => i.ProductId == productId);
        if (qty <= 0) { if (item != null) _db.CartItems.Remove(item); }
        else if (item == null) cart.Items.Add(new CartItem { ProductId = productId, Quantity = qty });
        else item.Quantity = qty;
        cart.UpdatedUtc = DateTime.UtcNow;
        await _db.SaveChangesAsync();
    }

    // ---- operations ---------------------------------------------------------

    public async Task<int> CountAsync() => (await LoadQuantitiesAsync()).Values.Sum();

    public async Task<CartViewModel> GetAsync()
    {
        var qty = await LoadQuantitiesAsync();
        var settings = await _settings.GetWebsiteAsync();
        var vm = new CartViewModel { FreeShippingThreshold = settings.FreeShippingThreshold };
        if (qty.Count == 0) return vm;

        var ids = qty.Keys.ToList();
        var products = await _db.Products.AsNoTracking().Include(p => p.Category).Include(p => p.Images)
            .Where(p => ids.Contains(p.Id) && p.IsActive).ToListAsync();

        foreach (var (id, q) in qty)
        {
            var p = products.FirstOrDefault(x => x.Id == id);
            if (p == null) { await SetQtyAsync(id, 0); continue; }   // product was removed: drop the line
            vm.Lines.Add(new CartLineViewModel
            {
                ProductId = p.Id, Slug = p.Slug, Name = p.Name, Brand = p.Brand, CategorySlug = p.Category!.Slug,
                ImageUrl = p.Images.OrderByDescending(i => i.IsPrimary).ThenBy(i => i.SortOrder).Select(i => i.Path).FirstOrDefault(),
                OriginalPrice = p.OriginalPrice, UnitPrice = p.CurrentPrice, Quantity = q, StockQuantity = p.StockQuantity
            });
        }
        var pr = PricingCalculator.Calculate(vm.Lines.Select(l => new PricingLine(l.OriginalPrice, l.UnitPrice, l.Quantity)), settings.ShippingFee, settings.FreeShippingThreshold);
        vm.Subtotal = pr.Subtotal; vm.DiscountTotal = pr.DiscountTotal; vm.ShippingFee = pr.ShippingFee; vm.Total = pr.Total;
        return vm;
    }

    public async Task<ServiceResult> AddAsync(int productId, int quantity)
    {
        if (quantity < 1) quantity = 1;
        var p = await _db.Products.AsNoTracking().FirstOrDefaultAsync(x => x.Id == productId && x.IsActive);
        if (p == null) return ServiceResult.Fail("Sản phẩm không tồn tại hoặc đã ngừng bán.");
        if (UserId != null && p.OwnerUserId == UserId)
            return ServiceResult.Fail("Bạn không thể mua chính sản phẩm do mình đăng bán.");
        if (p.StockQuantity <= 0) return ServiceResult.Fail("Sản phẩm đã hết hàng.");

        var existing = (await LoadQuantitiesAsync()).GetValueOrDefault(productId);
        var wanted = existing + quantity;
        var limit = Math.Min(p.StockQuantity, MaxPerLine);
        if (wanted > limit)
            return ServiceResult.Fail(existing >= limit
                ? $"Bạn đã có {existing} sản phẩm này trong giỏ, đạt mức tối đa có thể mua ({limit})."
                : $"Chỉ có thể mua tối đa {limit} sản phẩm này (đã có {existing} trong giỏ).");

        await SetQtyAsync(productId, wanted);
        return ServiceResult.Ok();
    }

    public async Task<ServiceResult> SetQuantityAsync(int productId, int quantity)
    {
        if (quantity <= 0) { await SetQtyAsync(productId, 0); return ServiceResult.Ok(); }
        var p = await _db.Products.AsNoTracking().FirstOrDefaultAsync(x => x.Id == productId && x.IsActive);
        if (p == null) { await SetQtyAsync(productId, 0); return ServiceResult.Fail("Sản phẩm không còn bán và đã được xóa khỏi giỏ."); }
        var limit = Math.Min(p.StockQuantity, MaxPerLine);
        if (quantity > limit)
        {
            await SetQtyAsync(productId, Math.Max(limit, 0));
            return ServiceResult.Fail($"Chỉ còn {limit} sản phẩm \"{p.Name}\". Số lượng đã được điều chỉnh.");
        }
        await SetQtyAsync(productId, quantity);
        return ServiceResult.Ok();
    }

    public async Task<ServiceResult> RemoveAsync(int productId) { await SetQtyAsync(productId, 0); return ServiceResult.Ok(); }

    public async Task ClearAsync()
    {
        var uid = UserId;
        if (uid == null) { Session.Remove(GuestKey); return; }
        await _db.CartItems.Where(i => i.Cart!.UserId == uid).ExecuteDeleteAsync();
    }

    public async Task MergeGuestCartAsync(string userId)
    {
        var guest = LoadGuest();
        if (guest.Count == 0) return;
        var cart = await GetOrCreateDbCartAsync(userId);
        var ids = guest.Keys.ToList();
        var products = await _db.Products.AsNoTracking().Where(p => ids.Contains(p.Id) && p.IsActive && p.StockQuantity > 0).ToListAsync();
        foreach (var p in products)
        {
            var limit = Math.Min(p.StockQuantity, MaxPerLine);
            var item = cart.Items.FirstOrDefault(i => i.ProductId == p.Id);
            if (item == null) cart.Items.Add(new CartItem { ProductId = p.Id, Quantity = Math.Min(guest[p.Id], limit) });
            else item.Quantity = Math.Min(item.Quantity + guest[p.Id], limit);   // never exceed stock when merging
        }
        cart.UpdatedUtc = DateTime.UtcNow;
        await _db.SaveChangesAsync();
        Session.Remove(GuestKey);
    }
}
