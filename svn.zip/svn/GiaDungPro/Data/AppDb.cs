using CuaHangGiaDungPro.Models;
using Microsoft.EntityFrameworkCore;

namespace CuaHangGiaDungPro.Data;

public class AppDb : DbContext
{
    public AppDb(DbContextOptions<AppDb> o) : base(o) { }

    public DbSet<NguoiDung>      NguoiDungs      => Set<NguoiDung>();
    public DbSet<DanhMuc>        DanhMucs        => Set<DanhMuc>();
    public DbSet<SanPham>        SanPhams        => Set<SanPham>();
    public DbSet<DanhGia>        DanhGias        => Set<DanhGia>();
    public DbSet<YeuThich>       YeuThichs       => Set<YeuThich>();
    public DbSet<DonHang>        DonHangs        => Set<DonHang>();
    public DbSet<ChiTietDonHang> ChiTietDonHangs => Set<ChiTietDonHang>();
    public DbSet<Banner>         Banners         => Set<Banner>();
    public DbSet<BaiViet>        BaiViets        => Set<BaiViet>();
    public DbSet<LienHe>         LienHes         => Set<LienHe>();
    public DbSet<CauHinh>        CauHinhs        => Set<CauHinh>();
    public DbSet<NhatKy>         NhatKys         => Set<NhatKy>();

    protected override void OnModelCreating(ModelBuilder b)
    {
        b.Entity<NguoiDung>().HasIndex(x => x.Email).IsUnique();
        b.Entity<DonHang>().HasIndex(x => x.MaDon).IsUnique();
        b.Entity<DonHang>()
            .HasOne(x => x.NguoiDung).WithMany()
            .HasForeignKey(x => x.NguoiDungId).OnDelete(DeleteBehavior.SetNull);
        b.Entity<ChiTietDonHang>().HasOne<DonHang>()
            .WithMany(x => x.ChiTiet).HasForeignKey(x => x.DonHangId)
            .OnDelete(DeleteBehavior.Cascade);
        b.Entity<SanPham>().HasOne(x => x.DanhMuc)
            .WithMany(x => x.DanhSachSanPham).HasForeignKey(x => x.DanhMucId)
            .OnDelete(DeleteBehavior.Restrict);
        b.Entity<DanhGia>().HasOne(x => x.SanPham)
            .WithMany(x => x.DanhSachDanhGia).HasForeignKey(x => x.SanPhamId)
            .OnDelete(DeleteBehavior.Cascade);
        b.Entity<DanhGia>().HasOne(x => x.NguoiDung)
            .WithMany().HasForeignKey(x => x.NguoiDungId)
            .OnDelete(DeleteBehavior.Cascade);
        b.Entity<DanhGia>().HasIndex(x => new { x.NguoiDungId, x.SanPhamId }).IsUnique();
        b.Entity<YeuThich>().HasIndex(x => new { x.NguoiDungId, x.SanPhamId }).IsUnique();
        b.Entity<YeuThich>().HasOne(x => x.SanPham)
            .WithMany().HasForeignKey(x => x.SanPhamId).OnDelete(DeleteBehavior.Cascade);
    }
}
