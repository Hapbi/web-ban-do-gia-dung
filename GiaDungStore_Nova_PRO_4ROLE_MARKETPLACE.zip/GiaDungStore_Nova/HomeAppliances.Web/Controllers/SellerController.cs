using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using HomeAppliances.Web.Data;
using HomeAppliances.Web.Domain;
using HomeAppliances.Web.Models.Entities;
using HomeAppliances.Web.Models.ViewModels;

namespace HomeAppliances.Web.Controllers;

[Authorize(Roles = "Customer")]
[Route("ban-hang")]
public class SellerController : Controller
{
    private readonly ApplicationDbContext _db;
    public SellerController(ApplicationDbContext db) => _db = db;

    [HttpGet("")]
    public async Task<IActionResult> Index()
    {
        var uid = User.FindFirst(System.Security.Claims.ClaimTypes.NameIdentifier)?.Value!;
        var listings = await _db.Products.AsNoTracking()
            .Where(p => p.OwnerUserId == uid && p.IsMarketplaceListing)
            .OrderByDescending(p => p.CreatedUtc)
            .Select(p => new SellerListingRow { Id=p.Id, Name=p.Name, Price=p.CurrentPrice, StockQuantity=p.StockQuantity, IsActive=p.IsActive, ListingStatus=p.ListingStatus, CreatedUtc=p.CreatedUtc })
            .ToListAsync();
        return View(new SellerDashboardViewModel
        {
            Listings = listings,
            PendingCount = listings.Count(x => x.ListingStatus == 0),
            ApprovedCount = listings.Count(x => x.ListingStatus == 1 && x.IsActive),
            PlatformFeeRate = 0.07m
        });
    }

    [HttpGet("dang-san-pham")]
    public async Task<IActionResult> Create()
    {
        return View(await BuildVmAsync(new SellerListingCreateViewModel()));
    }

    [HttpPost("dang-san-pham")]
    public async Task<IActionResult> Create(SellerListingCreateViewModel vm)
    {
        if (!ModelState.IsValid) return View(await BuildVmAsync(vm));
        var uid = User.FindFirst(System.Security.Claims.ClaimTypes.NameIdentifier)?.Value!;
        var cat = await _db.Categories.FirstOrDefaultAsync(c => c.Id == vm.CategoryId && c.IsActive);
        if (cat == null) { ModelState.AddModelError(nameof(vm.CategoryId), "Danh mục không hợp lệ."); return View(await BuildVmAsync(vm)); }

        var slug = Domain.SlugHelper.Slugify(vm.Name) + "-" + Guid.NewGuid().ToString("N")[..6];
        var product = new Product
        {
            Name = vm.Name.Trim(), Slug = slug, Description = vm.Description.Trim(), Brand = vm.Brand.Trim(),
            CategoryId = vm.CategoryId, OriginalPrice = vm.Price, StockQuantity = vm.StockQuantity,
            OwnerUserId = uid, IsMarketplaceListing = true, ListingStatus = 0, IsActive = false, PlatformFeeRate = 0.07m
        };
        if (!string.IsNullOrWhiteSpace(vm.ImageUrl))
            product.Images.Add(new ProductImage { Path = vm.ImageUrl.Trim(), IsPrimary = true, SortOrder = 0 });
        _db.Products.Add(product);
        await _db.SaveChangesAsync();
        TempData["Success"] = "Đã gửi sản phẩm. Nhân viên sẽ duyệt trước khi sản phẩm xuất hiện trên cửa hàng.";
        return RedirectToAction(nameof(Index));
    }

    private async Task<SellerListingCreateViewModel> BuildVmAsync(SellerListingCreateViewModel vm)
    {
        vm.Categories = await _db.Categories.AsNoTracking().Where(c => c.IsActive).OrderBy(c => c.DisplayOrder).ThenBy(c => c.Name)
            .Select(c => new SelectListItem(c.Name, c.Id.ToString(), c.Id == vm.CategoryId)).ToListAsync();
        return vm;
    }
}
