using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using NovaShop.Data;
using NovaShop.Models;

namespace NovaShop.Controllers;

public class HomeController : Controller
{
    private readonly AppDbContext _db;
    public HomeController(AppDbContext db) => _db = db;

    public async Task<IActionResult> Index()
    {
        var q = _db.Products.Include(p => p.Images).Include(p => p.Reviews).Include(p => p.Brand).Include(p => p.Category)
            .Where(p => p.IsActive && (!p.IsMarketplaceListing || p.ListingStatus == ListingStatus.Approved));

        var vm = new HomeVM
        {
            Featured = await q.Where(p => p.IsFeatured).OrderByDescending(p => p.SoldCount).Take(8).ToListAsync(),
            NewArrivals = await q.OrderByDescending(p => p.CreatedAt).Take(8).ToListAsync(),
            BestSellers = await q.OrderByDescending(p => p.SoldCount).Take(8).ToListAsync(),
            FlashSale = await q.Where(p => p.SalePrice != null && p.SalePrice < p.OriginalPrice)
                .OrderByDescending(p => (p.OriginalPrice - p.SalePrice) / p.OriginalPrice).Take(6).ToListAsync(),
            Categories = await _db.Categories.Where(c => c.IsActive).OrderBy(c => c.DisplayOrder).ToListAsync(),
            Brands = await _db.Brands.Where(b => b.IsActive).ToListAsync(),
            LatestPosts = await _db.BlogPosts.Where(b => b.IsPublished).OrderByDescending(b => b.PublishedAt).Take(3).ToListAsync(),
            Banners = await _db.Banners.Where(b => b.IsActive && b.Position == "home-top").OrderBy(b => b.SortOrder).ToListAsync()
        };
        return View(vm);
    }

    [Route("loi")]
    public IActionResult Error() => View();

    [Route("khong-tim-thay")]
    public IActionResult NotFound404() { Response.StatusCode = 404; return View(); }
}
