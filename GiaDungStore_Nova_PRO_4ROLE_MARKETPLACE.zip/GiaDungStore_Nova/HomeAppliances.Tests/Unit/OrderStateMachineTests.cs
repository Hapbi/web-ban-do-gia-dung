using HomeAppliances.Web.Domain;
using Xunit;

namespace HomeAppliances.Tests.Unit;

public class OrderStateMachineTests
{
    [Theory]
    [InlineData(OrderStatus.PendingPayment, OrderStatus.PendingVerification, ActorRole.Customer, true)]
    [InlineData(OrderStatus.PendingVerification, OrderStatus.Paid, ActorRole.Admin, true)]
    [InlineData(OrderStatus.PendingVerification, OrderStatus.Paid, ActorRole.Employee, true)]
    [InlineData(OrderStatus.PendingVerification, OrderStatus.PaymentRejected, ActorRole.Employee, true)]
    [InlineData(OrderStatus.PaymentRejected, OrderStatus.PendingVerification, ActorRole.Customer, true)]
    [InlineData(OrderStatus.Paid, OrderStatus.Processing, ActorRole.Employee, true)]
    [InlineData(OrderStatus.Processing, OrderStatus.Shipped, ActorRole.Employee, true)]
    [InlineData(OrderStatus.Shipped, OrderStatus.Delivered, ActorRole.Admin, true)]
    public void Allows_the_normal_workflow(OrderStatus from, OrderStatus to, ActorRole actor, bool expected) =>
        Assert.Equal(expected, OrderStateMachine.CanTransition(from, to, actor));

    [Theory]
    [InlineData(OrderStatus.PendingPayment, OrderStatus.Paid, ActorRole.Admin)]            // cannot skip verification
    [InlineData(OrderStatus.PendingPayment, OrderStatus.Shipped, ActorRole.Admin)]
    [InlineData(OrderStatus.PendingVerification, OrderStatus.Paid, ActorRole.Customer)]    // customers cannot approve their own payment
    [InlineData(OrderStatus.PendingVerification, OrderStatus.Processing, ActorRole.Admin)]
    [InlineData(OrderStatus.Paid, OrderStatus.Shipped, ActorRole.Employee)]                // must pass Processing first
    [InlineData(OrderStatus.Paid, OrderStatus.Processing, ActorRole.Customer)]
    [InlineData(OrderStatus.Delivered, OrderStatus.Cancelled, ActorRole.Admin)]            // final states stay final
    [InlineData(OrderStatus.Cancelled, OrderStatus.PendingPayment, ActorRole.Admin)]
    [InlineData(OrderStatus.Cancelled, OrderStatus.Paid, ActorRole.Admin)]
    public void Rejects_illegal_transitions(OrderStatus from, OrderStatus to, ActorRole actor) =>
        Assert.False(OrderStateMachine.CanTransition(from, to, actor));

    [Fact]
    public void Customers_can_cancel_only_unpaid_orders()
    {
        Assert.True(OrderStateMachine.CanTransition(OrderStatus.PendingPayment, OrderStatus.Cancelled, ActorRole.Customer));
        Assert.True(OrderStateMachine.CanTransition(OrderStatus.PendingVerification, OrderStatus.Cancelled, ActorRole.Customer));
        Assert.True(OrderStateMachine.CanTransition(OrderStatus.PaymentRejected, OrderStatus.Cancelled, ActorRole.Customer));
        Assert.False(OrderStateMachine.CanTransition(OrderStatus.Paid, OrderStatus.Cancelled, ActorRole.Customer));
        Assert.False(OrderStateMachine.CanTransition(OrderStatus.Processing, OrderStatus.Cancelled, ActorRole.Customer));
    }

    [Fact]
    public void Only_admins_can_cancel_paid_orders()
    {
        Assert.True(OrderStateMachine.CanTransition(OrderStatus.Paid, OrderStatus.Cancelled, ActorRole.Admin));
        Assert.False(OrderStateMachine.CanTransition(OrderStatus.Paid, OrderStatus.Cancelled, ActorRole.Employee));
        Assert.False(OrderStateMachine.CanTransition(OrderStatus.Shipped, OrderStatus.Cancelled, ActorRole.Admin));
    }

    [Fact]
    public void Revenue_statuses_are_exactly_the_verified_ones()
    {
        foreach (var s in Enum.GetValues<OrderStatus>())
        {
            var expected = s is OrderStatus.Paid or OrderStatus.Processing or OrderStatus.Shipped or OrderStatus.Delivered;
            Assert.Equal(expected, OrderStateMachine.IsPaid(s));
        }
        Assert.False(OrderStateMachine.IsPaid(OrderStatus.PendingVerification));
        Assert.False(OrderStateMachine.IsPaid(OrderStatus.Cancelled));
        Assert.False(OrderStateMachine.IsPaid(OrderStatus.PaymentRejected));
    }

    [Fact]
    public void Proof_upload_is_allowed_only_before_payment_is_verified()
    {
        Assert.True(OrderStateMachine.CanUploadProof(OrderStatus.PendingPayment));
        Assert.True(OrderStateMachine.CanUploadProof(OrderStatus.PaymentRejected));
        Assert.True(OrderStateMachine.CanUploadProof(OrderStatus.PendingVerification));
        Assert.False(OrderStateMachine.CanUploadProof(OrderStatus.Paid));
        Assert.False(OrderStateMachine.CanUploadProof(OrderStatus.Cancelled));
    }

    [Fact]
    public void Employees_get_fulfilment_steps_but_never_payment_or_cancel_after_payment()
    {
        var next = OrderStateMachine.AllowedNext(OrderStatus.Paid, ActorRole.Employee);
        Assert.Contains(OrderStatus.Processing, next);
        Assert.DoesNotContain(OrderStatus.Cancelled, next);
    }

    [Fact]
    public void Every_status_has_a_vietnamese_label()
    {
        foreach (var s in Enum.GetValues<OrderStatus>()) Assert.NotEqual(s.ToString(), OrderStateMachine.DisplayName(s));
    }
}
