using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using NovaShop.Data;
using NovaShop.Models;

namespace NovaShop.Controllers;

public class BlogController : Controller
{
    private readonly AppDbContext _db;
    public BlogController(AppDbContext db) => _db = db;

    [Route("bai-viet")]
    public async Task<IActionResult> Index()
    {
        var posts = await _db.BlogPosts.Where(p => p.IsPublished)
            .OrderByDescending(p => p.PublishedAt).Take(30).ToListAsync();
        return View(posts);
    }

    [Route("bai-viet/{slug}")]
    public async Task<IActionResult> Detail(string slug)
    {
        var p = await _db.BlogPosts.FirstOrDefaultAsync(b => b.Slug == slug && b.IsPublished);
        if (p == null) return NotFound();
        p.ViewCount++;
        await _db.SaveChangesAsync();
        ViewBag.Recent = await _db.BlogPosts.Where(b => b.IsPublished && b.Id != p.Id)
            .OrderByDescending(b => b.PublishedAt).Take(3).ToListAsync();
        return View(p);
    }
}
