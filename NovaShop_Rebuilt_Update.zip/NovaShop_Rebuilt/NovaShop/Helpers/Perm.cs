namespace NovaShop.Helpers;

// Quyền chức năng cho Staff (Admin luôn có tất cả).
// "" = chưa cấu hình -> dùng Perm.Staff mặc định
// "-" = Admin đã chủ động tắt hết
// "a,b" = chỉ các quyền được liệt kê
public record PermInfo(string Key, string Label, string Group);

public static class Perm
{
    public const string None = "-";

    public static readonly PermInfo[] All =
    {
        new("revenue.view",    "Xem doanh thu trên Dashboard",         "Dashboard"),
        new("stock.view",      "Xem tồn kho trên Dashboard",           "Dashboard"),
        new("product.manage",  "Xem / thêm / sửa / ẩn sản phẩm",       "Sản phẩm"),
        new("price.set",       "Đổi giá sản phẩm",                     "Sản phẩm"),
        new("product.delete",  "Xóa vĩnh viễn sản phẩm",               "Sản phẩm"),
        new("taxonomy.manage", "Danh mục · Thương hiệu · Tag",         "Sản phẩm"),
        new("marketplace.manage", "Duyệt / từ chối listing",           "Sản phẩm"),
        new("order.view",      "Xem & in đơn hàng",                    "Bán hàng"),
        new("order.status",    "Đổi trạng thái / hủy đơn hàng",        "Bán hàng"),
        new("payment.verify",  "Xác minh thanh toán chuyển khoản",     "Bán hàng"),
        new("post.manage",     "Quản lý bài viết",                     "Nội dung & khách hàng"),
        new("contact.manage",  "Xử lý liên hệ & phản ánh",             "Nội dung & khách hàng"),
        new("banner.manage",   "Quản lý banner trang chủ",             "Nội dung & khách hàng"),
        new("report.view",     "Xem báo cáo vận hành",                 "Báo cáo & hệ thống"),
        new("stats.view",      "Xem thống kê & xuất CSV doanh thu",    "Báo cáo & hệ thống"),
        new("settings.manage", "Cấu hình website / QR thanh toán",     "Báo cáo & hệ thống"),
        new("log.view",        "Xem nhật ký hệ thống",                 "Báo cáo & hệ thống"),
    };

    public static readonly string[] Keys = All.Select(x => x.Key).ToArray();

    public static readonly string[] Staff =
    {
        "product.manage", "order.view", "order.status", "revenue.view", "stock.view",
        "post.manage", "contact.manage", "report.view"
    };

    public static readonly string[] Backoffice = { "Admin", "Staff" };

    public static string[] Parse(string stored) =>
        (stored ?? "").Split(',', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries)
            .Where(Keys.Contains).Distinct().ToArray();

    public static string[] Effective(string role, string stored)
    {
        if (role == "Admin") return Keys;
        if (role != "Staff") return Array.Empty<string>();
        var s = (stored ?? "").Trim();
        if (s == "") return Staff;
        if (s == None) return Array.Empty<string>();
        return Parse(s);
    }

    public static string Serialize(IEnumerable<string> keys)
    {
        var list = Keys.Where(k => (keys ?? Array.Empty<string>()).Contains(k)).ToArray();
        return list.Length == 0 ? None : string.Join(",", list);
    }
}
