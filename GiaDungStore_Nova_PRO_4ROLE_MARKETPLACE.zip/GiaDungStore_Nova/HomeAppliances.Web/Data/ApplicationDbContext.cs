using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using HomeAppliances.Web.Models.Entities;

namespace HomeAppliances.Web.Data;

public class ApplicationDbContext : IdentityDbContext<ApplicationUser>
{
    public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options) : base(options) { }

    public DbSet<Category> Categories => Set<Category>();
    public DbSet<Product> Products => Set<Product>();
    public DbSet<ProductImage> ProductImages => Set<ProductImage>();
    public DbSet<ProductSpecification> ProductSpecifications => Set<ProductSpecification>();
    public DbSet<Cart> Carts => Set<Cart>();
    public DbSet<CartItem> CartItems => Set<CartItem>();
    public DbSet<Order> Orders => Set<Order>();
    public DbSet<OrderItem> OrderItems => Set<OrderItem>();
    public DbSet<OrderStatusHistory> OrderStatusHistory => Set<OrderStatusHistory>();
    public DbSet<PaymentProof> PaymentProofs => Set<PaymentProof>();
    public DbSet<BankTransferSettings> BankTransferSettings => Set<BankTransferSettings>();
    public DbSet<WebsiteSettings> WebsiteSettings => Set<WebsiteSettings>();
    public DbSet<Banner> Banners => Set<Banner>();
    public DbSet<ShippingAddress> ShippingAddresses => Set<ShippingAddress>();
    public DbSet<AuditLog> AuditLogs => Set<AuditLog>();
    public DbSet<ContactMessage> ContactMessages => Set<ContactMessage>();

    protected override void OnModelCreating(ModelBuilder b)
    {
        base.OnModelCreating(b);

        // Catalog: a category with products cannot be deleted; deactivate it instead.
        b.Entity<Product>().HasOne(p => p.Category).WithMany(c => c.Products)
            .HasForeignKey(p => p.CategoryId).OnDelete(DeleteBehavior.Restrict);
        b.Entity<Product>().HasOne(p => p.OwnerUser).WithMany()
            .HasForeignKey(p => p.OwnerUserId).OnDelete(DeleteBehavior.SetNull);

        // Order history must survive: products and users referenced by orders cannot be deleted.
        b.Entity<OrderItem>().HasOne(i => i.Product).WithMany()
            .HasForeignKey(i => i.ProductId).OnDelete(DeleteBehavior.Restrict);
        b.Entity<Order>().HasOne(o => o.User).WithMany()
            .HasForeignKey(o => o.UserId).OnDelete(DeleteBehavior.Restrict);

        // Order children are owned by the order.
        b.Entity<OrderItem>().HasOne(i => i.Order).WithMany(o => o.Items)
            .HasForeignKey(i => i.OrderId).OnDelete(DeleteBehavior.Cascade);
        b.Entity<OrderStatusHistory>().HasOne(h => h.Order).WithMany(o => o.History)
            .HasForeignKey(h => h.OrderId).OnDelete(DeleteBehavior.Cascade);
        b.Entity<PaymentProof>().HasOne(p => p.Order).WithMany(o => o.Proofs)
            .HasForeignKey(p => p.OrderId).OnDelete(DeleteBehavior.Cascade);

        // Carts and addresses go away with their user.
        b.Entity<Cart>().HasOne(c => c.User).WithMany()
            .HasForeignKey(c => c.UserId).OnDelete(DeleteBehavior.Cascade);
        b.Entity<CartItem>().HasOne(i => i.Cart).WithMany(c => c.Items)
            .HasForeignKey(i => i.CartId).OnDelete(DeleteBehavior.Cascade);
        b.Entity<CartItem>().HasOne(i => i.Product).WithMany()
            .HasForeignKey(i => i.ProductId).OnDelete(DeleteBehavior.Cascade);
        b.Entity<ShippingAddress>().HasOne(a => a.User).WithMany()
            .HasForeignKey(a => a.UserId).OnDelete(DeleteBehavior.Cascade);
    }
}
