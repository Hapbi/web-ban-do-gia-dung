(function () {
    'use strict';

    // ============ TOAST auto dismiss ============
    document.querySelectorAll('[data-toast]').forEach(t => {
        setTimeout(() => { t.style.animation = 'fadeOut .35s ease forwards'; setTimeout(() => t.remove(), 350); }, 5000);
    });

    // ============ Quantity stepper ============
    document.querySelectorAll('.qty-stepper').forEach(wrap => {
        const input = wrap.querySelector('input');
        const minus = wrap.querySelector('[data-qty-minus]');
        const plus  = wrap.querySelector('[data-qty-plus]');
        if (!input) return;
        const sync = () => {
            const v = parseInt(input.value) || 1;
            document.querySelectorAll('[data-qty-field]').forEach(f => f.value = v);
        };
        minus?.addEventListener('click', () => {
            const v = Math.max(1, (parseInt(input.value) || 1) - 1);
            input.value = v; sync();
        });
        plus?.addEventListener('click', () => {
            const v = Math.min(parseInt(input.max) || 99, (parseInt(input.value) || 1) + 1);
            input.value = v; sync();
        });
        input.addEventListener('input', sync);
        sync();
    });

    // ============ Cart bump animation after add ============
    const cartBtn = document.querySelector('[data-cart-btn]');
    if (cartBtn) {
        document.querySelectorAll('form[action="/gio-hang/them"]').forEach(f => {
            f.addEventListener('submit', () => {
                cartBtn.classList.add('bump');
                setTimeout(() => cartBtn.classList.remove('bump'), 600);
            });
        });
    }

    // ============ Scroll reveal ============
    const io = ('IntersectionObserver' in window) ? new IntersectionObserver(entries => {
        entries.forEach(e => { if (e.isIntersecting) { e.target.classList.add('on'); io.unobserve(e.target); } });
    }, { threshold: 0.1 }) : null;
    if (io) {
        document.querySelectorAll('.sec, .pcard, .stat-card, .card, .blog-card').forEach(el => {
            el.classList.add('reveal'); io.observe(el);
        });
    }

    // ============ Notification polling ============
    const notifBadge = document.querySelector('[data-notif-count]');
    if (notifBadge) {
        const poll = () => {
            fetch('/api/thong-bao/dem').then(r => r.json()).then(d => {
                if (d.count > 0) { notifBadge.textContent = d.count; notifBadge.style.display = ''; }
                else { notifBadge.style.display = 'none'; }
            }).catch(() => {});
        };
        setInterval(poll, 30000);
    }

    // ============ Auto-submit select (admin filters) ============
    document.querySelectorAll('select[data-autosubmit]').forEach(s => {
        s.addEventListener('change', () => s.form?.submit());
    });

    // ============ Confirm data-confirm ============
    document.querySelectorAll('[data-confirm]').forEach(el => {
        el.addEventListener('click', e => {
            if (!confirm(el.dataset.confirm)) { e.preventDefault(); }
        });
    });

    // ============ Smooth scroll for anchors ============
    document.querySelectorAll('a[href^="#"]').forEach(a => {
        a.addEventListener('click', e => {
            const t = document.querySelector(a.getAttribute('href'));
            if (t) { e.preventDefault(); t.scrollIntoView({ behavior: 'smooth', block: 'start' }); }
        });
    });

    // ============ Price input formatting (dots) ============
    document.querySelectorAll('input[data-money]').forEach(inp => {
        const fmt = () => {
            const digits = inp.value.replace(/\D/g, '');
            inp.value = digits ? Number(digits).toLocaleString('vi-VN') : '';
        };
        inp.addEventListener('blur', fmt);
        inp.addEventListener('input', () => {
            const digits = inp.value.replace(/\D/g, '');
            inp.dataset.raw = digits;
        });
        if (inp.value && !isNaN(inp.value)) fmt();
    });

    // ============ Copy button ============
    document.querySelectorAll('[data-copy]').forEach(btn => {
        btn.addEventListener('click', () => {
            const sel = btn.dataset.copy;
            const el = document.querySelector(sel);
            if (!el) return;
            const text = el.textContent || el.value || '';
            navigator.clipboard.writeText(text).then(() => {
                const old = btn.textContent;
                btn.textContent = '✓ Đã sao chép';
                setTimeout(() => btn.textContent = old, 1500);
            });
        });
    });

    // ============ Product image fallback ============
    document.querySelectorAll('img[data-fallback]').forEach(img => {
        img.addEventListener('error', () => {
            if (img.src !== img.dataset.fallback) img.src = img.dataset.fallback;
        });
    });

})();
