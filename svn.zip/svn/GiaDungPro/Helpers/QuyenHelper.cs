using System.Security.Claims;

namespace CuaHangGiaDungPro.Helpers;

public static class QuyenHelper
{
    public record QuyenItem(string Ma, string Ten, string Nhom);

    public static readonly QuyenItem[] TatCa =
    {
        new("sanpham", "Quản lý sản phẩm",   "Cửa hàng"),
        new("danhmuc", "Quản lý danh mục",   "Cửa hàng"),
        new("donhang", "Quản lý đơn hàng",   "Bán hàng"),
        new("danhgia", "Duyệt đánh giá",     "Bán hàng"),
        new("baocao",  "Xem báo cáo",        "Báo cáo"),
    };

    public static readonly string[] MacDinh = { "sanpham", "danhmuc", "donhang", "baocao", "danhgia" };

    public static string[] HieuLuc(string vaiTro, string quyen)
    {
        if (vaiTro == "Admin") return TatCa.Select(x => x.Ma).ToArray();
        if (vaiTro != "NhanVien") return Array.Empty<string>();
        var s = (quyen ?? "").Trim();
        if (s == "") return MacDinh;
        if (s == "-") return Array.Empty<string>();
        return s.Split(',', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries)
                .Where(x => TatCa.Any(q => q.Ma == x)).Distinct().ToArray();
    }

    public static string Luu(IEnumerable<string> maDaChon)
    {
        var list = TatCa.Where(x => (maDaChon ?? Array.Empty<string>()).Contains(x.Ma)).Select(x => x.Ma).ToArray();
        return list.Length == 0 ? "-" : string.Join(",", list);
    }

    public static bool CoQuyen(ClaimsPrincipal user, string ma)
    {
        if (user.IsInRole("Admin")) return true;
        return user.HasClaim("Quyen", ma);
    }
}
