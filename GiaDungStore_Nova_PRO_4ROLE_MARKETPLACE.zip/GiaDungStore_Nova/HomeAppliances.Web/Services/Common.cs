namespace HomeAppliances.Web.Services;

public class ServiceResult
{
    public bool Succeeded { get; init; }
    public string? Error { get; init; }
    public static ServiceResult Ok() => new() { Succeeded = true };
    public static ServiceResult Fail(string error) => new() { Succeeded = false, Error = error };
}

public class ServiceResult<T> : ServiceResult
{
    public T? Value { get; init; }
    public static ServiceResult<T> Ok(T value) => new() { Succeeded = true, Value = value };
    public new static ServiceResult<T> Fail(string error) => new() { Succeeded = false, Error = error };
}

public class PagedResult<T>
{
    public List<T> Items { get; set; } = new();
    public int Page { get; set; } = 1;
    public int PageSize { get; set; } = 10;
    public int TotalItems { get; set; }
    public int TotalPages => Math.Max(1, (int)Math.Ceiling(TotalItems / (double)PageSize));
}

public class EmailOptions
{
    public const string SectionName = "Email";
    public bool Enabled { get; set; }
    public string SmtpHost { get; set; } = "";
    public int SmtpPort { get; set; } = 587;
    public bool UseSsl { get; set; } = true;
    public string Username { get; set; } = "";
    public string Password { get; set; } = "";
    public string FromAddress { get; set; } = "no-reply@example.invalid";
    public string FromName { get; set; } = "Cửa hàng điện máy";
}

public class StorageOptions
{
    public const string SectionName = "Storage";
    public string PrivateRoot { get; set; } = "App_Data/private";
    public long MaxImageBytes { get; set; } = 2 * 1024 * 1024;
    public long MaxPaymentProofBytes { get; set; } = 5 * 1024 * 1024;
}
