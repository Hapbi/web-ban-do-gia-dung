using Microsoft.EntityFrameworkCore;
using HomeAppliances.Web.Data;
using HomeAppliances.Web.Domain;
using HomeAppliances.Web.Models.Entities;
using HomeAppliances.Web.Models.ViewModels;

namespace HomeAppliances.Web.Services;

public interface IProductAdminService
{
    Task<PagedResult<Product>> SearchAsync(string? q, int? categoryId, bool? active, bool lowStockOnly, int page);
    Task<Product?> GetAsync(int id);
    Task<ServiceResult<int>> SaveAsync(ProductEditViewModel vm, IReadOnlyList<IFormFile> newImages);
    Task<ServiceResult> DeleteImageAsync(int productId, int imageId);
    Task<ServiceResult> SetPrimaryImageAsync(int productId, int imageId);
    Task<ServiceResult> ToggleActiveAsync(int id);
    Task<ServiceResult> DeleteAsync(int id);
}

public class ProductAdminService : IProductAdminService
{
    public const int LowStockThreshold = 5;
    private readonly ApplicationDbContext _db;
    private readonly IFileStorage _files;
    private readonly IAuditService _audit;

    public ProductAdminService(ApplicationDbContext db, IFileStorage files, IAuditService audit) { _db = db; _files = files; _audit = audit; }

    public async Task<PagedResult<Product>> SearchAsync(string? q, int? categoryId, bool? active, bool lowStockOnly, int page)
    {
        const int size = 15;
        var query = _db.Products.AsNoTracking().Include(p => p.Category).Include(p => p.Images).AsQueryable();
        if (!string.IsNullOrWhiteSpace(q)) { var t = q.Trim(); query = query.Where(p => p.Name.Contains(t) || p.Brand.Contains(t) || p.Slug.Contains(t)); }
        if (categoryId.HasValue) query = query.Where(p => p.CategoryId == categoryId.Value);
        if (active.HasValue) query = query.Where(p => p.IsActive == active.Value);
        if (lowStockOnly) query = query.Where(p => p.StockQuantity <= LowStockThreshold);
        var total = await query.CountAsync();
        page = Math.Clamp(page, 1, Math.Max(1, (int)Math.Ceiling(total / (double)size)));
        var items = await query.OrderByDescending(p => p.UpdatedUtc).Skip((page - 1) * size).Take(size).ToListAsync();
        return new PagedResult<Product> { Items = items, Page = page, PageSize = size, TotalItems = total };
    }

    public Task<Product?> GetAsync(int id) =>
        _db.Products.Include(p => p.Images).Include(p => p.Specifications).Include(p => p.Category).FirstOrDefaultAsync(p => p.Id == id);

    private async Task<string> UniqueSlugAsync(string baseSlug, int excludeId)
    {
        var slug = baseSlug; var n = 2;
        while (await _db.Products.AnyAsync(p => p.Slug == slug && p.Id != excludeId)) slug = $"{baseSlug}-{n++}";
        return slug;
    }

    /// <summary>Parses "Name: Value" lines typed by the administrator.</summary>
    public static List<(string Name, string Value)> ParseSpecs(string? text)
    {
        var list = new List<(string, string)>();
        foreach (var line in (text ?? "").Split('\n', StringSplitOptions.RemoveEmptyEntries))
        {
            var i = line.IndexOf(':');
            if (i <= 0) continue;
            var name = line[..i].Trim(); var value = line[(i + 1)..].Trim();
            if (name.Length > 0 && value.Length > 0) list.Add((name.Length > 100 ? name[..100] : name, value.Length > 500 ? value[..500] : value));
        }
        return list;
    }

    public async Task<ServiceResult<int>> SaveAsync(ProductEditViewModel vm, IReadOnlyList<IFormFile> newImages)
    {
        if (!await _db.Categories.AnyAsync(c => c.Id == vm.CategoryId)) return ServiceResult<int>.Fail("Danh mục không tồn tại.");
        if (vm.DiscountPrice.HasValue && vm.DiscountPrice.Value > 0 && vm.DiscountPrice.Value >= vm.OriginalPrice)
            return ServiceResult<int>.Fail("Giá khuyến mãi phải nhỏ hơn giá gốc.");

        // Store images first; if any file is rejected nothing is written to the database.
        var savedPaths = new List<string>();
        foreach (var f in newImages.Where(f => f.Length > 0))
        {
            var r = await _files.SavePublicImageAsync(f, "products");
            if (!r.Succeeded) { foreach (var p in savedPaths) _files.DeletePublic(p); return ServiceResult<int>.Fail($"{f.FileName}: {r.Error}"); }
            savedPaths.Add(r.Value!);
        }

        try
        {
            Product product;
            var isNew = vm.Id == 0;
            if (isNew) { product = new Product(); _db.Products.Add(product); }
            else
            {
                product = (await _db.Products.Include(p => p.Images).Include(p => p.Specifications).FirstOrDefaultAsync(p => p.Id == vm.Id))!;
                if (product == null) return ServiceResult<int>.Fail("Không tìm thấy sản phẩm.");
            }

            var baseSlug = SlugHelper.Slugify(string.IsNullOrWhiteSpace(vm.Slug) ? vm.Name : vm.Slug);
            if (baseSlug == "") baseSlug = "san-pham";
            product.Name = vm.Name.Trim(); product.Slug = await UniqueSlugAsync(baseSlug, product.Id);
            product.Description = vm.Description?.Trim() ?? ""; product.Brand = vm.Brand.Trim(); product.CategoryId = vm.CategoryId;
            product.OriginalPrice = vm.OriginalPrice;
            product.DiscountPrice = vm.DiscountPrice is > 0 ? vm.DiscountPrice : null;
            product.StockQuantity = vm.StockQuantity; product.IsFeatured = vm.IsFeatured; product.IsActive = vm.IsActive;
            product.UpdatedUtc = DateTime.UtcNow;

            _db.ProductSpecifications.RemoveRange(product.Specifications);
            product.Specifications.Clear();
            var order = 0;
            foreach (var (n, v) in ParseSpecs(vm.SpecificationsText)) product.Specifications.Add(new ProductSpecification { Name = n, Value = v, SortOrder = order++ });

            var hasPrimary = product.Images.Any(i => i.IsPrimary);
            var sort = product.Images.Count == 0 ? 0 : product.Images.Max(i => i.SortOrder) + 1;
            foreach (var path in savedPaths)
            {
                product.Images.Add(new ProductImage { Path = path, IsPrimary = !hasPrimary, SortOrder = sort++ });
                hasPrimary = true;
            }
            await _db.SaveChangesAsync();
            await _audit.LogAsync(isNew ? "Product.Create" : "Product.Update", "Product", product.Id.ToString(), $"{product.Name} | giá {product.OriginalPrice:N0} | tồn {product.StockQuantity}");
            return ServiceResult<int>.Ok(product.Id);
        }
        catch
        {
            foreach (var p in savedPaths) _files.DeletePublic(p);
            throw;
        }
    }

    public async Task<ServiceResult> DeleteImageAsync(int productId, int imageId)
    {
        var img = await _db.ProductImages.FirstOrDefaultAsync(i => i.Id == imageId && i.ProductId == productId);
        if (img == null) return ServiceResult.Fail("Không tìm thấy ảnh.");
        var wasPrimary = img.IsPrimary; var path = img.Path;
        _db.ProductImages.Remove(img);
        await _db.SaveChangesAsync();
        _files.DeletePublic(path);
        if (wasPrimary)
        {
            var next = await _db.ProductImages.Where(i => i.ProductId == productId).OrderBy(i => i.SortOrder).FirstOrDefaultAsync();
            if (next != null) { next.IsPrimary = true; await _db.SaveChangesAsync(); }
        }
        return ServiceResult.Ok();
    }

    public async Task<ServiceResult> SetPrimaryImageAsync(int productId, int imageId)
    {
        var images = await _db.ProductImages.Where(i => i.ProductId == productId).ToListAsync();
        if (images.All(i => i.Id != imageId)) return ServiceResult.Fail("Không tìm thấy ảnh.");
        foreach (var i in images) i.IsPrimary = i.Id == imageId;
        await _db.SaveChangesAsync();
        return ServiceResult.Ok();
    }

    public async Task<ServiceResult> ToggleActiveAsync(int id)
    {
        var p = await _db.Products.FirstOrDefaultAsync(x => x.Id == id);
        if (p == null) return ServiceResult.Fail("Không tìm thấy sản phẩm.");
        p.IsActive = !p.IsActive; p.UpdatedUtc = DateTime.UtcNow;
        await _db.SaveChangesAsync();
        await _audit.LogAsync(p.IsActive ? "Product.Activate" : "Product.Deactivate", "Product", id.ToString(), p.Name);
        return ServiceResult.Ok();
    }

    public async Task<ServiceResult> DeleteAsync(int id)
    {
        var p = await _db.Products.Include(x => x.Images).FirstOrDefaultAsync(x => x.Id == id);
        if (p == null) return ServiceResult.Fail("Không tìm thấy sản phẩm.");
        if (await _db.OrderItems.AnyAsync(i => i.ProductId == id))
            return ServiceResult.Fail("Sản phẩm đã có trong đơn hàng nên không thể xóa. Hãy chọn \"Ngừng bán\" thay thế.");
        var paths = p.Images.Select(i => i.Path).ToList();
        _db.Products.Remove(p);
        await _db.SaveChangesAsync();
        foreach (var path in paths) _files.DeletePublic(path);
        await _audit.LogAsync("Product.Delete", "Product", id.ToString(), p.Name);
        return ServiceResult.Ok();
    }
}
