using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using HomeAppliances.Web.Data;
using HomeAppliances.Web.Infrastructure;
using HomeAppliances.Web.Models.Entities;
using HomeAppliances.Web.Models.ViewModels;
using HomeAppliances.Web.Services;

namespace HomeAppliances.Web.Areas.Admin.Controllers;

[Area("Admin"), Authorize(Policy = AppPolicies.AdminOnly)]
public class BannersController : Controller
{
    private readonly ApplicationDbContext _db;
    private readonly IFileStorage _files;
    private readonly IAuditService _audit;
    public BannersController(ApplicationDbContext db, IFileStorage files, IAuditService audit) { _db = db; _files = files; _audit = audit; }

    public async Task<IActionResult> Index() => View(await _db.Banners.AsNoTracking().OrderBy(b => b.SortOrder).ToListAsync());

    public IActionResult Create() => View("Edit", new BannerEditViewModel());

    public async Task<IActionResult> Edit(int id)
    {
        var b = await _db.Banners.AsNoTracking().FirstOrDefaultAsync(x => x.Id == id);
        return b == null ? NotFound() : View(new BannerEditViewModel { Id = b.Id, Title = b.Title, Subtitle = b.Subtitle, LinkUrl = b.LinkUrl, IsActive = b.IsActive, SortOrder = b.SortOrder, ExistingImage = b.ImagePath });
    }

    [HttpPost, RequestSizeLimit(4 * 1024 * 1024)]
    public async Task<IActionResult> Save(BannerEditViewModel vm, IFormFile? image)
    {
        var existing = vm.Id == 0 ? null : await _db.Banners.FirstOrDefaultAsync(b => b.Id == vm.Id);
        if (vm.Id != 0 && existing == null) return NotFound();
        vm.ExistingImage = existing?.ImagePath;

        // Only internal paths or https links: blocks javascript: and other schemes.
        if (!string.IsNullOrWhiteSpace(vm.LinkUrl) && !(vm.LinkUrl.StartsWith('/') && !vm.LinkUrl.StartsWith("//")) && !vm.LinkUrl.StartsWith("https://"))
            ModelState.AddModelError(nameof(vm.LinkUrl), "Liên kết phải bắt đầu bằng / hoặc https://");
        if (existing == null && image is not { Length: > 0 }) ModelState.AddModelError("", "Vui lòng chọn ảnh banner.");
        if (!ModelState.IsValid) return View("Edit", vm);

        string? newPath = null;
        if (image is { Length: > 0 })
        {
            var saved = await _files.SavePublicImageAsync(image, "banners");
            if (!saved.Succeeded) { ModelState.AddModelError("", saved.Error!); return View("Edit", vm); }
            newPath = saved.Value;
        }
        var b = existing ?? new Banner();
        var oldPath = existing?.ImagePath;
        b.Title = vm.Title.Trim(); b.Subtitle = vm.Subtitle?.Trim(); b.LinkUrl = string.IsNullOrWhiteSpace(vm.LinkUrl) ? null : vm.LinkUrl.Trim();
        b.IsActive = vm.IsActive; b.SortOrder = vm.SortOrder;
        if (newPath != null) b.ImagePath = newPath;
        if (existing == null) _db.Banners.Add(b);
        await _db.SaveChangesAsync();
        if (newPath != null && oldPath != null) _files.DeletePublic(oldPath);
        await _audit.LogAsync(existing == null ? "Banner.Create" : "Banner.Update", "Banner", b.Id.ToString(), b.Title);
        TempData["Success"] = "Đã lưu banner.";
        return RedirectToAction(nameof(Index));
    }

    [HttpPost]
    public async Task<IActionResult> Delete(int id)
    {
        var b = await _db.Banners.FirstOrDefaultAsync(x => x.Id == id);
        if (b == null) return NotFound();
        _db.Banners.Remove(b);
        await _db.SaveChangesAsync();
        _files.DeletePublic(b.ImagePath);
        await _audit.LogAsync("Banner.Delete", "Banner", id.ToString(), b.Title);
        TempData["Success"] = "Đã xóa banner.";
        return RedirectToAction(nameof(Index));
    }
}
