using HomeAppliances.Web.Domain;
using Xunit;

namespace HomeAppliances.Tests.Unit;

public class PricingCalculatorTests
{
    [Fact]
    public void Computes_subtotal_discount_shipping_and_total()
    {
        var r = PricingCalculator.Calculate(new[]
        {
            new PricingLine(1_000_000m, 800_000m, 2),   // sale item: saves 400k
            new PricingLine(500_000m, 500_000m, 1)
        }, shippingFee: 30_000m, freeShippingThreshold: 5_000_000m);

        Assert.Equal(2_500_000m, r.Subtotal);
        Assert.Equal(400_000m, r.DiscountTotal);
        Assert.Equal(30_000m, r.ShippingFee);
        Assert.Equal(2_130_000m, r.Total);   // 2.5m - 0.4m + 30k
    }

    [Fact]
    public void Free_shipping_applies_once_the_discounted_total_reaches_the_threshold()
    {
        var r = PricingCalculator.Calculate(new[] { new PricingLine(6_000_000m, 5_000_000m, 1) }, 30_000m, 5_000_000m);
        Assert.Equal(0m, r.ShippingFee);
        Assert.Equal(5_000_000m, r.Total);
    }

    [Fact]
    public void Threshold_is_measured_after_discounts()
    {
        var r = PricingCalculator.Calculate(new[] { new PricingLine(5_200_000m, 4_900_000m, 1) }, 30_000m, 5_000_000m);
        Assert.Equal(30_000m, r.ShippingFee);   // list price is over 5m but the customer pays 4.9m
    }

    [Fact]
    public void Zero_threshold_disables_free_shipping()
    {
        var r = PricingCalculator.Calculate(new[] { new PricingLine(90_000_000m, 90_000_000m, 1) }, 30_000m, 0m);
        Assert.Equal(30_000m, r.ShippingFee);
    }

    [Fact]
    public void Empty_cart_costs_nothing_including_shipping()
    {
        var r = PricingCalculator.Calculate(Array.Empty<PricingLine>(), 30_000m, 5_000_000m);
        Assert.Equal(0m, r.Total);
        Assert.Equal(0m, r.ShippingFee);
    }

    [Fact]
    public void A_sale_price_above_the_list_price_is_never_charged()
    {
        var r = PricingCalculator.Calculate(new[] { new PricingLine(1_000_000m, 1_500_000m, 1) }, 0m, 0m);
        Assert.Equal(1_000_000m, r.Total);
    }

    [Fact]
    public void Ignores_non_positive_quantities()
    {
        var r = PricingCalculator.Calculate(new[] { new PricingLine(100_000m, 100_000m, 0), new PricingLine(100_000m, 100_000m, -3) }, 30_000m, 0m);
        Assert.Equal(0m, r.Total);
    }
}
