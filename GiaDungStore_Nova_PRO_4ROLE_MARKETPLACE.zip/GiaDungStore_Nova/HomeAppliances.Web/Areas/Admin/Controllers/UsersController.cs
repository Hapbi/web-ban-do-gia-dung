using System.Security.Claims;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using HomeAppliances.Web.Data;
using HomeAppliances.Web.Infrastructure;
using HomeAppliances.Web.Models.Entities;
using HomeAppliances.Web.Models.ViewModels;
using HomeAppliances.Web.Services;

namespace HomeAppliances.Web.Areas.Admin.Controllers;

/// <summary>Customer and staff account management, role assignment and the "verify payments" permission.</summary>
[Area("Admin"), Authorize(Policy = AppPolicies.AdminOnly)]
public class UsersController : Controller
{
    private readonly UserManager<ApplicationUser> _users;
    private readonly ApplicationDbContext _db;
    private readonly IAuditService _audit;
    public UsersController(UserManager<ApplicationUser> users, ApplicationDbContext db, IAuditService audit) { _users = users; _db = db; _audit = audit; }

    private static bool HasVerifyClaim(IEnumerable<Claim> c) => c.Any(x => x.Type == AppClaims.PermissionType && x.Value == AppClaims.VerifyPayments);

    public async Task<IActionResult> Index(string? role, string? q, int page = 1)
    {
        const int size = 20;
        var query = from u in _db.Users
                    join ur in _db.UserRoles on u.Id equals ur.UserId
                    join r in _db.Roles on ur.RoleId equals r.Id
                    select new { User = u, RoleName = r.Name };
        if (!string.IsNullOrEmpty(role)) query = query.Where(x => x.RoleName == role);
        if (!string.IsNullOrWhiteSpace(q))
        {
            var t = q.Trim();
            query = query.Where(x => x.User.Email!.Contains(t) || x.User.FullName.Contains(t) || x.User.PhoneNumber!.Contains(t));
        }
        var total = await query.CountAsync();
        page = Math.Clamp(page, 1, Math.Max(1, (int)Math.Ceiling(total / (double)size)));
        var rows = await query.OrderByDescending(x => x.User.CreatedUtc).Skip((page - 1) * size).Take(size).ToListAsync();

        var items = new List<UserListItem>();
        foreach (var x in rows)
        {
            var canVerify = x.RoleName == AppRoles.Employee && HasVerifyClaim(await _users.GetClaimsAsync(x.User));
            items.Add(new UserListItem { Id = x.User.Id, Email = x.User.Email ?? "", FullName = x.User.FullName, Phone = x.User.PhoneNumber, Role = x.RoleName ?? "", IsActive = x.User.IsActive, CanVerifyPayments = canVerify, CreatedUtc = x.User.CreatedUtc });
        }
        ViewData["Role"] = role; ViewData["Q"] = q;
        return View(new PagedResult<UserListItem> { Items = items, Page = page, PageSize = size, TotalItems = total });
    }

    public IActionResult CreateStaff() => View(new CreateStaffViewModel());

    [HttpPost]
    public async Task<IActionResult> CreateStaff(CreateStaffViewModel vm)
    {
        if (vm.Role is not (AppRoles.Employee or AppRoles.Admin)) ModelState.AddModelError(nameof(vm.Role), "Vai trò không hợp lệ.");
        if (!ModelState.IsValid) return View(vm);

        var email = vm.Email.Trim();
        var user = new ApplicationUser { UserName = email, Email = email, EmailConfirmed = true, FullName = vm.FullName.Trim(), PhoneNumber = vm.PhoneNumber?.Trim() };
        var result = await _users.CreateAsync(user, vm.Password);
        if (!result.Succeeded)
        {
            foreach (var e in result.Errors) ModelState.AddModelError(e.Code.Contains("Password") ? nameof(vm.Password) : nameof(vm.Email), IdentityErrors.Translate(e));
            return View(vm);
        }
        await _users.AddToRoleAsync(user, vm.Role);
        await _audit.LogAsync("User.Create", "User", user.Id, $"{email} ({vm.Role})");
        TempData["Success"] = "Đã tạo tài khoản. Hãy báo mật khẩu ban đầu cho nhân viên và yêu cầu đổi mật khẩu sau khi đăng nhập.";
        return RedirectToAction(nameof(Index), new { role = vm.Role });
    }

    public async Task<IActionResult> Edit(string id)
    {
        var u = await _users.FindByIdAsync(id);
        if (u == null) return NotFound();
        var roles = await _users.GetRolesAsync(u);
        return View(new UserEditViewModel
        {
            Id = u.Id, Email = u.Email ?? "", FullName = u.FullName, Role = roles.FirstOrDefault() ?? AppRoles.Customer,
            CanVerifyPayments = HasVerifyClaim(await _users.GetClaimsAsync(u)), IsActive = u.IsActive, IsSelf = u.Id == User.GetUserId()
        });
    }

    [HttpPost]
    public async Task<IActionResult> Edit(UserEditViewModel vm)
    {
        var u = await _users.FindByIdAsync(vm.Id);
        if (u == null) return NotFound();
        vm.Email = u.Email ?? ""; vm.IsSelf = u.Id == User.GetUserId();
        if (!ModelState.IsValid) return View(vm);

        var currentRoles = await _users.GetRolesAsync(u);
        var currentRole = currentRoles.FirstOrDefault() ?? AppRoles.Customer;

        // ---- safeguards ----
        string? error = null;
        if (!AppRoles.All.Contains(vm.Role)) error = "Vai trò không hợp lệ.";
        else if (vm.IsSelf && (vm.Role != currentRole || !vm.IsActive)) error = "Bạn không thể đổi vai trò hoặc vô hiệu hóa chính tài khoản của mình.";
        else if (currentRole == AppRoles.Admin && (vm.Role != AppRoles.Admin || !vm.IsActive))
        {
            var otherActiveAdmins = (await _users.GetUsersInRoleAsync(AppRoles.Admin)).Count(a => a.IsActive && a.Id != u.Id);
            if (otherActiveAdmins == 0) error = "Phải còn ít nhất một quản trị viên đang hoạt động.";
        }
        if (error != null) { ModelState.AddModelError("", error); return View(vm); }

        // ---- apply ----
        u.FullName = vm.FullName.Trim();
        if (vm.Role != currentRole)
        {
            await _users.RemoveFromRolesAsync(u, currentRoles);
            await _users.AddToRoleAsync(u, vm.Role);
        }
        var claims = await _users.GetClaimsAsync(u);
        var want = vm.Role == AppRoles.Employee && vm.CanVerifyPayments;
        var has = HasVerifyClaim(claims);
        var claim = new Claim(AppClaims.PermissionType, AppClaims.VerifyPayments);
        if (want && !has) await _users.AddClaimAsync(u, claim);
        if (!want && has) await _users.RemoveClaimAsync(u, claim);

        var activeChanged = u.IsActive != vm.IsActive;
        u.IsActive = vm.IsActive;
        if (activeChanged)
        {
            await _users.SetLockoutEnabledAsync(u, true);
            await _users.SetLockoutEndDateAsync(u, vm.IsActive ? null : DateTimeOffset.MaxValue);
            if (vm.IsActive) await _users.ResetAccessFailedCountAsync(u);
        }
        await _users.UpdateAsync(u);
        await _users.UpdateSecurityStampAsync(u);   // signs the user out of existing sessions so new rights apply at once

        await _audit.LogAsync("User.Update", "User", u.Id, $"{u.Email}: vai trò {currentRole}->{vm.Role}, xác minh thanh toán={want}, hoạt động={vm.IsActive}");
        TempData["Success"] = "Đã cập nhật tài khoản.";
        return RedirectToAction(nameof(Index));
    }
}
