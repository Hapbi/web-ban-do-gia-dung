using System.Globalization;

namespace HomeAppliances.Web.Helpers;

/// <summary>
/// Formats money as Vietnamese Dong, e.g. 12.490.000 ₫.
/// Uses an explicit NumberFormatInfo so the output does not depend on the
/// server's ICU/culture data.
/// </summary>
public static class VndFormatter
{
    private static readonly NumberFormatInfo Nfi = new()
    {
        NumberGroupSeparator = ".",
        NumberDecimalSeparator = ",",
        NumberGroupSizes = new[] { 3 }
    };

    public static string ToVnd(this decimal amount) =>
        Math.Round(amount, 0, MidpointRounding.AwayFromZero).ToString("N0", Nfi) + " ₫";

    public static string ToVnd(this decimal? amount) => amount.HasValue ? amount.Value.ToVnd() : "";
}
