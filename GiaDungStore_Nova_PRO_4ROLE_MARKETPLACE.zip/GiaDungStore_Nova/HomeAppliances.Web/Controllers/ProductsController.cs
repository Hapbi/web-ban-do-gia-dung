using Microsoft.AspNetCore.Mvc;
using HomeAppliances.Web.Models.ViewModels;
using HomeAppliances.Web.Services;

namespace HomeAppliances.Web.Controllers;

public class ProductsController : Controller
{
    private readonly IProductCatalog _catalog;

    public ProductsController(IProductCatalog catalog) => _catalog = catalog;

    [HttpGet("san-pham")]
    public async Task<IActionResult> Index([FromQuery] ProductListQuery query) =>
        View(await _catalog.GetProductListAsync(query));

    [HttpGet("danh-muc/{slug}")]
    public async Task<IActionResult> Category(string slug, [FromQuery] ProductListQuery query)
    {
        if (await _catalog.GetCategoryAsync(slug) is null) return NotFound();
        query.Category = slug;
        return View("Index", await _catalog.GetProductListAsync(query));
    }

    [HttpGet("san-pham/{slug}")]
    public async Task<IActionResult> Detail(string slug)
    {
        var product = await _catalog.GetProductBySlugAsync(slug);
        return product is null ? NotFound() : View(product);
    }
}
