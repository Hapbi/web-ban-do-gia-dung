using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using HomeAppliances.Web.Infrastructure;
using HomeAppliances.Web.Models.ViewModels;
using HomeAppliances.Web.Services;

namespace HomeAppliances.Web.Areas.Admin.Controllers;

/// <summary>Bank account details and the QR image customers scan. The QR is always the image uploaded here.</summary>
[Area("Admin"), Authorize(Policy = AppPolicies.AdminOnly)]
public class BankSettingsController : Controller
{
    private readonly ISettingsService _settings;
    private readonly IFileStorage _files;
    private readonly IAuditService _audit;
    public BankSettingsController(ISettingsService settings, IFileStorage files, IAuditService audit) { _settings = settings; _files = files; _audit = audit; }

    public async Task<IActionResult> Index()
    {
        var b = await _settings.GetBankAsync();
        return View(new BankSettingsViewModel { BankName = b.BankName, AccountHolder = b.AccountHolder, AccountNumber = b.AccountNumber, Branch = b.Branch, Instructions = b.Instructions, ReferenceFormat = b.ReferenceFormat, QrImagePath = b.QrImagePath });
    }

    [HttpPost, RequestSizeLimit(4 * 1024 * 1024)]
    public async Task<IActionResult> Index(BankSettingsViewModel vm, IFormFile? qrImage)
    {
        var current = await _settings.GetBankAsync();
        vm.QrImagePath = current.QrImagePath;
        if (!vm.ReferenceFormat.Contains("{OrderNumber}", StringComparison.OrdinalIgnoreCase))
            ModelState.AddModelError(nameof(vm.ReferenceFormat), "Mẫu phải chứa {OrderNumber} để đối soát được đơn hàng.");
        if (!ModelState.IsValid) return View(vm);

        string? newQr = null;
        if (qrImage is { Length: > 0 })
        {
            var saved = await _files.SavePublicImageAsync(qrImage, "qr");
            if (!saved.Succeeded) { ModelState.AddModelError("", saved.Error!); return View(vm); }
            newQr = saved.Value;
        }
        await _settings.SaveBankAsync(new Models.Entities.BankTransferSettings
        {
            BankName = vm.BankName.Trim(), AccountHolder = vm.AccountHolder.Trim(), AccountNumber = vm.AccountNumber.Trim(), Branch = vm.Branch?.Trim(),
            Instructions = vm.Instructions.Trim(), ReferenceFormat = vm.ReferenceFormat.Trim(), QrImagePath = newQr ?? current.QrImagePath
        });
        if (newQr != null) _files.DeletePublic(current.QrImagePath);
        await _audit.LogAsync("BankSettings.Update", "BankTransferSettings", "1", $"{vm.BankName.Trim()}{(newQr != null ? " | đổi mã QR" : "")}");
        TempData["Success"] = "Đã lưu thông tin chuyển khoản.";
        return RedirectToAction(nameof(Index));
    }
}
