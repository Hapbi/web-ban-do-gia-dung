using System.ComponentModel.DataAnnotations;

namespace HomeAppliances.Web.Models.ViewModels;

public static class Msg
{
    public const string PhonePattern = @"^(\+84|0)\d{9,10}$";
    public const string PhoneError = "Số điện thoại không hợp lệ (ví dụ 0912345678).";
}

public class RegisterViewModel
{
    [Required(ErrorMessage = "Vui lòng nhập họ và tên."), StringLength(100, ErrorMessage = "Họ và tên tối đa 100 ký tự.")]
    [Display(Name = "Họ và tên")] public string FullName { get; set; } = "";

    [Required(ErrorMessage = "Vui lòng nhập email."), EmailAddress(ErrorMessage = "Email không hợp lệ."), StringLength(256)]
    [Display(Name = "Email")] public string Email { get; set; } = "";

    [Required(ErrorMessage = "Vui lòng nhập số điện thoại."), RegularExpression(Msg.PhonePattern, ErrorMessage = Msg.PhoneError)]
    [Display(Name = "Số điện thoại")] public string PhoneNumber { get; set; } = "";

    [Required(ErrorMessage = "Vui lòng nhập mật khẩu."), StringLength(100, MinimumLength = 8, ErrorMessage = "Mật khẩu từ 8 đến 100 ký tự.")]
    [DataType(DataType.Password)][Display(Name = "Mật khẩu")] public string Password { get; set; } = "";

    [Required(ErrorMessage = "Vui lòng nhập lại mật khẩu."), Compare(nameof(Password), ErrorMessage = "Mật khẩu nhập lại không khớp.")]
    [DataType(DataType.Password)][Display(Name = "Nhập lại mật khẩu")] public string ConfirmPassword { get; set; } = "";
}

public class LoginViewModel
{
    [Required(ErrorMessage = "Vui lòng nhập tên đăng nhập hoặc email.")]
    [Display(Name = "Tên đăng nhập hoặc email")] public string Email { get; set; } = "";

    [Required(ErrorMessage = "Vui lòng nhập mật khẩu.")]
    [DataType(DataType.Password)][Display(Name = "Mật khẩu")] public string Password { get; set; } = "";

    [Display(Name = "Ghi nhớ đăng nhập")] public bool RememberMe { get; set; }
    public string? ReturnUrl { get; set; }
}

public class ForgotPasswordViewModel
{
    [Required(ErrorMessage = "Vui lòng nhập email."), EmailAddress(ErrorMessage = "Email không hợp lệ.")]
    [Display(Name = "Email đã đăng ký")] public string Email { get; set; } = "";
}

public class ResetPasswordViewModel
{
    [Required, EmailAddress] public string Email { get; set; } = "";
    [Required] public string Code { get; set; } = "";

    [Required(ErrorMessage = "Vui lòng nhập mật khẩu mới."), StringLength(100, MinimumLength = 8, ErrorMessage = "Mật khẩu từ 8 đến 100 ký tự.")]
    [DataType(DataType.Password)][Display(Name = "Mật khẩu mới")] public string Password { get; set; } = "";

    [Required(ErrorMessage = "Vui lòng nhập lại mật khẩu."), Compare(nameof(Password), ErrorMessage = "Mật khẩu nhập lại không khớp.")]
    [DataType(DataType.Password)][Display(Name = "Nhập lại mật khẩu mới")] public string ConfirmPassword { get; set; } = "";
}

public class ProfileViewModel
{
    [Display(Name = "Email")] public string Email { get; set; } = "";

    [Required(ErrorMessage = "Vui lòng nhập họ và tên."), StringLength(100, ErrorMessage = "Họ và tên tối đa 100 ký tự.")]
    [Display(Name = "Họ và tên")] public string FullName { get; set; } = "";

    [Required(ErrorMessage = "Vui lòng nhập số điện thoại."), RegularExpression(Msg.PhonePattern, ErrorMessage = Msg.PhoneError)]
    [Display(Name = "Số điện thoại")] public string PhoneNumber { get; set; } = "";
}

public class ChangePasswordViewModel
{
    [Required(ErrorMessage = "Vui lòng nhập mật khẩu hiện tại.")]
    [DataType(DataType.Password)][Display(Name = "Mật khẩu hiện tại")] public string CurrentPassword { get; set; } = "";

    [Required(ErrorMessage = "Vui lòng nhập mật khẩu mới."), StringLength(100, MinimumLength = 8, ErrorMessage = "Mật khẩu từ 8 đến 100 ký tự.")]
    [DataType(DataType.Password)][Display(Name = "Mật khẩu mới")] public string NewPassword { get; set; } = "";

    [Required(ErrorMessage = "Vui lòng nhập lại mật khẩu mới."), Compare(nameof(NewPassword), ErrorMessage = "Mật khẩu nhập lại không khớp.")]
    [DataType(DataType.Password)][Display(Name = "Nhập lại mật khẩu mới")] public string ConfirmPassword { get; set; } = "";
}

public class AddressViewModel
{
    public int Id { get; set; }

    [Required(ErrorMessage = "Vui lòng nhập họ tên người nhận."), StringLength(100)]
    [Display(Name = "Họ và tên người nhận")] public string ReceiverName { get; set; } = "";

    [Required(ErrorMessage = "Vui lòng nhập số điện thoại."), RegularExpression(Msg.PhonePattern, ErrorMessage = Msg.PhoneError)]
    [Display(Name = "Số điện thoại")] public string Phone { get; set; } = "";

    [Required(ErrorMessage = "Vui lòng nhập địa chỉ."), StringLength(300, MinimumLength = 10, ErrorMessage = "Địa chỉ từ 10 đến 300 ký tự.")]
    [Display(Name = "Địa chỉ")] public string Address { get; set; } = "";

    [Display(Name = "Đặt làm địa chỉ mặc định")] public bool IsDefault { get; set; }
}
