@echo off
setlocal
cd /d "%~dp0NovaShop"
dotnet --version >nul 2>&1
if errorlevel 1 (
  echo Chua tim thay .NET 8 SDK. Hay cai .NET 8 SDK truoc.
  echo https://dotnet.microsoft.com/download/dotnet/8.0
  pause
  exit /b 1
)
dotnet restore
if errorlevel 1 pause & exit /b 1
dotnet run
pause
