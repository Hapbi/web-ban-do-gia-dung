using Microsoft.AspNetCore.Http;
using Microsoft.Data.Sqlite;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.Logging.Abstractions;
using HomeAppliances.Web.Data;
using HomeAppliances.Web.Domain;
using HomeAppliances.Web.Models.Entities;
using HomeAppliances.Web.Services;

namespace HomeAppliances.Tests.Integration;

/// <summary>An isolated in-memory SQLite database with the real schema, plus the real services wired to fakes for files and e-mail.</summary>
public sealed class TestDb : IDisposable
{
    private readonly SqliteConnection _conn;
    private readonly DbContextOptions<ApplicationDbContext> _options;
    public ApplicationDbContext Db { get; }
    public FakeEmail Email { get; } = new();

    public TestDb()
    {
        _conn = new SqliteConnection("DataSource=:memory:");
        _conn.Open();
        _options = new DbContextOptionsBuilder<ApplicationDbContext>().UseSqlite(_conn).Options;
        Db = new ApplicationDbContext(_options);
        Db.Database.EnsureCreated();
        Db.Categories.Add(new Category { Id = 1, Name = "Tủ lạnh", Slug = "tu-lanh" });
        Db.SaveChanges();
    }

    /// <summary>A second context on the same database, so assertions never read stale tracked entities.</summary>
    public ApplicationDbContext Fresh() => new(_options);

    public OrderService Orders()
    {
        var cache = new MemoryCache(new MemoryCacheOptions());
        var ctx = Fresh();
        return new OrderService(ctx, new SettingsService(ctx, cache), new FakeFiles(), Email, new AuditService(ctx, new HttpContextAccessor()), NullLogger<OrderService>.Instance);
    }

    public ReportService Reports() => new(Fresh());

    public ApplicationUser AddUser(string name)
    {
        var u = new ApplicationUser { Id = Guid.NewGuid().ToString(), UserName = name + "@test.local", NormalizedUserName = name.ToUpper() + "@TEST.LOCAL", Email = name + "@test.local", NormalizedEmail = name.ToUpper() + "@TEST.LOCAL", FullName = name, SecurityStamp = Guid.NewGuid().ToString() };
        Db.Users.Add(u); Db.SaveChanges();
        return u;
    }

    public Product AddProduct(string name, decimal price, int stock, decimal? sale = null)
    {
        var p = new Product { Name = name, Slug = SlugHelper.Slugify(name) + "-" + Guid.NewGuid().ToString("N")[..4], Brand = "Test", CategoryId = 1, OriginalPrice = price, DiscountPrice = sale, StockQuantity = stock, Description = "x" };
        Db.Products.Add(p); Db.SaveChanges();
        return p;
    }

    public void PutInCart(ApplicationUser user, Product product, int qty)
    {
        var cart = Db.Carts.FirstOrDefault(c => c.UserId == user.Id);
        if (cart == null) { cart = new Cart { UserId = user.Id }; Db.Carts.Add(cart); Db.SaveChanges(); }
        Db.CartItems.Add(new CartItem { CartId = cart.Id, ProductId = product.Id, Quantity = qty });
        Db.SaveChanges();
    }

    public async Task<Order> PlaceOrderAsync(ApplicationUser user, Product product, int qty, string phone = "0912345678")
    {
        PutInCart(user, product, qty);
        var r = await Orders().PlaceOrderAsync(user.Id, user.Email!, new CheckoutInput(user.FullName, phone, "12 Phố Test, Quận 1, TP HCM", null));
        Assert(r.Succeeded, r.Error);
        return r.Value!;
    }

    public static IFormFile Png(string name = "bien-lai.png")
    {
        var bytes = new byte[] { 0x89, 0x50, 0x4E, 0x47, 0x0D, 0x0A, 0x1A, 0x0A, 0, 0, 0, 13, 73, 72, 68, 82, 0, 0, 0, 1 };
        return new FormFile(new MemoryStream(bytes), 0, bytes.Length, "proof", name);
    }

    private static void Assert(bool ok, string? msg) { if (!ok) throw new InvalidOperationException("Setup failed: " + msg); }

    public void Dispose() { Db.Dispose(); _conn.Dispose(); }
}

public class FakeFiles : IFileStorage
{
    public Task<ServiceResult<string>> SavePublicImageAsync(IFormFile file, string folder) => Task.FromResult(ServiceResult<string>.Ok($"/uploads/{folder}/{Guid.NewGuid():N}.png"));
    public Task<ServiceResult<StoredFile>> SavePrivateImageAsync(IFormFile file, string subFolder) =>
        Task.FromResult(ServiceResult<StoredFile>.Ok(new StoredFile($"{subFolder}/{Guid.NewGuid():N}.png", "image/png", file.Length)));
    public (Stream Stream, string ContentType)? OpenPrivate(string relativePath) => null;
    public void DeletePublic(string? webPath) { }
    public void DeletePrivate(string? relativePath) { }
}

public class FakeEmail : IEmailService
{
    public List<(string To, string Subject)> Sent { get; } = new();
    public bool IsEnabled => true;
    public Task SendAsync(string to, string subject, string htmlBody) { Sent.Add((to, subject)); return Task.CompletedTask; }
}
